-- =====================================================================
-- Fiscal Control — esquema do banco (Supabase / Postgres)
-- Rode este arquivo inteiro uma vez em: Supabase > SQL Editor > New query
-- Modelo: equipe única, dados compartilhados entre todos os usuários LOGADOS.
-- =====================================================================

-- 1) Histórico de importações (cada linha = um arquivo enviado)
create table if not exists public.importacoes (
  id              text primary key,
  source_type     text        not null,            -- TOTVS_SAIDA | TOTVS_ENTRADA | QIVE_SEFAZ
  file_name       text        not null,
  status          text        not null,            -- SUCESSO | ATENCAO | ERRO
  is_current      boolean     not null default false, -- arquivo "ativo" daquela origem
  storage_path    text,                            -- caminho do CSV no bucket 'importacoes'
  log             jsonb       not null,            -- ImportLogEntry completo
  imported_at     timestamptz not null default now(),
  imported_by     uuid        default auth.uid(),
  imported_by_email text      default (auth.jwt() ->> 'email')
);
create index if not exists importacoes_origem_idx
  on public.importacoes (source_type, is_current, imported_at desc);

-- 2) Benefícios fiscais cadastrados
create table if not exists public.beneficios_fiscais (
  id            text primary key,
  dados         jsonb       not null,              -- BeneficioFiscal completo
  criado_em     timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  atualizado_por uuid       default auth.uid()
);

-- 3) Segurança: RLS ligado e liberado SOMENTE para usuários autenticados
alter table public.importacoes        enable row level security;
alter table public.beneficios_fiscais enable row level security;

drop policy if exists "equipe_importacoes" on public.importacoes;
create policy "equipe_importacoes" on public.importacoes
  for all to authenticated using (true) with check (true);

drop policy if exists "equipe_beneficios" on public.beneficios_fiscais;
create policy "equipe_beneficios" on public.beneficios_fiscais
  for all to authenticated using (true) with check (true);

-- 4) Bucket privado para os CSVs importados
insert into storage.buckets (id, name, public)
values ('importacoes', 'importacoes', false)
on conflict (id) do nothing;

drop policy if exists "equipe_arquivos" on storage.objects;
create policy "equipe_arquivos" on storage.objects
  for all to authenticated
  using (bucket_id = 'importacoes')
  with check (bucket_id = 'importacoes');
