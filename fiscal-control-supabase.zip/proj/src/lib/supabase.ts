import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

/** false quando as variáveis de ambiente não foram configuradas (Vercel / .env.local) */
export const supabaseConfigurado = Boolean(url && anonKey);

// A anon key é pública por design: quem protege os dados é o login + RLS (ver supabase/schema.sql).
export const supabase = createClient(url ?? 'http://localhost', anonKey ?? 'sem-configuracao');

export const DB_ERROR_EVENT = 'fiscal-db-error';

/** Avisa a interface (banner vermelho) quando uma gravação/leitura no banco falha. */
export function reportarErroBanco(mensagem: string, erro?: unknown) {
  console.error(mensagem, erro);
  window.dispatchEvent(new CustomEvent(DB_ERROR_EVENT, { detail: mensagem }));
}
