import { ImportLogEntry, ImportSourceType, ImportStatus } from '../types/importHistory';
import { parseCSVString, ParseResult } from '../utils/csvParser';
import { parseQiveCSVString, QiveParseResult } from '../utils/qiveParser';
import { supabase, reportarErroBanco } from '../lib/supabase';

const BUCKET = 'importacoes';
const LEGACY_STORAGE_KEY = 'txc_fiscal_import_history_v2'; // histórico antigo (localStorage)

export interface DatasetsAtuais {
  saida?: { result: ParseResult; fileName: string };
  qive?: { result: QiveParseResult; fileName: string };
  totvsEntrada?: { result: ParseResult; fileName: string };
}

interface PersistOptions {
  /** false = só memória (ex.: dados de demonstração não vão para o banco compartilhado) */
  persist?: boolean;
}

class ImportacaoService {
  // Cache em memória do histórico; o banco (tabela `importacoes`) é a fonte da verdade.
  private inMemoryHistory: ImportLogEntry[] = [];

  /** Carrega o histórico compartilhado do banco. Chamar após o login. */
  public async carregar(): Promise<void> {
    // Remove o histórico antigo que ficava no navegador (dados fiscais não devem ficar em localStorage)
    try {
      localStorage.removeItem(LEGACY_STORAGE_KEY);
    } catch {
      // ignore
    }

    const { data, error } = await supabase
      .from('importacoes')
      .select('log')
      .order('imported_at', { ascending: false })
      .limit(50);

    if (error) {
      reportarErroBanco('Não foi possível carregar o histórico de importações.', error);
      return;
    }
    this.inMemoryHistory = (data ?? []).map((r) => r.log as ImportLogEntry);
  }

  /** Recarrega os últimos arquivos "ativos" (saída, Qive, TOTVS entrada) para não precisar reenviar planilhas. */
  public async carregarAtuais(): Promise<DatasetsAtuais> {
    const out: DatasetsAtuais = {};

    const { data, error } = await supabase
      .from('importacoes')
      .select('source_type, file_name, storage_path')
      .eq('is_current', true)
      .order('imported_at', { ascending: false });

    if (error) {
      reportarErroBanco('Não foi possível carregar os arquivos importados anteriormente.', error);
      return out;
    }

    const primeiroPorOrigem = new Map<string, { file_name: string; storage_path: string | null }>();
    for (const row of data ?? []) {
      if (!primeiroPorOrigem.has(row.source_type) && row.storage_path) {
        primeiroPorOrigem.set(row.source_type, row);
      }
    }

    const baixar = async (origem: ImportSourceType) => {
      const row = primeiroPorOrigem.get(origem);
      if (!row?.storage_path) return null;
      const { data: blob, error: dlError } = await supabase.storage
        .from(BUCKET)
        .download(row.storage_path);
      if (dlError || !blob) {
        reportarErroBanco(`Não foi possível baixar o arquivo "${row.file_name}".`, dlError);
        return null;
      }
      return { content: await blob.text(), fileName: row.file_name };
    };

    const [saida, qive, totvs] = await Promise.all([
      baixar('TOTVS_SAIDA'),
      baixar('QIVE_SEFAZ'),
      baixar('TOTVS_ENTRADA'),
    ]);

    // Re-processa o CSV original com os mesmos parsers (sem registrar novo histórico)
    if (saida) out.saida = { result: parseCSVString(saida.content), fileName: saida.fileName };
    if (qive) out.qive = { result: parseQiveCSVString(qive.content), fileName: qive.fileName };
    if (totvs)
      out.totvsEntrada = { result: parseCSVString(totvs.content), fileName: totvs.fileName };
    return out;
  }

  public getHistorico(): ImportLogEntry[] {
    return [...this.inMemoryHistory];
  }

  public listarHistorico(): ImportLogEntry[] {
    return this.getHistorico();
  }

  public registrarImportacao(
    entry: Omit<ImportLogEntry, 'id' | 'importedAt'>,
    content?: string,
    options: PersistOptions = {}
  ): ImportLogEntry {
    const fullEntry: ImportLogEntry = {
      ...entry,
      id: `IMP-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      importedAt: new Date().toISOString(),
    };

    // Atualiza a tela na hora; a gravação no banco acontece em segundo plano
    this.inMemoryHistory.unshift(fullEntry);
    this.inMemoryHistory = this.inMemoryHistory.slice(0, 50);

    if (options.persist !== false && content !== undefined) {
      void this.persistir(fullEntry, content);
    }
    return fullEntry;
  }

  private async persistir(entry: ImportLogEntry, content: string): Promise<void> {
    const path = `${entry.sourceType}/${entry.id}.csv`;

    const up = await supabase.storage
      .from(BUCKET)
      .upload(path, new Blob([content], { type: 'text/csv;charset=utf-8' }), {
        contentType: 'text/csv;charset=utf-8',
      });
    if (up.error) {
      reportarErroBanco(`Falha ao salvar o arquivo "${entry.fileName}" no banco.`, up.error);
      return;
    }

    const ativo = entry.status !== 'ERRO';
    const ins = await supabase.from('importacoes').insert({
      id: entry.id,
      source_type: entry.sourceType,
      file_name: entry.fileName,
      status: entry.status,
      is_current: ativo,
      storage_path: path,
      log: entry,
      imported_at: entry.importedAt,
    });
    if (ins.error) {
      reportarErroBanco(`Falha ao registrar a importação de "${entry.fileName}".`, ins.error);
      return;
    }

    if (ativo) {
      // só o arquivo mais recente de cada origem fica "ativo"
      const upd = await supabase
        .from('importacoes')
        .update({ is_current: false })
        .eq('source_type', entry.sourceType)
        .eq('is_current', true)
        .neq('id', entry.id);
      if (upd.error) reportarErroBanco('Falha ao atualizar o arquivo ativo.', upd.error);
    }
  }

  /** "Limpar" na tela: o arquivo continua no histórico, mas deixa de ser carregado automaticamente. */
  public async desativarAtual(origem: ImportSourceType): Promise<void> {
    const { error } = await supabase
      .from('importacoes')
      .update({ is_current: false })
      .eq('source_type', origem)
      .eq('is_current', true);
    if (error) reportarErroBanco('Falha ao limpar o arquivo ativo.', error);
  }

  /** Apaga o histórico (e os arquivos) para TODA a equipe. */
  public async limparHistorico(): Promise<void> {
    const { data, error } = await supabase.from('importacoes').select('id, storage_path');
    if (error) {
      reportarErroBanco('Falha ao limpar o histórico.', error);
      return;
    }
    const paths = (data ?? []).map((r) => r.storage_path).filter((p): p is string => !!p);
    if (paths.length > 0) {
      const rm = await supabase.storage.from(BUCKET).remove(paths);
      if (rm.error) reportarErroBanco('Falha ao apagar arquivos do histórico.', rm.error);
    }
    const del = await supabase.from('importacoes').delete().neq('id', '');
    if (del.error) {
      reportarErroBanco('Falha ao limpar o histórico.', del.error);
      return;
    }
    this.inMemoryHistory = [];
  }

  // Parse Saída CSV & log
  public processarArquivoSaida(
    content: string,
    fileName: string,
    options: PersistOptions = {}
  ): ParseResult {
    const result = parseCSVString(content);

    const hasMissing = result.missingColumns.length > 0;
    const status: ImportStatus = hasMissing
      ? result.records.length > 0
        ? 'ATENCAO'
        : 'ERRO'
      : 'SUCESSO';

    const totalContabil = result.records.reduce((acc, r) => acc + (r.vlContabil || 0), 0);

    this.registrarImportacao({
      fileName,
      fileSizeBytes: content.length,
      sourceType: 'TOTVS_SAIDA',
      sourceLabel: 'TOTVS ERP (Notas de Saída)',
      totalRecords: result.totalRows,
      validRecords: result.records.length,
      invalidRecords: result.missingColumns.length,
      totalContabil,
      periodStart: result.minDateFormatted,
      periodEnd: result.maxDateFormatted,
      status,
      errors: result.missingColumns.map((col) => ({
        message: `Coluna esperada não identificada: ${col}`,
        severity: 'WARNING',
      })),
    }, content, options);

    return result;
  }

  // Parse Entrada TOTVS CSV & log
  public processarArquivoEntradaTotvs(
    content: string,
    fileName: string,
    options: PersistOptions = {}
  ): ParseResult {
    const result = parseCSVString(content);

    const hasMissing = result.missingColumns.length > 0;
    const status: ImportStatus = hasMissing
      ? result.records.length > 0
        ? 'ATENCAO'
        : 'ERRO'
      : 'SUCESSO';

    const totalContabil = result.records.reduce((acc, r) => acc + (r.vlContabil || 0), 0);

    this.registrarImportacao({
      fileName,
      fileSizeBytes: content.length,
      sourceType: 'TOTVS_ENTRADA',
      sourceLabel: 'TOTVS ERP (Notas de Entrada)',
      totalRecords: result.totalRows,
      validRecords: result.records.length,
      invalidRecords: result.missingColumns.length,
      totalContabil,
      periodStart: result.minDateFormatted,
      periodEnd: result.maxDateFormatted,
      status,
      errors: result.missingColumns.map((col) => ({
        message: `Coluna esperada não identificada: ${col}`,
        severity: 'WARNING',
      })),
    }, content, options);

    return result;
  }

  // Parse Qive SEFAZ CSV & log
  public processarArquivoQive(
    content: string,
    fileName: string,
    options: PersistOptions = {}
  ): QiveParseResult {
    const result = parseQiveCSVString(content);

    const status: ImportStatus = result.records.length > 0 ? 'SUCESSO' : 'ERRO';

    this.registrarImportacao({
      fileName,
      fileSizeBytes: content.length,
      sourceType: 'QIVE_SEFAZ',
      sourceLabel: 'Qive SEFAZ (Recebidas)',
      totalRecords: result.totalRows,
      validRecords: result.records.length,
      invalidRecords: 0,
      totalContabil: result.totalValue,
      status,
      errors: [],
    }, content, options);

    return result;
  }
}

export const importacaoService = new ImportacaoService();
