import React, { useState } from 'react';
import { ImportLogEntry } from '../types/importHistory';
import { importacaoService } from '../services/importacaoService';
import {
  History,
  FileSpreadsheet,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  FileCheck2,
  Calendar,
  Layers,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { EmptyState } from './common/EmptyState';
import { AlertBadge } from './common/AlertBadge';

interface ImportHistoryViewProps {
  logs: ImportLogEntry[];
  onRefreshLogs: () => void;
  onLoadDemoData: () => void;
}

export const ImportHistoryView: React.FC<ImportHistoryViewProps> = ({
  logs,
  onRefreshLogs,
  onLoadDemoData,
}) => {
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const handleClearHistory = async () => {
    if (
      window.confirm(
        'Deseja realmente apagar o histórico de importações e os arquivos salvos? Isso vale para TODA a equipe.'
      )
    ) {
      await importacaoService.limparHistorico();
      onRefreshLogs();
    }
  };

  const formatBRL = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const formatDate = (isoStr: string) => {
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoStr;
    }
  };

  const totalImportedRows = logs.reduce((acc, l) => acc + l.totalRecords, 0);
  const successCount = logs.filter((l) => l.status === 'SUCESSO').length;
  const warningCount = logs.filter((l) => l.status === 'ATENCAO' || l.status === 'ERRO').length;

  return (
    <div className="space-y-6">
      {/* Header & KPIs */}
      <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E2D9CE]">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#1E2D23] font-['Montserrat',sans-serif] flex items-center gap-2">
                <History className="w-5 h-5 text-[#8C6D4C]" />
                Histórico de Importações de Arquivos
              </h2>
              <span className="text-[10px] bg-[#FAF3EA] text-[#8C6D4C] border border-[#E8DCCB] font-bold px-2 py-0.5 rounded uppercase">
                Schema: import_history
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              Registro auditável de todos os lotes de arquivos processados pelo sistema (CSV, Excel e JSON).
            </p>
          </div>

          {logs.length > 0 && (
            <button
              onClick={handleClearHistory}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-lg transition-colors font-semibold"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Limpar Histórico</span>
            </button>
          )}
        </div>

        {/* 3 Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
          <div className="p-3.5 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
              Lotes Processados
            </span>
            <div className="text-2xl font-black text-[#1E2D23] font-mono">
              {logs.length}
            </div>
            <span className="text-[11px] text-neutral-500 mt-0.5 block">
              Arquivos registrados no ciclo
            </span>
          </div>

          <div className="p-3.5 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
              Registros Acumulados
            </span>
            <div className="text-2xl font-black text-[#1E2D23] font-mono">
              {totalImportedRows.toLocaleString('pt-BR')}
            </div>
            <span className="text-[11px] text-neutral-500 mt-0.5 block">
              Total de linhas processadas
            </span>
          </div>

          <div className="p-3.5 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
              Qualidade dos Lotes
            </span>
            <div className="flex items-center gap-3">
              <span className="text-sm font-bold text-emerald-800">
                🟢 {successCount} 100% OK
              </span>
              {warningCount > 0 && (
                <span className="text-sm font-bold text-amber-800">
                  🟡 {warningCount} c/ Alertas
                </span>
              )}
            </div>
            <span className="text-[11px] text-neutral-500 mt-0.5 block">
              Integridade dos dados validados
            </span>
          </div>
        </div>
      </div>

      {/* Logs Table */}
      {logs.length === 0 ? (
        <EmptyState
          title="Nenhuma importação registrada no histórico"
          description="Quando você fizer upload de arquivos de Saída ou Entradas, os logs com registros, data, integridade e possíveis erros serão registrados aqui."
          icon={History}
          actionButton={
            <button
              onClick={onLoadDemoData}
              className="px-4 py-2 bg-[#D5BEA4] hover:bg-[#C2A588] text-[#1E2D23] text-xs font-bold uppercase tracking-wider rounded-lg transition-all shadow-sm"
            >
              Carregar Arquivos de Teste
            </button>
          }
        />
      ) : (
        <div className="bg-white border border-[#E2D9CE] rounded-xl overflow-hidden shadow-xs">
          <div className="px-5 py-3 bg-[#FAF8F5] border-b border-[#E2D9CE] flex items-center justify-between text-xs text-neutral-600 font-bold">
            <span>Listagem de Importações Realizadas ({logs.length})</span>
            <span className="text-[11px] text-neutral-400 font-normal">
              Compatível com estrutura SQL: id, filename, imported_at, source_type, rows, status
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-[#1E2D23] text-[#FAF7F2] font-bold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">Data / Hora</th>
                  <th className="py-2.5 px-3">Arquivo / Lote</th>
                  <th className="py-2.5 px-3">Tipo de Documento</th>
                  <th className="py-2.5 px-3 text-right">Registros</th>
                  <th className="py-2.5 px-3 text-right">Valor Total</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3 text-center">Ocorrências</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2D9CE]/60">
                {logs.map((log) => {
                  const isExpanded = expandedLogId === log.id;
                  const hasErrors = log.errors && log.errors.length > 0;

                  return (
                    <React.Fragment key={log.id}>
                      <tr className="hover:bg-[#FAF8F5] transition-colors">
                        <td className="py-3 px-3 font-mono text-neutral-600 whitespace-nowrap">
                          {formatDate(log.importedAt)}
                        </td>

                        <td className="py-3 px-3">
                          <div className="font-bold text-[#1E2D23] flex items-center gap-1.5">
                            <FileSpreadsheet className="w-3.5 h-3.5 text-[#8C6D4C] shrink-0" />
                            <span className="truncate max-w-xs" title={log.fileName}>
                              {log.fileName}
                            </span>
                          </div>
                          <div className="text-[10px] text-neutral-400 font-mono">
                            ID: {log.id}
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span className="inline-block px-2 py-0.5 rounded bg-neutral-100 border border-neutral-300 font-bold text-neutral-800 text-[10px] uppercase">
                            {log.sourceLabel}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-right font-mono font-bold text-[#1E2D23]">
                          {log.totalRecords.toLocaleString('pt-BR')}
                        </td>

                        <td className="py-3 px-3 text-right font-mono text-neutral-800">
                          {formatBRL(log.totalContabil)}
                        </td>

                        <td className="py-3 px-3 text-center">
                          {log.status === 'SUCESSO' ? (
                            <AlertBadge severity="OK" label="Sucesso" size="sm" />
                          ) : log.status === 'ATENCAO' ? (
                            <AlertBadge severity="ATENCAO" label="Atenção" size="sm" />
                          ) : (
                            <AlertBadge severity="CRITICO" label="Erro" size="sm" />
                          )}
                        </td>

                        <td className="py-3 px-3 text-center">
                          {hasErrors ? (
                            <button
                              onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold text-amber-900 bg-amber-50 border border-amber-300 hover:bg-amber-100 transition-colors"
                            >
                              <span>{log.errors.length} avisos</span>
                              {isExpanded ? (
                                <ChevronUp className="w-3 h-3" />
                              ) : (
                                <ChevronDown className="w-3 h-3" />
                              )}
                            </button>
                          ) : (
                            <span className="text-neutral-400 text-[11px]">—</span>
                          )}
                        </td>
                      </tr>

                      {/* Expanded error log items */}
                      {isExpanded && hasErrors && (
                        <tr className="bg-amber-50/40">
                          <td colSpan={7} className="py-3 px-6">
                            <div className="text-xs font-bold text-amber-900 mb-1.5 flex items-center gap-1.5">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                              Ocorrências detectadas durante o processamento do arquivo:
                            </div>
                            <ul className="space-y-1 list-disc list-inside text-[11px] text-neutral-700 font-mono">
                              {log.errors.map((err, idx) => (
                                <li key={idx} className="break-all">
                                  {err.message}
                                </li>
                              ))}
                            </ul>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
