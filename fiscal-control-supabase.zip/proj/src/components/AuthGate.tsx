import React, { useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase, supabaseConfigurado, DB_ERROR_EVENT } from '../lib/supabase';
import { importacaoService } from '../services/importacaoService';
import { regrasService } from '../services/regrasService';
import App, { AppInitialData } from '../App';

const box: React.CSSProperties = {
  minHeight: '100vh',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  background: '#f8fafc',
  fontFamily: 'system-ui, sans-serif',
  padding: 16,
};
const card: React.CSSProperties = {
  background: '#fff',
  border: '1px solid #e2e8f0',
  borderRadius: 12,
  padding: 28,
  width: '100%',
  maxWidth: 380,
  boxShadow: '0 1px 3px rgba(0,0,0,.06)',
};
const input: React.CSSProperties = {
  width: '100%',
  padding: '10px 12px',
  border: '1px solid #cbd5e1',
  borderRadius: 8,
  marginTop: 6,
  marginBottom: 14,
  fontSize: 14,
  boxSizing: 'border-box',
};

export default function AuthGate() {
  const [session, setSession] = useState<Session | null>(null);
  const [checking, setChecking] = useState(true);
  const [initial, setInitial] = useState<AppInitialData | null>(null);
  const [dbError, setDbError] = useState<string | null>(null);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loggingIn, setLoggingIn] = useState(false);

  useEffect(() => {
    if (!supabaseConfigurado) {
      setChecking(false);
      return;
    }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setChecking(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  // Banner quando uma gravação no banco falha
  useEffect(() => {
    const h = (e: Event) => setDbError((e as CustomEvent<string>).detail);
    window.addEventListener(DB_ERROR_EVENT, h);
    return () => window.removeEventListener(DB_ERROR_EVENT, h);
  }, []);

  // Depois do login: carrega histórico, benefícios e os últimos arquivos importados
  const userId = session?.user.id;
  useEffect(() => {
    if (!userId) {
      setInitial(null);
      return;
    }
    let cancelado = false;
    (async () => {
      const [, , atuais] = await Promise.all([
        importacaoService.carregar(),
        regrasService.carregarBeneficios(),
        importacaoService.carregarAtuais(),
      ]);
      if (!cancelado) setInitial(atuais);
    })();
    return () => {
      cancelado = true;
    };
  }, [userId]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoggingIn(true);
    setLoginError('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setLoginError('E-mail ou senha incorretos.');
    setLoggingIn(false);
  };

  if (!supabaseConfigurado) {
    return (
      <div style={box}>
        <div style={card}>
          <h2 style={{ marginTop: 0 }}>Banco não configurado</h2>
          <p style={{ fontSize: 14, color: '#475569' }}>
            Defina <code>VITE_SUPABASE_URL</code> e <code>VITE_SUPABASE_ANON_KEY</code> (arquivo{' '}
            <code>.env.local</code> ou Environment Variables da Vercel) e faça um novo deploy.
          </p>
        </div>
      </div>
    );
  }

  if (checking) return <div style={box}>Carregando…</div>;

  if (!session) {
    return (
      <div style={box}>
        <form style={card} onSubmit={handleLogin}>
          <h2 style={{ marginTop: 0, marginBottom: 4 }}>Fiscal Control</h2>
          <p style={{ marginTop: 0, fontSize: 13, color: '#64748b' }}>Acesso restrito à equipe.</p>
          <label style={{ fontSize: 13 }}>
            E-mail
            <input
              style={input}
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="username"
              required
            />
          </label>
          <label style={{ fontSize: 13 }}>
            Senha
            <input
              style={input}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
            />
          </label>
          {loginError && <p style={{ color: '#b91c1c', fontSize: 13, marginTop: 0 }}>{loginError}</p>}
          <button
            type="submit"
            disabled={loggingIn}
            style={{
              width: '100%',
              padding: '10px 12px',
              background: '#0f172a',
              color: '#fff',
              border: 0,
              borderRadius: 8,
              fontSize: 14,
              cursor: 'pointer',
            }}
          >
            {loggingIn ? 'Entrando…' : 'Entrar'}
          </button>
        </form>
      </div>
    );
  }

  if (!initial) return <div style={box}>Carregando dados da equipe…</div>;

  return (
    <>
      {dbError && (
        <div
          role="alert"
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            zIndex: 9999,
            background: '#b91c1c',
            color: '#fff',
            padding: '8px 16px',
            fontSize: 13,
            display: 'flex',
            justifyContent: 'space-between',
          }}
        >
          <span>⚠ {dbError} Os dados podem não ter sido salvos.</span>
          <button
            onClick={() => setDbError(null)}
            style={{ background: 'none', border: 0, color: '#fff', cursor: 'pointer' }}
          >
            ✕
          </button>
        </div>
      )}
      <App initial={initial} />
      <div
        style={{
          position: 'fixed',
          bottom: 10,
          right: 12,
          zIndex: 9000,
          background: '#fff',
          border: '1px solid #e2e8f0',
          borderRadius: 999,
          padding: '4px 12px',
          fontSize: 12,
          color: '#475569',
          boxShadow: '0 1px 3px rgba(0,0,0,.08)',
        }}
      >
        {session.user.email} ·{' '}
        <button
          onClick={() => supabase.auth.signOut()}
          style={{ background: 'none', border: 0, color: '#0f172a', cursor: 'pointer', fontWeight: 600 }}
        >
          Sair
        </button>
      </div>
    </>
  );
}
