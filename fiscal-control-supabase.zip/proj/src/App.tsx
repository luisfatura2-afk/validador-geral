import React, { useState, useMemo } from 'react';
import { Header, FiscalModule } from './components/Header';
import { Sidebar, MainNavigationModule } from './components/Sidebar';
import { FileUploader } from './components/FileUploader';
import { KpiCards } from './components/KpiCards';
import { EmailSummaryCard } from './components/EmailSummaryCard';
import { AttentionPoints } from './components/AttentionPoints';
import { TaxAnalysisSection } from './components/TaxAnalysisSection';
import { CfopAnalysisTable } from './components/CfopAnalysisTable';
import { SituationAnalysis } from './components/SituationAnalysis';
import { ChartsSection } from './components/ChartsSection';
import { FilterBar } from './components/FilterBar';
import { InvoicesTable } from './components/InvoicesTable';
import { InvoiceDetailModal } from './components/InvoiceDetailModal';
import { HelpModal } from './components/HelpModal';
import { CentralDadosView } from './components/CentralDadosView';
import { ImportHistoryView } from './components/ImportHistoryView';
import { AuditEngineView } from './components/AuditEngineView';

// Reconciliation components & utilities
import { ReconciliationUploader } from './components/ReconciliationUploader';
import { ReconciliationKpiCards } from './components/ReconciliationKpiCards';
import { ReconciliationEmailCard } from './components/ReconciliationEmailCard';
import { ReconciliationAttentionPoints } from './components/ReconciliationAttentionPoints';
import { ReconciliationFilterBar } from './components/ReconciliationFilterBar';
import { ReconciliationTable } from './components/ReconciliationTable';
import { ReconciliationDetailModal } from './components/ReconciliationDetailModal';
import {
  ReconciledItem,
  ReconciliationFilterState,
} from './types/reconciliation';
import { parseQiveCSVString, QiveParseResult } from './utils/qiveParser';
import { reconcileQiveAndTotvs } from './utils/reconciliationEngine';
import { exportReconciliationToExcel } from './utils/reconciliationExporter';

// Fiscal types & utilities
import {
  InvoiceRecord,
  FilterState,
  CfopSummary,
  SituationSummary,
  TaxTotals,
} from './types/fiscal';
import { parseCSVString, ParseResult } from './utils/csvParser';
import { calculateAttentionPoints } from './utils/attentionRules';
import {
  exportAnalysisToExcel,
  exportFilteredInvoicesToExcel,
  generateEmailSummary,
} from './utils/exporter';
import {
  FileSpreadsheet,
  ShieldCheck,
  Zap,
  ArrowRightLeft,
  AlertOctagon,
  Activity,
  ChevronRight,
  BarChart3,
  Scale,
  Sparkles,
} from 'lucide-react';
import { IndicatorsDashboard } from './components/IndicatorsDashboard';
import {
  SAMPLE_TOTVS_SAIDAS_CSV,
  SAMPLE_QIVE_ENTRADAS_CSV,
  SAMPLE_TOTVS_ENTRADAS_CSV,
} from './utils/sampleData';
import { importacaoService } from './services/importacaoService';
import { notasService } from './services/notasService';
import { conciliacaoService } from './services/conciliacaoService';
import { regrasService } from './services/regrasService';

const INITIAL_FILTERS: FilterState = {
  dataInicio: '',
  dataFim: '',
  empresa: '',
  situacao: '',
  cfop: '',
  especie: '',
  serie: '',
  numeroNf: '',
  cdPessoa: '',
  nomePessoa: '',
  attentionFilter: undefined,
};

const INITIAL_RECONCILIATION_FILTERS: ReconciliationFilterState = {
  status: 'ALL',
  tipoDocumento: 'ALL',
  termoBusca: '',
  dataInicio: '',
  dataFim: '',
  manifestacao: 'ALL',
};

export interface AppInitialData {
  saida?: { result: ParseResult; fileName: string };
  qive?: { result: QiveParseResult; fileName: string };
  totvsEntrada?: { result: ParseResult; fileName: string };
}

export default function App({ initial }: { initial?: AppInitialData }) {
  // Active Module & Sidebar state
  const [activeModule, setActiveModule] = useState<FiscalModule>('DASHBOARD');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // ==========================================
  // STATE: NOTAS DE SAÍDA
  // ==========================================
  const [parseResult, setParseResult] = useState<ParseResult | null>(initial?.saida?.result ?? null);
  const [fileName, setFileName] = useState<string>(initial?.saida?.fileName ?? '');
  const [filters, setFilters] = useState<FilterState>(INITIAL_FILTERS);
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceRecord | null>(null);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [emailCopied, setEmailCopied] = useState(false);

  // ==========================================
  // STATE: CONCILIAÇÃO DE ENTRADAS (QIVE × TOTVS)
  // ==========================================
  const [qiveResult, setQiveResult] = useState<QiveParseResult | null>(initial?.qive?.result ?? null);
  const [qiveFileName, setQiveFileName] = useState<string>(initial?.qive?.fileName ?? '');
  const [totvsEntradaResult, setTotvsEntradaResult] = useState<ParseResult | null>(initial?.totvsEntrada?.result ?? null);
  const [totvsEntradaFileName, setTotvsEntradaFileName] = useState<string>(
    initial?.totvsEntrada?.fileName ?? ''
  );
  const [reconciliationFilters, setReconciliationFilters] =
    useState<ReconciliationFilterState>(INITIAL_RECONCILIATION_FILTERS);
  const [selectedReconciledItem, setSelectedReconciledItem] =
    useState<ReconciledItem | null>(null);

  // Import History State (Sync with importacaoService)
  const [importLogs, setImportLogs] = useState(() => importacaoService.listarHistorico());
  const refreshImportLogs = () => {
    setImportLogs(importacaoService.listarHistorico());
  };

  // Handlers for Saída
  const handleFileLoaded = (csvContent: string, loadedFileName: string) => {
    const result = importacaoService.processarArquivoSaida(csvContent, loadedFileName);
    setParseResult(result);
    setFileName(loadedFileName);
    setFilters(INITIAL_FILTERS);
    refreshImportLogs();
  };

  const handleResetData = () => {
    void importacaoService.desativarAtual('TOTVS_SAIDA');
    setParseResult(null);
    setFileName('');
    setFilters(INITIAL_FILTERS);
  };

  // Handlers for Entrada (Qive & TOTVS)
  const handleQiveLoaded = (content: string, name: string) => {
    const res = importacaoService.processarArquivoQive(content, name);
    setQiveResult(res);
    setQiveFileName(name);
    refreshImportLogs();
  };

  const handleClearQive = () => {
    void importacaoService.desativarAtual('QIVE_SEFAZ');
    setQiveResult(null);
    setQiveFileName('');
  };

  const handleTotvsEntradaLoaded = (content: string, name: string) => {
    const res = importacaoService.processarArquivoEntradaTotvs(content, name);
    setTotvsEntradaResult(res);
    setTotvsEntradaFileName(name);
    refreshImportLogs();
  };

  const handleClearTotvsEntrada = () => {
    void importacaoService.desativarAtual('TOTVS_ENTRADA');
    setTotvsEntradaResult(null);
    setTotvsEntradaFileName('');
  };

  const handleLoadDemoData = () => {
    const saidaRes = importacaoService.processarArquivoSaida(
      SAMPLE_TOTVS_SAIDAS_CSV,
      'TOTVS_SAIDAS_EXEMPLO.csv',
      { persist: false }
    );
    setParseResult(saidaRes);
    setFileName('TOTVS_SAIDAS_EXEMPLO.csv');

    const qive = importacaoService.processarArquivoQive(
      SAMPLE_QIVE_ENTRADAS_CSV,
      'Qive_SEFAZ_Entradas_Exemplo.csv',
      { persist: false }
    );
    setQiveResult(qive);
    setQiveFileName('Qive_SEFAZ_Entradas_Exemplo.csv');

    const totvsEntrada = importacaoService.processarArquivoEntradaTotvs(
      SAMPLE_TOTVS_ENTRADAS_CSV,
      'TOTVS_ENTRADAS_EXEMPLO.csv',
      { persist: false }
    );
    setTotvsEntradaResult(totvsEntrada);
    setTotvsEntradaFileName('TOTVS_ENTRADAS_EXEMPLO.csv');

    refreshImportLogs();
  };

  // ==========================================
  // RECONCILIATION ENGINE COMPUTATION
  // ==========================================
  const reconciliationData = useMemo(() => {
    const qiveRecords = qiveResult ? qiveResult.records : [];
    const totvsRecords = totvsEntradaResult ? totvsEntradaResult.records : [];
    return conciliacaoService.conciliar(qiveRecords, totvsRecords);
  }, [qiveResult, totvsEntradaResult]);

  // Filtered reconciled items
  const filteredReconciledItems = useMemo(() => {
    return conciliacaoService.filtrarItens(reconciliationData.items, reconciliationFilters);
  }, [reconciliationData.items, reconciliationFilters]);

  const hasReconciliationData = Boolean(qiveResult || totvsEntradaResult);

  // ==========================================
  // SAÍDA COMPUTATIONS
  // ==========================================
  const allRecords = parseResult ? parseResult.records : [];

  // Central de Dados consolidated documents
  const centralFiscalDocuments = useMemo(() => {
    return notasService.buildCentralDataRepository(
      allRecords,
      totvsEntradaResult?.records || [],
      qiveResult?.records || []
    );
  }, [allRecords, totvsEntradaResult, qiveResult]);

  const attentionPoints = useMemo(() => {
    return calculateAttentionPoints(allRecords);
  }, [allRecords]);

  const attentionAffectedIds = useMemo(() => {
    if (!filters.attentionFilter) return null;
    const point = attentionPoints.find((p) => p.filterKey === filters.attentionFilter);
    return point ? new Set(point.affectedIds) : null;
  }, [filters.attentionFilter, attentionPoints]);

  const filteredRecords = useMemo(() => {
    if (!parseResult) return [];

    return allRecords.filter((r) => {
      if (filters.dataInicio && r.dtEmissaoDate) {
        const filterStart = new Date(`${filters.dataInicio}T00:00:00`);
        if (r.dtEmissaoDate < filterStart) return false;
      }

      if (filters.dataFim && r.dtEmissaoDate) {
        const filterEnd = new Date(`${filters.dataFim}T23:59:59`);
        if (r.dtEmissaoDate > filterEnd) return false;
      }

      if (filters.empresa && r.empresa !== filters.empresa) return false;

      if (filters.situacao) {
        const s = (r.situacao || '').toLowerCase();
        const f = filters.situacao.toLowerCase();
        if (f === 'outras') {
          if (s.includes('autoriz') || s.includes('cancel') || s.includes('inutiliz')) {
            return false;
          }
        } else if (!s.includes(f)) {
          return false;
        }
      }

      if (filters.cfop && r.cfop !== filters.cfop) return false;
      if (filters.especie && r.especie !== filters.especie) return false;
      if (filters.serie && r.serie !== filters.serie) return false;
      if (filters.numeroNf && !r.notaFiscal.includes(filters.numeroNf.trim())) return false;
      if (filters.cdPessoa && !r.cdPessoa.toLowerCase().includes(filters.cdPessoa.toLowerCase().trim())) return false;
      if (filters.nomePessoa && !r.nomePessoa.toLowerCase().includes(filters.nomePessoa.toLowerCase().trim())) return false;

      if (attentionAffectedIds && !attentionAffectedIds.has(r.id)) return false;

      return true;
    });
  }, [allRecords, parseResult, filters, attentionAffectedIds]);

  const kpis = useMemo(() => {
    let totalCount = 0;
    let totalValue = 0;
    let authorizedCount = 0;
    let authorizedValue = 0;
    let canceledCount = 0;
    let canceledValue = 0;
    let inutilizedCount = 0;
    let otherCount = 0;
    let otherValue = 0;

    filteredRecords.forEach((r) => {
      totalCount++;
      totalValue += r.vlContabil;

      const s = (r.situacao || '').toLowerCase();
      if (s.includes('autoriz') || s.includes('emitida') || s.includes('normal')) {
        authorizedCount++;
        authorizedValue += r.vlContabil;
      } else if (s.includes('cancel')) {
        canceledCount++;
        canceledValue += r.vlContabil;
      } else if (s.includes('inutiliz')) {
        inutilizedCount++;
      } else {
        otherCount++;
        otherValue += r.vlContabil;
      }
    });

    return {
      totalCount,
      totalValue,
      authorizedCount,
      authorizedValue,
      canceledCount,
      canceledValue,
      inutilizedCount,
      otherCount,
      otherValue,
    };
  }, [filteredRecords]);

  const taxTotals = useMemo<TaxTotals>(() => {
    return filteredRecords.reduce(
      (acc, r) => {
        acc.icms += r.vlIcms;
        acc.baseIcms += r.vlBaseIcms;
        acc.isentoIcms += r.vlIsentoIcms;
        acc.outroIcms += r.vlOutroIcms;
        acc.icmsSt += r.vlIcmsSt;
        acc.ipi += r.vlIpi;
        acc.pis += r.vlPis;
        acc.cofins += r.vlCofins;
        acc.fcp += r.vlFcp;
        acc.fcpSt += r.vlFcpSt;
        acc.ibs += r.vlIbs;
        acc.cbs += r.vlCbs;
        acc.is += r.vlIs;
        return acc;
      },
      {
        icms: 0,
        baseIcms: 0,
        isentoIcms: 0,
        outroIcms: 0,
        icmsSt: 0,
        ipi: 0,
        pis: 0,
        cofins: 0,
        fcp: 0,
        fcpSt: 0,
        ibs: 0,
        cbs: 0,
        is: 0,
      }
    );
  }, [filteredRecords]);

  // Aggregate tax credits from Entradas (TOTVS or Qive SEFAZ)
  const entradaTaxTotals = useMemo<TaxTotals>(() => {
    if (totvsEntradaResult && totvsEntradaResult.records.length > 0) {
      return totvsEntradaResult.records.reduce(
        (acc, r) => {
          acc.icms += r.vlIcms || 0;
          acc.baseIcms += r.vlBaseIcms || 0;
          acc.isentoIcms += r.vlIsentoIcms || 0;
          acc.outroIcms += r.vlOutroIcms || 0;
          acc.icmsSt += r.vlIcmsSt || 0;
          acc.ipi += r.vlIpi || 0;
          acc.pis += r.vlPis || 0;
          acc.cofins += r.vlCofins || 0;
          acc.fcp += r.vlFcp || 0;
          acc.fcpSt += r.vlFcpSt || 0;
          acc.ibs += r.vlIbs || 0;
          acc.cbs += r.vlCbs || 0;
          acc.is += r.vlIs || 0;
          return acc;
        },
        {
          icms: 0,
          baseIcms: 0,
          isentoIcms: 0,
          outroIcms: 0,
          icmsSt: 0,
          ipi: 0,
          pis: 0,
          cofins: 0,
          fcp: 0,
          fcpSt: 0,
          ibs: 0,
          cbs: 0,
          is: 0,
        }
      );
    }

    if (qiveResult && qiveResult.records.length > 0) {
      const totals: TaxTotals = {
        icms: 0,
        baseIcms: 0,
        isentoIcms: 0,
        outroIcms: 0,
        icmsSt: 0,
        ipi: 0,
        pis: 0,
        cofins: 0,
        fcp: 0,
        fcpSt: 0,
        ibs: 0,
        cbs: 0,
        is: 0,
      };

      qiveResult.records.forEach((r) => {
        totals.icms += r.valorIcms || 0;
        totals.baseIcms += r.valorBaseIcms || 0;
        totals.icmsSt += r.valorIcmsSt || 0;
        totals.ipi += r.valorIpi || 0;
        totals.pis += r.valorPis || 0;
        totals.cofins += r.valorCofins || 0;
      });

      return totals;
    }

    return {
      icms: 0,
      baseIcms: 0,
      isentoIcms: 0,
      outroIcms: 0,
      icmsSt: 0,
      ipi: 0,
      pis: 0,
      cofins: 0,
      fcp: 0,
      fcpSt: 0,
      ibs: 0,
      cbs: 0,
      is: 0,
    };
  }, [totvsEntradaResult, qiveResult]);

  const hasEntradaDataForTaxes = Boolean(
    (totvsEntradaResult && totvsEntradaResult.records.length > 0) ||
    (qiveResult && qiveResult.records.length > 0)
  );

  const entradaSourceLabel = useMemo(() => {
    if (totvsEntradaResult && totvsEntradaResult.records.length > 0) {
      return `TOTVS Entradas (${totvsEntradaResult.records.length} notas)`;
    }
    if (qiveResult && qiveResult.records.length > 0) {
      return `Qive SEFAZ (${qiveResult.records.length} notas)`;
    }
    return '';
  }, [totvsEntradaResult, qiveResult]);

  const cfopSummaries = useMemo<CfopSummary[]>(() => {
    const map = new Map<string, CfopSummary>();

    filteredRecords.forEach((r) => {
      const code = r.cfop || 'SEM_CFOP';
      const existing = map.get(code) || {
        cfop: code,
        count: 0,
        vlContabil: 0,
        vlIcms: 0,
        vlPis: 0,
        vlCofins: 0,
        vlIbs: 0,
        vlCbs: 0,
      };

      existing.count += 1;
      existing.vlContabil += r.vlContabil;
      existing.vlIcms += r.vlIcms;
      existing.vlPis += r.vlPis;
      existing.vlCofins += r.vlCofins;
      existing.vlIbs += r.vlIbs;
      existing.vlCbs += r.vlCbs;

      map.set(code, existing);
    });

    return Array.from(map.values()).sort((a, b) => b.vlContabil - a.vlContabil);
  }, [filteredRecords]);

  const situationSummaries = useMemo<SituationSummary[]>(() => {
    const map = new Map<string, { count: number; vlContabil: number }>();
    let total = 0;

    filteredRecords.forEach((r) => {
      const sit = r.situacao || 'Não informada';
      const current = map.get(sit) || { count: 0, vlContabil: 0 };
      current.count += 1;
      current.vlContabil += r.vlContabil;
      map.set(sit, current);
      total += 1;
    });

    return Array.from(map.entries())
      .map(([situacao, data]) => ({
        situacao,
        count: data.count,
        vlContabil: data.vlContabil,
        percentage: total > 0 ? (data.count / total) * 100 : 0,
      }))
      .sort((a, b) => b.count - a.count);
  }, [filteredRecords]);

  const { minDateFormatted, maxDateFormatted, periodStr } = useMemo(() => {
    if (activeModule === 'ENTRADA') {
      const qiveCount = qiveResult ? qiveResult.totalRows : 0;
      const totvsCount = totvsEntradaResult ? totvsEntradaResult.totalRows : 0;
      return {
        minDateFormatted: 'Início',
        maxDateFormatted: 'Fim',
        periodStr: `${qiveCount} Qive • ${totvsCount} TOTVS`,
      };
    }

    if (!parseResult || allRecords.length === 0) {
      return {
        minDateFormatted: 'Início',
        maxDateFormatted: 'Fim',
        periodStr: 'Nenhum arquivo carregado',
      };
    }

    const dates = allRecords
      .map((r) => r.dtEmissaoDate)
      .filter((d): d is Date => Boolean(d))
      .sort((a, b) => a.getTime() - b.getTime());

    if (dates.length === 0) {
      return {
        minDateFormatted: 'Início',
        maxDateFormatted: 'Fim',
        periodStr: 'Período não identificado',
      };
    }

    const minDate = dates[0].toLocaleDateString('pt-BR');
    const maxDate = dates[dates.length - 1].toLocaleDateString('pt-BR');

    return {
      minDateFormatted: minDate,
      maxDateFormatted: maxDate,
      periodStr: minDate === maxDate ? minDate : `${minDate} a ${maxDate}`,
    };
  }, [activeModule, qiveResult, totvsEntradaResult, parseResult, allRecords]);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.dataInicio) count++;
    if (filters.dataFim) count++;
    if (filters.empresa) count++;
    if (filters.situacao) count++;
    if (filters.cfop) count++;
    if (filters.especie) count++;
    if (filters.serie) count++;
    if (filters.numeroNf) count++;
    if (filters.cdPessoa) count++;
    if (filters.nomePessoa) count++;
    if (filters.attentionFilter) count++;
    return count;
  }, [filters]);

  // Export handlers
  const handleExportExcelSaida = () => {
    if (!parseResult) return;
    exportAnalysisToExcel(
      allRecords,
      cfopSummaries,
      situationSummaries,
      taxTotals,
      periodStr
    );
  };

  const handleCopyEmailSaida = async () => {
    const email = generateEmailSummary(
      minDateFormatted,
      maxDateFormatted,
      kpis.totalCount,
      kpis.authorizedCount,
      kpis.authorizedValue,
      kpis.canceledCount,
      kpis.inutilizedCount,
      kpis.otherCount
    );
    try {
      await navigator.clipboard.writeText(email);
      setEmailCopied(true);
      setTimeout(() => setEmailCopied(false), 3000);
    } catch {
      setEmailCopied(false);
    }
  };

  const handleExportReconciliationExcel = () => {
    exportReconciliationToExcel(filteredReconciledItems, reconciliationData.kpis);
  };

  return (
    <div className="min-h-screen bg-[#F7F5F0] text-[#1E2D23] font-['Plus_Jakarta_Sans',sans-serif] flex flex-col">
      {/* Universal Top Header with Module Switcher */}
      <Header
        activeModule={activeModule}
        onSelectModule={setActiveModule}
        periodStr={periodStr}
        totalRecords={activeModule === 'SAIDA' ? allRecords.length : reconciliationData.items.length}
        filteredCount={activeModule === 'SAIDA' ? filteredRecords.length : filteredReconciledItems.length}
        onExportExcel={activeModule === 'SAIDA' ? handleExportExcelSaida : handleExportReconciliationExcel}
        onCopyEmail={handleCopyEmailSaida}
        onResetData={handleResetData}
        onOpenHelp={() => setIsHelpOpen(true)}
        onLoadDemoData={handleLoadDemoData}
        onToggleSidebar={() => setIsMobileSidebarOpen((prev) => !prev)}
        emailCopied={emailCopied}
        hasData={activeModule === 'SAIDA' ? Boolean(parseResult) : hasReconciliationData}
      />

      {/* Main Layout Container with Sidebar */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Mobile Backdrop */}
        {isMobileSidebarOpen && (
          <div
            onClick={() => setIsMobileSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-20 sm:hidden"
          />
        )}

        {/* Sidebar */}
        <div
          className={`fixed inset-y-0 left-0 z-30 sm:static sm:z-auto transition-transform duration-200 ${
            isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full sm:translate-x-0'
          }`}
        >
          <Sidebar
            currentModule={activeModule}
            onSelectModule={(mod) => {
              setActiveModule(mod);
              setIsMobileSidebarOpen(false);
            }}
            isCollapsed={isSidebarCollapsed}
            onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
            onOpenHelp={() => setIsHelpOpen(true)}
            saidaCount={allRecords.length}
            entradaCount={totvsEntradaResult?.records.length || 0}
            reconciledCount={reconciliationData.items.length}
            historyCount={importLogs.length}
          />
        </div>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto max-w-full px-4 sm:px-6 lg:px-8 py-6">
        {/* ========================================================================= */}
        {/* MODULE 1: CONCILIAÇÃO DE ENTRADAS (QIVE SEFAZ × TOTVS ERP)               */}
        {/* ========================================================================= */}
        {activeModule === 'ENTRADA' && (
          <div>
            {/* Hero Introduction for Entrada */}
            <div className="text-center max-w-3xl mx-auto mb-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#FAF8F5] border border-[#E2D9CE] rounded-full text-xs font-bold text-[#1E2D23] uppercase tracking-wider mb-3">
                <span className="w-1.5 h-1.5 rounded-full bg-[#8C6D4C]" />
                <span>Módulo de Conciliação e Auditoria de Entradas</span>
              </div>
              <h1 className="font-['Cormorant_Garamond',serif] text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1E2D23] mb-3">
                Cruzamento Qive (SEFAZ) × TOTVS (ERP)
              </h1>
              <p className="text-sm sm:text-base text-neutral-600 max-w-2xl mx-auto leading-relaxed">
                Importe o relatório avançado do <strong>Qive</strong> (documentos emitidos por fornecedores na SEFAZ)
                e o relatório de entradas do <strong>TOTVS</strong>. O sistema realiza a conciliação instantânea pela{' '}
                <strong>Chave de Acesso</strong>, apontando notas pendentes de escrituração e divergências de valores.
              </p>
            </div>

            {/* Dual Uploader for Qive and TOTVS */}
            <ReconciliationUploader
              qiveResult={qiveResult}
              qiveFileName={qiveFileName}
              onQiveLoaded={handleQiveLoaded}
              onClearQive={handleClearQive}
              totvsResult={totvsEntradaResult}
              totvsFileName={totvsEntradaFileName}
              onTotvsLoaded={handleTotvsEntradaLoaded}
              onClearTotvs={handleClearTotvsEntrada}
            />

            {/* Empty State Concept Cards if neither file loaded */}
            {!hasReconciliationData && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-6">
                <div className="bg-white border border-[#E2D9CE] rounded-lg p-5 shadow-xs">
                  <div className="w-9 h-9 rounded bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#8C6D4C] mb-3">
                    <ArrowRightLeft className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wider mb-1 font-['Montserrat',sans-serif]">
                    1. Cruzamento por Chave de Acesso
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Comparação de 44 dígitos sem margem para erro humano. Descubra imediatamente quais notas
                    já foram escrituradas no TOTVS e quais faltam lançar.
                  </p>
                </div>

                <div className="bg-white border border-[#E2D9CE] rounded-lg p-5 shadow-xs">
                  <div className="w-9 h-9 rounded bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#8C6D4C] mb-3">
                    <AlertOctagon className="w-4 h-4 text-[#8F3E35]" />
                  </div>
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wider mb-1 font-['Montserrat',sans-serif]">
                    2. Rastreamento de Pendências
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Identifique notas autorizadas no seu CNPJ que ainda não entraram no estoque ou no financeiro,
                    evitando perda de prazos de manifestação e fechamento contábil.
                  </p>
                </div>

                <div className="bg-white border border-[#E2D9CE] rounded-lg p-5 shadow-xs">
                  <div className="w-9 h-9 rounded bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#8C6D4C] mb-3">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wider mb-1 font-['Montserrat',sans-serif]">
                    3. Relatório Pronto em Excel
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Exporte a conciliação completa dividida em abas (Falta Lançar, Divergências, Conciliadas)
                    para cobrança rápida da equipe de compras e almoxarifado.
                  </p>
                </div>
              </div>
            )}

            {/* Reconciliation Dashboard when data is present */}
            {hasReconciliationData && (
              <>
                {/* Executive Indicator Banner */}
                <div className="bg-[#1E2D23] text-[#FAF7F2] rounded-xl p-4 sm:p-5 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs border border-[#334D3C]">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4] shrink-0">
                      <Activity className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-[#FAF7F2] font-['Montserrat',sans-serif] uppercase tracking-wide">
                        Painel Executivo de Indicadores
                      </h4>
                      <p className="text-xs text-[#C2B7A3]">
                        Acompanhe a Taxa de Conciliação, Top Fornecedores com Pendências, Funil Fiscal e Score de Conformidade.
                      </p>
                    </div>
                  </div>
                  <button
                    id="btn-goto-indicadores-from-reconcile"
                    onClick={() => setActiveModule('DASHBOARD')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded bg-[#D5BEA4] hover:bg-[#C2A588] text-[#1E2D23] uppercase tracking-wider transition-all shrink-0 active:scale-98"
                  >
                    <span>Ver Painel de Indicadores</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Top KPIs */}
                <ReconciliationKpiCards
                  kpis={reconciliationData.kpis}
                  activeStatusFilter={reconciliationFilters.status}
                  onSelectStatusFilter={(st) =>
                    setReconciliationFilters({ ...reconciliationFilters, status: st })
                  }
                />

                {/* Email Summary Card */}
                <ReconciliationEmailCard
                  kpis={reconciliationData.kpis}
                  items={reconciliationData.items}
                />

                {/* Attention Points */}
                <ReconciliationAttentionPoints
                  items={reconciliationData.items}
                  kpis={reconciliationData.kpis}
                  onFilterClick={(type, val) => {
                    if (type === 'status') {
                      setReconciliationFilters({ ...reconciliationFilters, status: val });
                    } else if (type === 'tipoDocumento') {
                      setReconciliationFilters({ ...reconciliationFilters, tipoDocumento: val });
                    }
                  }}
                />

                {/* Filter Bar */}
                <ReconciliationFilterBar
                  filters={reconciliationFilters}
                  onFilterChange={setReconciliationFilters}
                  onResetFilters={() => setReconciliationFilters(INITIAL_RECONCILIATION_FILTERS)}
                  onExportExcel={handleExportReconciliationExcel}
                  totalFiltered={filteredReconciledItems.length}
                  totalItems={reconciliationData.items.length}
                />

                {/* Comparison Table */}
                <ReconciliationTable
                  items={filteredReconciledItems}
                  onSelectItem={setSelectedReconciledItem}
                />
              </>
            )}

            {/* Side-by-Side Audit Modal */}
            <ReconciliationDetailModal
              item={selectedReconciledItem}
              onClose={() => setSelectedReconciledItem(null)}
            />
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODULE 2: NOTAS DE SAÍDA (TOTVS)                                         */}
        {/* ========================================================================= */}
        {activeModule === 'SAIDA' && (
          <div>
            {!parseResult && (
              <div className="text-center max-w-3xl mx-auto mb-8">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#FAF8F5] border border-[#E2D9CE] rounded-full text-xs font-bold text-[#1E2D23] uppercase tracking-wider mb-3">
                  <span className="w-1 h-1 rounded-full bg-[#8C6D4C]" />
                  <span>Conferência de Notas Fiscais de Saída</span>
                </div>
                <h1 className="font-['Cormorant_Garamond',serif] text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1E2D23] mb-3">
                  Auditoria e Conferência de Saídas
                </h1>
                <p className="text-sm sm:text-base text-neutral-600 max-w-2xl mx-auto leading-relaxed">
                  Importe a planilha CSV de notas de saída com as 26 colunas padrão geradas pelo ERP. O processamento é
                  realizado 100% no seu navegador com sigilo total.
                </p>
              </div>
            )}

            {/* File Uploader / Status */}
            <FileUploader
              onFileLoaded={handleFileLoaded}
              lastParseResult={parseResult}
              currentFileName={fileName}
              hasData={Boolean(parseResult)}
            />

            {!parseResult && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-8">
                <div className="bg-white border border-[#E2D9CE] rounded-lg p-5 shadow-xs">
                  <div className="w-9 h-9 rounded bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#8C6D4C] mb-3">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wider mb-1 font-['Montserrat',sans-serif]">
                    1. Mapeamento Automático
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Leitura precisa das 26 colunas padrão: Empresa, Situação, Dt. emissão, Nota fiscal, CFOP,
                    valores contábeis e tributos federais/estaduais.
                  </p>
                </div>

                <div className="bg-white border border-[#E2D9CE] rounded-lg p-5 shadow-xs">
                  <div className="w-9 h-9 rounded bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#8C6D4C] mb-3">
                    <Zap className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wider mb-1 font-['Montserrat',sans-serif]">
                    2. Diagnóstico & Pontos de Atenção
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Identificação automática de notas sem valor, notas canceladas, alíquotas zeradas,
                    chaves ausentes e agrupamentos por código CFOP.
                  </p>
                </div>

                <div className="bg-white border border-[#E2D9CE] rounded-lg p-5 shadow-xs">
                  <div className="w-9 h-9 rounded bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#8C6D4C] mb-3">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wider mb-1 font-['Montserrat',sans-serif]">
                    3. Segurança & Exportação
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Gere resumos executivos formatados para e-mail corporativo e exporte relatórios consolidados em
                    planilha Excel em apenas um clique.
                  </p>
                </div>
              </div>
            )}

            {parseResult && (
              <>
                <KpiCards
                  totalCount={kpis.totalCount}
                  authorizedCount={kpis.authorizedCount}
                  authorizedValue={kpis.authorizedValue}
                  canceledCount={kpis.canceledCount}
                  canceledValue={kpis.canceledValue}
                  inutilizedCount={kpis.inutilizedCount}
                  otherCount={kpis.otherCount}
                  otherValue={kpis.otherValue}
                  totalValue={kpis.totalValue}
                  selectedSituationFilter={filters.situacao}
                  onSelectSituation={(sit) => setFilters({ ...filters, situacao: sit })}
                />

                <EmailSummaryCard
                  minDateFormatted={minDateFormatted}
                  maxDateFormatted={maxDateFormatted}
                  totalNotes={kpis.totalCount}
                  authorizedCount={kpis.authorizedCount}
                  authorizedTotalValue={kpis.authorizedValue}
                  canceledCount={kpis.canceledCount}
                  inutilizedCount={kpis.inutilizedCount}
                  otherCount={kpis.otherCount}
                />

                <AttentionPoints
                  attentionPoints={attentionPoints}
                  activeAttentionFilter={filters.attentionFilter}
                  onSelectAttentionFilter={(filterKey) =>
                    setFilters({
                      ...filters,
                      attentionFilter: filters.attentionFilter === filterKey ? undefined : filterKey,
                    })
                  }
                />

                <TaxAnalysisSection
                  taxTotals={taxTotals}
                  totalContabil={kpis.totalValue}
                  creditoTaxTotals={entradaTaxTotals}
                  hasEntradaData={hasEntradaDataForTaxes}
                  entradaSourceLabel={entradaSourceLabel}
                  onNavigateToEntrada={() => setActiveModule('ENTRADA')}
                  onLoadDemoData={handleLoadDemoData}
                />

                <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 mb-8 items-start">
                  <div className="xl:col-span-7">
                    <CfopAnalysisTable
                      cfopSummaries={cfopSummaries}
                      selectedCfop={filters.cfop}
                      onSelectCfop={(cfop) => setFilters({ ...filters, cfop })}
                    />
                  </div>
                  <div className="xl:col-span-5">
                    <SituationAnalysis
                      situationSummaries={situationSummaries}
                      totalNotes={filteredRecords.length}
                      selectedSituation={filters.situacao}
                      onSelectSituation={(situacao) => setFilters({ ...filters, situacao })}
                    />
                  </div>
                </div>

                <ChartsSection
                  records={filteredRecords}
                  cfopSummaries={cfopSummaries}
                />

                <FilterBar
                  filters={filters}
                  onFilterChange={setFilters}
                  onResetFilters={() => setFilters(INITIAL_FILTERS)}
                  allRecords={allRecords}
                  activeFilterCount={activeFilterCount}
                />

                <InvoicesTable
                  records={filteredRecords}
                  onSelectInvoice={setSelectedInvoice}
                  onExportExcel={() => exportFilteredInvoicesToExcel(filteredRecords)}
                />

                <InvoiceDetailModal
                  invoice={selectedInvoice}
                  onClose={() => setSelectedInvoice(null)}
                />
              </>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODULE 3: DASHBOARD EXECUTIVO & INDICADORES ESTRATÉGICOS                   */}
        {/* ========================================================================= */}
        {(activeModule === 'DASHBOARD' || (activeModule as string) === 'INDICADORES') && (
          <IndicatorsDashboard
            saidaRecords={allRecords}
            saidaTaxTotals={taxTotals}
            entradaTaxTotals={entradaTaxTotals}
            cfopSummaries={cfopSummaries}
            situationSummaries={situationSummaries}
            saidaFileName={fileName}
            hasSaidaData={Boolean(parseResult)}
            reconciliationItems={reconciliationData.items}
            reconciliationKpis={reconciliationData.kpis}
            qiveFileName={qiveFileName}
            totvsEntradaFileName={totvsEntradaFileName}
            hasEntradaData={hasReconciliationData}
            onNavigateToModule={(mod) => setActiveModule(mod === 'INDICADORES' ? 'DASHBOARD' : mod)}
            onLoadSampleData={handleLoadDemoData}
          />
        )}

        {/* ========================================================================= */}
        {/* MODULE 4: APURAÇÃO FISCAL CONSOLIDADA (DÉBITO - CRÉDITO)                   */}
        {/* ========================================================================= */}
        {activeModule === 'APURACAO' && (
          <div className="space-y-6">
            <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E2D9CE]">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-[#1E2D23] font-['Montserrat',sans-serif] flex items-center gap-2">
                      <Scale className="w-5 h-5 text-[#8C6D4C]" />
                      Demonstrativo Consolidado de Apuração Fiscal
                    </h2>
                    <span className="text-[10px] bg-[#FAF3EA] text-[#8C6D4C] border border-[#E8DCCB] font-bold px-2 py-0.5 rounded uppercase">
                      Não-Cumulatividade
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 mt-1">
                    Cálculo rigoroso de <strong>Débito (Saídas faturadas no TOTVS)</strong> menos{' '}
                    <strong>Crédito (Entradas comprovadas na SEFAZ e escrituradas)</strong> para ICMS, PIS, COFINS e projeção de IBS/CBS.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleLoadDemoData}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF8F5] hover:bg-[#FAF3EA] border border-[#E2D9CE] rounded-lg text-xs font-bold text-[#1E2D23] transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#8C6D4C]" />
                    <span>Recarregar Dados Demo</span>
                  </button>
                </div>
              </div>
            </div>

            <TaxAnalysisSection
              taxTotals={taxTotals}
              totalContabil={kpis.totalValue}
              creditoTaxTotals={entradaTaxTotals}
              hasEntradaData={hasEntradaDataForTaxes}
              entradaSourceLabel={entradaSourceLabel}
              onNavigateToEntrada={() => setActiveModule('ENTRADA')}
              onLoadDemoData={handleLoadDemoData}
            />
          </div>
        )}

        {/* ========================================================================= */}
        {/* MODULE 5: CENTRAL UNIFICADA DE DADOS FISCAIS                              */}
        {/* ========================================================================= */}
        {activeModule === 'CENTRAL_DADOS' && (
          <CentralDadosView
            documents={centralFiscalDocuments}
            onLoadDemoData={handleLoadDemoData}
            onNavigateToModule={(mod) => setActiveModule(mod)}
            onSelectDocument={(doc) => {
              const foundSaida = allRecords.find(
                (r) => r.id === doc.id || r.chaveAcesso === doc.chaveAcesso
              );
              if (foundSaida) {
                setSelectedInvoice(foundSaida);
              }
            }}
          />
        )}

        {/* ========================================================================= */}
        {/* MODULE 6: MOTOR DE AUDITORIA & CONFORMIDADE FISCAL                         */}
        {/* ========================================================================= */}
        {activeModule === 'AUDITORIA' && (
          <AuditEngineView
            records={allRecords}
            onSelectInvoice={(inv) => {
              setSelectedInvoice(inv);
              setActiveModule('SAIDA');
            }}
            onLoadDemoData={handleLoadDemoData}
          />
        )}

        {/* ========================================================================= */}
        {/* MODULE 7: HISTÓRICO DE IMPORTAÇÕES                                        */}
        {/* ========================================================================= */}
        {activeModule === 'HISTORICO' && (
          <ImportHistoryView
            logs={importLogs}
            onRefreshLogs={refreshImportLogs}
            onLoadDemoData={handleLoadDemoData}
          />
        )}
      </main>
    </div>

      {/* Global Help Modal */}
      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />

      {/* TXC Brand Footer */}
      <footer className="bg-[#1E2D23] text-[#FAF7F2] border-t border-[#2A3F31] py-8 mt-12 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-xl font-black tracking-tighter text-[#E8DEC8] font-['Montserrat',sans-serif]">
              TXC
            </span>
            <span className="text-neutral-500">|</span>
            <span className="text-[#C2B7A3]">
              Fiscal Control • Sistema de Auditoria de Saídas e Conciliação de Entradas (Qive × TOTVS)
            </span>
          </div>

          <div className="flex items-center gap-4 text-[#A39989]">
            <span>Sigilo 100% no Navegador</span>
            <span>•</span>
            <span>Cruzamento por Chave de Acesso (44 dígitos)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
