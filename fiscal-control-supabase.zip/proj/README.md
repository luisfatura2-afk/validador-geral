# Fiscal Control — Análise de Notas de Saída

React + Vite + Supabase (login + Postgres + Storage). Dados compartilhados pela equipe.

## 1. Criar o banco (Supabase, plano gratuito serve)
1. Crie um projeto em https://supabase.com (região **South America (São Paulo)**).
2. **SQL Editor → New query**: cole o conteúdo de `supabase/schema.sql` e rode.
3. **Authentication → Sign In / Providers → Email**: **desative "Allow new users to sign up"**
   (senão qualquer pessoa com o link consegue criar conta e ler os dados).
4. **Authentication → Users → Add user → Create new user**: crie cada pessoa da equipe (e-mail + senha, marque "Auto Confirm").
5. **Project Settings → API**: copie a *Project URL* e a *anon public key*
   (**nunca** use a `service_role`).

## 2. Variáveis de ambiente
- Local: copie `.env.example` para `.env.local` e preencha.
- Vercel: **Settings → Environment Variables** → `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` → faça Redeploy.

## 3. Rodar
```
npm install
npm run dev
```

## O que fica no banco
| Dado | Onde |
|---|---|
| Histórico de importações | tabela `importacoes` |
| Arquivos CSV importados (saída, Qive, TOTVS entrada) | bucket privado `importacoes` |
| Benefícios fiscais | tabela `beneficios_fiscais` |

A conciliação Qive × TOTVS é recalculada a partir dos arquivos salvos ao abrir o sistema.
Dados de demonstração **não** são gravados no banco.
