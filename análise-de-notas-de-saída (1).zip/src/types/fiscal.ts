export interface RawInvoiceRow {
  [key: string]: string | undefined;
}

export interface InvoiceRecord {
  id: string; // generated index or unique row id
  // 26 standard columns:
  empresa: string;
  situacao: string;
  dtEmissao: string; // original string e.g. "12/03/2024"
  dtSaidaEntrada: string;
  especie: string;
  notaFiscal: string;
  serie: string;
  cdPessoa: string;
  nomePessoa: string;
  cfop: string;
  vlContabil: number;
  vlContabilRaw: string;
  aliqIcms: number;
  aliqIcmsRaw: string;
  vlBaseIcms: number;
  vlBaseIcmsRaw: string;
  vlIcms: number;
  vlIcmsRaw: string;
  vlIsentoIcms: number;
  vlIsentoIcmsRaw: string;
  vlOutroIcms: number;
  vlOutroIcmsRaw: string;
  vlIpi: number;
  vlIpiRaw: string;
  vlIcmsSt: number;
  vlIcmsStRaw: string;
  vlPis: number;
  vlPisRaw: string;
  vlCofins: number;
  vlCofinsRaw: string;
  vlFcp: number;
  vlFcpRaw: string;
  vlFcpSt: number;
  vlFcpStRaw: string;
  vlIbs: number;
  vlIbsRaw: string;
  vlCbs: number;
  vlCbsRaw: string;
  vlIs: number;
  vlIsRaw: string;
  chaveAcesso: string;

  // Parsed Date object for filtering & sorting (if valid)
  dtEmissaoDate?: Date;
  dtSaidaEntradaDate?: Date;

  // Raw row preserved intact
  rawRow: Record<string, string>;
}

export interface FilterState {
  dataInicio: string;
  dataFim: string;
  empresa: string;
  situacao: string;
  cfop: string;
  especie: string;
  serie: string;
  numeroNf: string;
  cdPessoa: string;
  nomePessoa: string;
  attentionFilter?: string; // e.g. "SEM_CFOP", "DUP_CHAVE", etc.
}

export interface AttentionPoint {
  id: string;
  title: string;
  term: 'Verificar' | 'Possível inconsistência' | 'Campo não informado';
  description: string;
  count: number;
  severity: 'warning' | 'info' | 'critical';
  filterKey: string;
  affectedIds: string[];
}

export interface CfopSummary {
  cfop: string;
  count: number;
  vlContabil: number;
  vlIcms: number;
  vlPis: number;
  vlCofins: number;
  vlIbs: number;
  vlCbs: number;
}

export interface SituationSummary {
  situacao: string;
  count: number;
  percentage: number;
  vlContabil: number;
}

export interface TaxTotals {
  icms: number;
  baseIcms: number;
  isentoIcms: number;
  outroIcms: number;
  icmsSt: number;
  ipi: number;
  pis: number;
  cofins: number;
  fcp: number;
  fcpSt: number;
  ibs: number;
  cbs: number;
  is: number;
}

export interface TaxAssessmentItem {
  code: string;
  name: string;
  category: 'ESTADUAL' | 'FEDERAL' | 'REFORMA';
  debito: number; // Saídas (Débito da empresa)
  credito: number; // Entradas (Crédito fiscal)
  saldo: number; // debito - credito
  status: 'A_RECOLHER' | 'SALDO_CREDOR' | 'ZERADO';
}

export interface TaxAssessmentResult {
  items: TaxAssessmentItem[];
  totalDebito: number;
  totalCredito: number;
  saldoGeral: number;
  statusGeral: 'A_RECOLHER' | 'SALDO_CREDOR' | 'ZERADO';
}
