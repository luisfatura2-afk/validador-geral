import { InvoiceRecord } from './fiscal';

export type FiscalDocumentType =
  | 'ENTRADA'
  | 'SAIDA'
  | 'DEVOLUCAO'
  | 'CTE'
  | 'SERVICO';

export interface UnifiedFiscalDocument {
  id: string;
  category: FiscalDocumentType;
  numero: string;
  serie: string;
  chaveAcesso: string;
  dataEmissao: string;
  dataMovimentacao?: string;
  emitenteOuDestinatario: string;
  documentoPessoa: string;
  cfopPrincipal: string;
  valorContabil: number;
  valorIcms: number;
  valorPis: number;
  valorCofins: number;
  valorIpi: number;
  valorIbs?: number;
  valorCbs?: number;
  situacaoSefaz: string;
  origemFonte: 'TOTVS' | 'QIVE_SEFAZ' | 'MANUAL' | 'OUTROS';
  originalRecord?: InvoiceRecord | Record<string, unknown>;
  temInconsistencia?: boolean;
}

export interface CentralDadosFilterState {
  category: 'ALL' | FiscalDocumentType;
  origem: 'ALL' | 'TOTVS' | 'QIVE_SEFAZ';
  busca: string;
  dataInicio: string;
  dataFim: string;
  cfop: string;
  apenasInconsistentes: boolean;
}
