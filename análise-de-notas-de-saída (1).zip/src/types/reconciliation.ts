import { InvoiceRecord } from './fiscal';

export interface QiveRecord {
  id: string;
  chaveAcesso: string;
  numero: string;
  serie: string;
  dataEmissao: string;
  dataEmissaoDate?: Date;
  nomeEmitente: string;
  cnpjEmitente: string;
  ieEmitente: string;
  destinatario: string;
  cnpjDestinatario: string;
  ieDestinatario: string;
  valorTotal: number;
  valorIcms: number;
  valorPis?: number;
  valorCofins?: number;
  valorIpi?: number;
  valorIcmsSt?: number;
  valorBaseIcms?: number;
  status: string; // "Autorizadas", "Canceladas", etc.
  manifestacao: string; // "Com Ciência", "Confirmada", etc.
  naturezaOperacao: string;
  cfops: string;
  tipoNota: 'NFe' | 'CTe' | 'NFSe' | 'Outro';
  rawRow: Record<string, string>;
}

export type ReconciliationStatus =
  | 'MATCHED'              // Present in both Qive and TOTVS
  | 'PENDING_IN_TOTVS'     // In Qive but missing in TOTVS (Risk: not registered!)
  | 'ONLY_IN_TOTVS'        // In TOTVS but missing in Qive
  | 'VALUE_DIVERGENCE'     // Present in both, but values differ (> R$ 0.05)
  | 'CANCELLED_SEFAZ';     // Cancelled in SEFAZ

export interface ReconciledItem {
  id: string;
  chaveAcesso: string;
  status: ReconciliationStatus;
  statusLabel: string;
  
  // Data from Qive (if available)
  qive?: QiveRecord;
  
  // Data from TOTVS (if available)
  totvs?: InvoiceRecord;
  
  // Comparison fields
  numero: string;
  serie: string;
  tipoDocumento: string;
  nomeEmitente: string;
  cnpjEmitente: string;
  dataEmissao: string;
  dataEmissaoDate?: Date;
  valorQive: number;
  valorTotvs: number;
  diferencaValor: number;
  valorIcmsQive: number;
  valorIcmsTotvs: number;
  cfops: string;
  manifestacao: string;
  statusSefaz: string;
}

export interface ReconciliationKPIs {
  totalQiveCount: number;
  totalQiveValue: number;
  totalTotvsCount: number;
  totalTotvsValue: number;
  
  matchedCount: number;
  matchedValue: number;
  
  pendingTotvsCount: number;
  pendingTotvsValue: number;
  
  onlyTotvsCount: number;
  onlyTotvsValue: number;
  
  divergenceCount: number;
  divergenceValueSum: number;
  
  cancelledCount: number;
  cancelledValue: number;
}

export interface ReconciliationFilterState {
  status: string; // 'ALL', 'MATCHED', 'PENDING_IN_TOTVS', 'ONLY_IN_TOTVS', 'VALUE_DIVERGENCE', 'CANCELLED_SEFAZ'
  tipoDocumento: string; // 'ALL', 'NFe', 'CTe', 'NFSe'
  termoBusca: string; // search in NF, chave, emitente, cnpj
  dataInicio: string;
  dataFim: string;
  manifestacao: string;
}
