export type ImportSourceType =
  | 'TOTVS_SAIDA'
  | 'TOTVS_ENTRADA'
  | 'QIVE_SEFAZ'
  | 'CTE'
  | 'SERVICO'
  | 'GENERIC_CSV'
  | 'GENERIC_EXCEL'
  | 'GENERIC_JSON';

export type ImportStatus = 'SUCESSO' | 'ATENCAO' | 'ERRO';

export interface ImportErrorItem {
  line?: number;
  column?: string;
  message: string;
  severity: 'WARNING' | 'ERROR';
  rawSnippet?: string;
}

export interface ImportLogEntry {
  id: string;
  fileName: string;
  fileSizeBytes?: number;
  importedAt: string; // ISO string
  sourceType: ImportSourceType;
  sourceLabel: string;
  totalRecords: number;
  validRecords: number;
  invalidRecords: number;
  totalContabil: number;
  periodStart?: string;
  periodEnd?: string;
  status: ImportStatus;
  errors: ImportErrorItem[];
  metadata?: Record<string, unknown>;
}

export interface ImportHistoryState {
  logs: ImportLogEntry[];
  lastImportedId?: string;
}
