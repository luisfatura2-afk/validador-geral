export type TipoBeneficioFiscal =
  | 'ISENCAO'
  | 'REDUCAO_BASE'
  | 'DIFERIMENTO'
  | 'SUSPENSAO'
  | 'NAO_INCIDENCIA'
  | 'CREDITO_PRESUMIDO'
  | 'OUTROS';

export interface BeneficioFiscal {
  id: string;
  codigo: string; // Ex: cBenef "PR800000", "SP000001", "RS051000", "BENEF-001"
  nome: string; // Ex: "Isenção de ICMS - Hortifrutigranjeiros"
  tipoBeneficio: TipoBeneficioFiscal;
  cfops: string[]; // Lista de CFOPs vinculados, ex: ["5101", "5102", "6101"]
  cstEsperado?: string; // Ex: "20", "40", "41", "50", "51"
  percentualReducao?: number; // Ex: 33.33 ou 50
  aliquotaEfetiva?: number; // Ex: 7 ou 12
  uf: string; // Ex: "SP", "PR", "MG", "TODOS"
  baseLegal: string; // Ex: "Art. 14 do Anexo II do RICMS", "Convênio ICMS 52/91"
  descricao?: string;
  ativo: boolean;
  criadoEm: string;
  atualizadoEm?: string;
}

export interface BeneficioFiscalAuditoriaStats {
  totalBeneficios: number;
  beneficiosAtivos: number;
  totalCfopsVinculados: number;
  documentosAtingidos: number;
  totalValorBeneficio: number;
  inconsistenciasDetectadas: number;
}
