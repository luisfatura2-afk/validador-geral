export type AlertSeverity = 'OK' | 'ATENCAO' | 'CRITICO' | 'INFORMATIVO';

export type RuleCategory =
  | 'CFOP'
  | 'ICMS'
  | 'PIS'
  | 'COFINS'
  | 'IBS'
  | 'CBS'
  | 'CST'
  | 'DUPLICIDADE'
  | 'DIVERGENCIA'
  | 'DOCUMENTO_INVALIDO'
  | 'CAMPOS_AUSENTES'
  | 'BENEFICIO_FISCAL';

export interface AuditRule {
  id: string;
  code: string;
  name: string;
  category: RuleCategory;
  defaultSeverity: AlertSeverity;
  description: string;
  legalReference?: string;
  enabled: boolean;
}

export interface AuditFinding {
  id: string;
  ruleId: string;
  ruleCode: string;
  category: RuleCategory;
  severity: AlertSeverity;
  title: string;
  description: string;
  documentKey?: string;
  documentNumber?: string;
  documentSerie?: string;
  documentDate?: string;
  entityName?: string;
  entityId?: string;
  cfop?: string;
  suggestedAction?: string;
  impactValue?: number;
}

export interface AuditSummary {
  totalAnalyzed: number;
  totalOk: number;
  totalAlerts: number;
  criticalCount: number;
  attentionCount: number;
  infoCount: number;
  okCount: number;
  findings: AuditFinding[];
  findingsByCategory: Record<RuleCategory, number>;
  findingsBySeverity: Record<AlertSeverity, number>;
}
