import React, { useState, useMemo } from 'react';
import {
  Activity,
  TrendingUp,
  ShieldCheck,
  AlertTriangle,
  ArrowRightLeft,
  FileOutput,
  FileSpreadsheet,
  CheckCircle2,
  Percent,
  DollarSign,
  Building2,
  PieChart,
  BarChart3,
  Layers,
  Sparkles,
  HelpCircle,
  Clock,
  ChevronRight,
  RefreshCw,
  Scale,
  ArrowDownRight,
  ArrowUpRight,
} from 'lucide-react';
import { InvoiceRecord, TaxTotals, CfopSummary, SituationSummary } from '../types/fiscal';
import { ReconciliationKPIs, ReconciledItem } from '../types/reconciliation';
import { formatBRL, formatDecimalBR } from '../utils/csvParser';
import { exportIndicatorsToExcel } from '../utils/indicatorsExporter';

interface IndicatorsDashboardProps {
  saidaRecords: InvoiceRecord[];
  saidaTaxTotals: TaxTotals;
  entradaTaxTotals?: TaxTotals;
  cfopSummaries: CfopSummary[];
  situationSummaries: SituationSummary[];
  saidaFileName?: string;
  hasSaidaData: boolean;

  reconciliationItems: ReconciledItem[];
  reconciliationKpis: ReconciliationKPIs;
  qiveFileName?: string;
  totvsEntradaFileName?: string;
  hasEntradaData: boolean;

  onNavigateToModule: (mod: 'SAIDA' | 'ENTRADA' | 'INDICADORES') => void;
  onLoadSampleData?: () => void;
}

export const IndicatorsDashboard: React.FC<IndicatorsDashboardProps> = ({
  saidaRecords,
  saidaTaxTotals,
  entradaTaxTotals,
  cfopSummaries,
  situationSummaries,
  saidaFileName,
  hasSaidaData,

  reconciliationItems,
  reconciliationKpis,
  qiveFileName,
  totvsEntradaFileName,
  hasEntradaData,

  onNavigateToModule,
  onLoadSampleData,
}) => {
  const [activeScope, setActiveScope] = useState<'ALL' | 'ENTRADA' | 'SAIDA'>('ALL');

  // 1. Saída Metrics
  const saidaMetrics = useMemo(() => {
    const totalCount = saidaRecords.length;
    const authorizedRecords = saidaRecords.filter((r) => {
      const s = (r.situacao || '').toLowerCase();
      return s.includes('autoriz') || s.includes('emitida') || s.includes('normal');
    });
    const authorizedCount = authorizedRecords.length;
    const authorizedValue = authorizedRecords.reduce((acc, r) => acc + r.vlContabil, 0);

    const cancelledRecords = saidaRecords.filter((r) => {
      const s = (r.situacao || '').toLowerCase();
      return s.includes('cancel');
    });
    const cancelledCount = cancelledRecords.length;
    const cancelledValue = cancelledRecords.reduce((acc, r) => acc + r.vlContabil, 0);

    const inutilizedCount = saidaRecords.filter((r) => {
      const s = (r.situacao || '').toLowerCase();
      return s.includes('inutiliz');
    }).length;

    const totalTaxes =
      saidaTaxTotals.icms +
      saidaTaxTotals.pis +
      saidaTaxTotals.cofins +
      saidaTaxTotals.ipi +
      saidaTaxTotals.icmsSt +
      saidaTaxTotals.ibs +
      saidaTaxTotals.cbs;

    const effectiveTaxRate = authorizedValue > 0 ? (totalTaxes / authorizedValue) * 100 : 0;
    const avgTicket = authorizedCount > 0 ? authorizedValue / authorizedCount : 0;
    const regularRate = totalCount > 0 ? (authorizedCount / totalCount) * 100 : 0;

    return {
      totalCount,
      authorizedCount,
      authorizedValue,
      cancelledCount,
      cancelledValue,
      inutilizedCount,
      totalTaxes,
      effectiveTaxRate,
      avgTicket,
      regularRate,
    };
  }, [saidaRecords, saidaTaxTotals]);

  // 2. Reconciliation Metrics (Entrada Qive x TOTVS)
  const entradaMetrics = useMemo(() => {
    const totalQive = reconciliationKpis.totalQiveCount;
    const totalValueQive = reconciliationKpis.totalQiveValue;
    const matched = reconciliationKpis.matchedCount;
    const matchedVal = reconciliationKpis.matchedValue;
    const pending = reconciliationKpis.pendingTotvsCount;
    const pendingVal = reconciliationKpis.pendingTotvsValue;
    const divergences = reconciliationKpis.divergenceCount;
    const divergenceVal = reconciliationKpis.divergenceValueSum;

    // Conciliation Rate
    const conciliationRate = totalQive > 0 ? (matched / totalQive) * 100 : 0;

    // Accuracy Rate (matched without divergence)
    const accuracyRate = matched > 0 ? ((matched - divergences) / matched) * 100 : 100;

    // Top Pending Suppliers
    const supplierMap = new Map<string, { nome: string; cnpj: string; count: number; totalValue: number }>();
    reconciliationItems
      .filter((i) => i.status === 'PENDING_IN_TOTVS')
      .forEach((item) => {
        const key = item.cnpjEmitente || item.nomeEmitente || 'DESCONHECIDO';
        const existing = supplierMap.get(key) || {
          nome: item.nomeEmitente || 'Fornecedor Não Identificado',
          cnpj: item.cnpjEmitente || '-',
          count: 0,
          totalValue: 0,
        };
        existing.count += 1;
        existing.totalValue += item.valorQive;
        supplierMap.set(key, existing);
      });

    const topPendingSuppliers = Array.from(supplierMap.values())
      .sort((a, b) => b.totalValue - a.totalValue)
      .slice(0, 5);

    // Document types in Qive
    const docTypes = {
      nfe: reconciliationItems.filter((i) => i.tipoDocumento === 'NFe').length,
      cte: reconciliationItems.filter((i) => i.tipoDocumento === 'CTe').length,
      nfse: reconciliationItems.filter((i) => i.tipoDocumento === 'NFSe').length,
      outros: reconciliationItems.filter((i) => !['NFe', 'CTe', 'NFSe'].includes(i.tipoDocumento)).length,
    };

    return {
      totalQive,
      totalValueQive,
      matched,
      matchedVal,
      pending,
      pendingVal,
      divergences,
      divergenceVal,
      conciliationRate,
      accuracyRate,
      topPendingSuppliers,
      docTypes,
    };
  }, [reconciliationKpis, reconciliationItems]);

  // 3. Consolidated Health Score (0 - 100)
  const healthScore = useMemo(() => {
    let score = 100;
    const hasAny = hasSaidaData || hasEntradaData;
    if (!hasAny) return 100;

    if (hasEntradaData && entradaMetrics.totalQive > 0) {
      // Penalty for pending invoices
      const pendingRatio = entradaMetrics.pending / entradaMetrics.totalQive;
      score -= Math.min(30, Math.round(pendingRatio * 50));

      // Penalty for divergences
      if (entradaMetrics.divergences > 0) {
        score -= Math.min(15, entradaMetrics.divergences * 3);
      }
    }

    if (hasSaidaData && saidaMetrics.totalCount > 0) {
      // Penalty for cancelled invoices
      const cancelledRatio = saidaMetrics.cancelledCount / saidaMetrics.totalCount;
      score -= Math.min(15, Math.round(cancelledRatio * 40));
    }

    return Math.max(20, Math.min(100, score));
  }, [hasSaidaData, hasEntradaData, entradaMetrics, saidaMetrics]);

  // Apuração Fiscal Consolidada: Débitos (Saídas) - Créditos (Entradas)
  const taxAssessment = useMemo(() => {
    const safeEntrada = entradaTaxTotals || {
      icms: 0,
      baseIcms: 0,
      isentoIcms: 0,
      outroIcms: 0,
      icmsSt: 0,
      ipi: 0,
      pis: 0,
      cofins: 0,
      fcp: 0,
      fcpSt: 0,
      ibs: 0,
      cbs: 0,
      is: 0,
    };

    const debitoIcms = saidaTaxTotals.icms;
    const creditoIcms = safeEntrada.icms;
    const saldoIcms = debitoIcms - creditoIcms;

    const debitoPis = saidaTaxTotals.pis;
    const creditoPis = safeEntrada.pis;
    const saldoPis = debitoPis - creditoPis;

    const debitoCofins = saidaTaxTotals.cofins;
    const creditoCofins = safeEntrada.cofins;
    const saldoCofins = debitoCofins - creditoCofins;

    const debitoIpi = saidaTaxTotals.ipi;
    const creditoIpi = safeEntrada.ipi;
    const saldoIpi = debitoIpi - creditoIpi;

    const debitoSt = saidaTaxTotals.icmsSt;
    const creditoSt = safeEntrada.icmsSt;
    const saldoSt = debitoSt - creditoSt;

    const totalDebitos =
      debitoIcms +
      debitoPis +
      debitoCofins +
      debitoIpi +
      debitoSt +
      saidaTaxTotals.fcp +
      saidaTaxTotals.fcpSt +
      saidaTaxTotals.ibs +
      saidaTaxTotals.cbs;

    const totalCreditos =
      creditoIcms +
      creditoPis +
      creditoCofins +
      creditoIpi +
      creditoSt +
      safeEntrada.fcp +
      safeEntrada.fcpSt +
      safeEntrada.ibs +
      safeEntrada.cbs;

    const saldoGeral = totalDebitos - totalCreditos;

    return {
      totalDebitos,
      totalCreditos,
      saldoGeral,
      saldoIcms,
      debitoIcms,
      creditoIcms,
      saldoPis,
      debitoPis,
      creditoPis,
      saldoCofins,
      debitoCofins,
      creditoCofins,
      saldoIpi,
      debitoIpi,
      creditoIpi,
      saldoSt,
      debitoSt,
      creditoSt,
      hasCredits: totalCreditos > 0,
    };
  }, [saidaTaxTotals, entradaTaxTotals]);

  // Health level definition
  const healthLevel = useMemo(() => {
    if (healthScore >= 90) {
      return {
        label: 'EXCELENTE CONFORMIDADE',
        desc: 'Baixíssimo risco fiscal e alta taxa de escrituração contábil.',
        badgeClass: 'bg-[#233527] text-[#D5BEA4] border-[#3D5B47]',
        barColor: 'bg-[#3D5B47]',
      };
    }
    if (healthScore >= 75) {
      return {
        label: 'ATENÇÃO OPERACIONAL',
        desc: 'Existem pendências de escrituração ou divergências que requerem tratativa.',
        badgeClass: 'bg-amber-900/30 text-amber-300 border-amber-700/50',
        barColor: 'bg-amber-600',
      };
    }
    return {
      label: 'RISCO FISCAL ELEVADO',
      desc: 'Volume crítico de notas não lançadas no TOTVS ou divergências de valores.',
      badgeClass: 'bg-rose-950/40 text-rose-300 border-rose-800/60',
      barColor: 'bg-rose-600',
    };
  }, [healthScore]);

  // Handle Export Excel
  const handleExport = () => {
    exportIndicatorsToExcel({
      saidaTotalValue: saidaMetrics.authorizedValue + saidaMetrics.cancelledValue,
      saidaTotalCount: saidaMetrics.totalCount,
      saidaAuthorizedValue: saidaMetrics.authorizedValue,
      saidaAuthorizedCount: saidaMetrics.authorizedCount,
      saidaTaxTotals,
      cfopSummaries,
      reconciliationKpis,
      pendingSuppliers: entradaMetrics.topPendingSuppliers,
      healthScore,
    });
  };

  const hasAnyData = hasSaidaData || hasEntradaData;

  return (
    <div className="space-y-6">
      {/* Top Banner / Navigation context */}
      <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-['Montserrat',sans-serif] font-bold text-xs bg-[#1E2D23] text-[#D5BEA4] px-2.5 py-0.5 rounded tracking-wider uppercase">
                Dashboard Executivo
              </span>
              <span className="text-xs text-neutral-400">•</span>
              <span className="text-xs font-semibold text-neutral-600">
                TXC Fiscal Control — Monitoramento de Eficiência & Risco Fiscal
              </span>
            </div>
            <h2 className="font-['Cormorant_Garamond',serif] text-2xl sm:text-3xl font-bold text-[#1E2D23] mt-1">
              Painel de Indicadores & KPIs Gerenciais
            </h2>
            <p className="text-xs sm:text-sm text-neutral-600 mt-0.5">
              Cruzamento de conformidade entre compras faturadas na SEFAZ (Qive) e lançamentos contábeis/fiscais no ERP TOTVS.
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            {onLoadSampleData && (
              <button
                id="btn-load-demo-indicators"
                onClick={onLoadSampleData}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded bg-[#F5F1EB] hover:bg-[#EAE4DC] text-[#1E2D23] border border-[#D5BEA4] transition-all shadow-xs"
                title="Carregar dados fiscais realistas de exemplo"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#8C6D4C]" />
                <span>Carregar Exemplo Demonstrativo</span>
              </button>
            )}

            <button
              id="btn-export-indicators-excel"
              onClick={handleExport}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded bg-[#1E2D23] hover:bg-[#2A3F31] text-[#D5BEA4] uppercase tracking-wider transition-all shadow-sm active:scale-98"
              title="Baixar planilha consolidada de indicadores"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Exportar Indicadores (Excel)</span>
            </button>
          </div>
        </div>

        {/* Dataset Status Badges */}
        <div className="mt-4 pt-4 border-t border-[#E2D9CE] flex flex-wrap items-center gap-2 sm:gap-4 text-xs">
          <span className="text-neutral-500 font-semibold uppercase text-[11px] tracking-wider">Origem dos Dados:</span>
          
          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border ${
            hasEntradaData && reconciliationKpis.totalQiveCount > 0
              ? 'bg-[#F2F6F3] border-[#3D5B47] text-[#1E2D23]'
              : 'bg-[#FAF8F5] border-[#E2D9CE] text-neutral-500'
          }`}>
            <span className={`w-2 h-2 rounded-full ${hasEntradaData && reconciliationKpis.totalQiveCount > 0 ? 'bg-emerald-600' : 'bg-neutral-400'}`} />
            <span className="font-semibold">Qive SEFAZ:</span>
            <span>{hasEntradaData ? `${reconciliationKpis.totalQiveCount} notas carregadas` : 'Não importado'}</span>
          </div>

          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border ${
            hasEntradaData && reconciliationKpis.totalTotvsCount > 0
              ? 'bg-[#F2F6F3] border-[#3D5B47] text-[#1E2D23]'
              : 'bg-[#FAF8F5] border-[#E2D9CE] text-neutral-500'
          }`}>
            <span className={`w-2 h-2 rounded-full ${hasEntradaData && reconciliationKpis.totalTotvsCount > 0 ? 'bg-emerald-600' : 'bg-neutral-400'}`} />
            <span className="font-semibold">TOTVS Entradas:</span>
            <span>{hasEntradaData ? `${reconciliationKpis.totalTotvsCount} notas escrituradas` : 'Não importado'}</span>
          </div>

          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border ${
            hasSaidaData
              ? 'bg-[#F2F6F3] border-[#3D5B47] text-[#1E2D23]'
              : 'bg-[#FAF8F5] border-[#E2D9CE] text-neutral-500'
          }`}>
            <span className={`w-2 h-2 rounded-full ${hasSaidaData ? 'bg-emerald-600' : 'bg-neutral-400'}`} />
            <span className="font-semibold">TOTVS Saídas:</span>
            <span>{hasSaidaData ? `${saidaMetrics.authorizedCount} faturamentos` : 'Não importado'}</span>
          </div>

          {!hasAnyData && (
            <span className="text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded text-[11px] font-medium">
              Nenhum arquivo importado ainda. Clique em "Carregar Exemplo Demonstrativo" ou acesse as abas de Saída e Entrada.
            </span>
          )}
        </div>
      </div>

      {/* Scope Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-[#E2D9CE] pb-2">
        <button
          id="btn-scope-all"
          onClick={() => setActiveScope('ALL')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
            activeScope === 'ALL'
              ? 'bg-[#1E2D23] text-[#D5BEA4] shadow-xs'
              : 'text-neutral-600 hover:text-black hover:bg-[#F5F1EB]'
          }`}
        >
          Visão Consolidada (360°)
        </button>

        <button
          id="btn-scope-entrada"
          onClick={() => setActiveScope('ENTRADA')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all inline-flex items-center gap-1.5 ${
            activeScope === 'ENTRADA'
              ? 'bg-[#1E2D23] text-[#D5BEA4] shadow-xs'
              : 'text-neutral-600 hover:text-black hover:bg-[#F5F1EB]'
          }`}
        >
          <ArrowRightLeft className="w-3.5 h-3.5" />
          <span>Conciliação de Entradas (Qive × TOTVS)</span>
        </button>

        <button
          id="btn-scope-saida"
          onClick={() => setActiveScope('SAIDA')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all inline-flex items-center gap-1.5 ${
            activeScope === 'SAIDA'
              ? 'bg-[#1E2D23] text-[#D5BEA4] shadow-xs'
              : 'text-neutral-600 hover:text-black hover:bg-[#F5F1EB]'
          }`}
        >
          <FileOutput className="w-3.5 h-3.5" />
          <span>Faturamento & Saídas (TOTVS)</span>
        </button>
      </div>

      {/* SECTION 1: HEALTH SCORE & HIGH LEVEL GAUGES */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Fiscal Health Gauge Card */}
        <div className="bg-[#1E2D23] text-[#FAF7F2] rounded-xl p-6 border border-[#334D3C] shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono tracking-widest text-[#D5BEA4] uppercase">
                Índice de Saúde Fiscal
              </span>
              <ShieldCheck className="w-5 h-5 text-[#D5BEA4]" />
            </div>

            <div className="mt-4 flex items-baseline gap-3">
              <span className="text-5xl font-black font-['Montserrat',sans-serif] tracking-tight text-[#FAF7F2]">
                {healthScore}
              </span>
              <span className="text-xl font-medium text-[#C2B7A3]">/ 100</span>
            </div>

            <div className="mt-3">
              <div className="w-full bg-[#2A3F31] rounded-full h-2.5 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${healthLevel.barColor}`}
                  style={{ width: `${healthScore}%` }}
                />
              </div>
            </div>

            <div className="mt-4">
              <span className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold border uppercase tracking-wider ${healthLevel.badgeClass}`}>
                {healthLevel.label}
              </span>
              <p className="text-xs text-[#C2B7A3] mt-2 leading-relaxed">
                {healthLevel.desc}
              </p>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-[#334D3C] grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-[#C2B7A3] block text-[10px] uppercase">Aderência SEFAZ</span>
              <span className="font-bold text-[#FAF7F2] font-mono">
                {entradaMetrics.totalQive > 0 ? `${entradaMetrics.conciliationRate.toFixed(1)}%` : '---'}
              </span>
            </div>
            <div>
              <span className="text-[#C2B7A3] block text-[10px] uppercase">Acurácia Valores</span>
              <span className="font-bold text-[#FAF7F2] font-mono">
                {entradaMetrics.matched > 0 ? `${entradaMetrics.accuracyRate.toFixed(1)}%` : '---'}
              </span>
            </div>
          </div>
        </div>

        {/* Strategic Cards: Entradas & Saídas Overview */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Card: Taxa de Conciliação */}
          <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                  Eficiência de Escrituração
                </span>
                <h3 className="text-xl font-bold text-[#1E2D23] font-['Montserrat',sans-serif] mt-0.5">
                  Taxa de Conciliação
                </h3>
              </div>
              <div className="w-8 h-8 rounded-lg bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#1E2D23]">
                <ArrowRightLeft className="w-4 h-4" />
              </div>
            </div>

            <div className="my-3">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-[#1E2D23] font-mono">
                  {entradaMetrics.totalQive > 0 ? `${entradaMetrics.conciliationRate.toFixed(1)}%` : '0.0%'}
                </span>
                <span className="text-xs text-neutral-500 font-medium">
                  ({entradaMetrics.matched} de {entradaMetrics.totalQive} notas lançadas)
                </span>
              </div>
              <div className="w-full bg-[#EAE4DC] rounded-full h-2 mt-2 overflow-hidden">
                <div
                  className="bg-[#1E2D23] h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, entradaMetrics.conciliationRate)}%` }}
                />
              </div>
            </div>

            <div className="pt-3 border-t border-[#E2D9CE] flex items-center justify-between text-xs text-neutral-600">
              <span>Valor conciliado no ERP:</span>
              <span className="font-bold text-[#1E2D23] font-mono">{formatBRL(entradaMetrics.matchedVal)}</span>
            </div>
          </div>

          {/* Card: Passivo Pendente */}
          <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                  Exposição Operacional
                </span>
                <h3 className="text-xl font-bold text-[#1E2D23] font-['Montserrat',sans-serif] mt-0.5">
                  Pendências no TOTVS
                </h3>
              </div>
              <div className="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700">
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>

            <div className="my-3">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl sm:text-3xl font-black text-amber-900 font-mono">
                  {formatBRL(entradaMetrics.pendingVal)}
                </span>
              </div>
              <p className="text-xs text-neutral-600 mt-1">
                <strong className="text-amber-900 font-semibold">{entradaMetrics.pending} documentos</strong> emitidos por fornecedores na SEFAZ que ainda não constam no ERP.
              </p>
            </div>

            <div className="pt-3 border-t border-[#E2D9CE] flex items-center justify-between text-xs">
              <span className="text-neutral-500">Ação recomendada:</span>
              <button
                id="btn-view-pending-in-table"
                onClick={() => onNavigateToModule('ENTRADA')}
                className="text-[#8C6D4C] hover:text-[#1E2D23] font-bold inline-flex items-center gap-1"
              >
                <span>Conferir na Tabela</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Card: Faturamento Saídas */}
          <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                  Faturamento de Saídas
                </span>
                <h3 className="text-xl font-bold text-[#1E2D23] font-['Montserrat',sans-serif] mt-0.5">
                  Receita Autorizada
                </h3>
              </div>
              <div className="w-8 h-8 rounded-lg bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#1E2D23]">
                <FileOutput className="w-4 h-4" />
              </div>
            </div>

            <div className="my-3">
              <div className="text-2xl sm:text-3xl font-black text-[#1E2D23] font-mono">
                {formatBRL(saidaMetrics.authorizedValue)}
              </div>
              <p className="text-xs text-neutral-600 mt-1">
                {saidaMetrics.authorizedCount} notas autorizadas • Ticket médio: {formatBRL(saidaMetrics.avgTicket)}
              </p>
            </div>

            <div className="pt-3 border-t border-[#E2D9CE] flex items-center justify-between text-xs text-neutral-600">
              <span>Regularidade de emissão:</span>
              <span className="font-bold text-[#1E2D23] font-mono">
                {saidaMetrics.totalCount > 0 ? `${saidaMetrics.regularRate.toFixed(1)}%` : '---'}
              </span>
            </div>
          </div>

          {/* Card: Carga Tributária Efetiva */}
          <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block">
                  Carga Tributária
                </span>
                <h3 className="text-xl font-bold text-[#1E2D23] font-['Montserrat',sans-serif] mt-0.5">
                  Impostos Apurados
                </h3>
              </div>
              <div className="w-8 h-8 rounded-lg bg-[#FAF8F5] border border-[#E2D9CE] flex items-center justify-center text-[#1E2D23]">
                <Percent className="w-4 h-4" />
              </div>
            </div>

            <div className="my-3">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-[#1E2D23] font-mono">
                  {saidaMetrics.authorizedValue > 0 ? `${saidaMetrics.effectiveTaxRate.toFixed(2)}%` : '0.00%'}
                </span>
                <span className="text-xs text-neutral-500 font-medium">alíquota média</span>
              </div>
              <div className="text-xs font-semibold text-neutral-700 mt-1">
                Total de tributos: {formatBRL(saidaMetrics.totalTaxes)}
              </div>
            </div>

            <div className="pt-3 border-t border-[#E2D9CE] flex items-center justify-between text-xs text-neutral-600">
              <span>ICMS Próprio apurado:</span>
              <span className="font-bold text-[#1E2D23] font-mono">{formatBRL(saidaTaxTotals.icms)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 2: TOP FORNECEDORES COM PENDÊNCIA NO TOTVS */}
      {(activeScope === 'ALL' || activeScope === 'ENTRADA') && (
        <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-[#E2D9CE]">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center">
                <Building2 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#1E2D23] font-['Montserrat',sans-serif] uppercase tracking-wide">
                  Top Fornecedores com Pendência de Escrituração no TOTVS
                </h3>
                <p className="text-xs text-neutral-500">
                  Emitentes na SEFAZ cujas notas mercantis ainda não foram integradas no ERP da empresa
                </p>
              </div>
            </div>

            <span className="text-xs font-mono font-semibold bg-[#FAF8F5] text-neutral-700 border border-[#E2D9CE] px-2.5 py-1 rounded">
              {entradaMetrics.topPendingSuppliers.length} fornecedores críticos listados
            </span>
          </div>

          {entradaMetrics.topPendingSuppliers.length > 0 ? (
            <div className="space-y-3">
              {entradaMetrics.topPendingSuppliers.map((supp, index) => {
                const percentOfPending =
                  entradaMetrics.pendingVal > 0 ? (supp.totalValue / entradaMetrics.pendingVal) * 100 : 0;

                return (
                  <div
                    key={supp.cnpj + index}
                    className="p-3.5 rounded-lg border border-[#E2D9CE] bg-[#FAF8F5] hover:bg-[#F5F1EB] transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-start sm:items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center text-xs font-bold font-mono">
                          {index + 1}
                        </span>
                        <div>
                          <h4 className="font-bold text-sm text-[#1E2D23]">{supp.nome}</h4>
                          <span className="text-xs font-mono text-neutral-500">CNPJ: {supp.cnpj}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 self-end sm:self-center">
                        <div className="text-right">
                          <span className="text-xs text-neutral-500 block">Notas pendentes:</span>
                          <span className="font-bold text-xs text-amber-900 bg-amber-100 px-2 py-0.5 rounded">
                            {supp.count} {supp.count === 1 ? 'nota' : 'notas'}
                          </span>
                        </div>
                        <div className="text-right min-w-[120px]">
                          <span className="text-xs text-neutral-500 block">Valor retido:</span>
                          <span className="font-bold text-sm text-[#1E2D23] font-mono">
                            {formatBRL(supp.totalValue)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-2.5">
                      <div className="w-full bg-[#E2D9CE] rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-[#8C6D4C] h-full rounded-full"
                          style={{ width: `${Math.min(100, Math.max(5, percentOfPending))}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-8 text-center text-neutral-500">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2 opacity-80" />
              <p className="text-sm font-semibold text-neutral-700">
                Nenhum fornecedor com pendência pendente no momento.
              </p>
              <p className="text-xs text-neutral-500 mt-0.5">
                {hasEntradaData
                  ? 'Todas as notas recebidas pelo Qive foram conciliadas com o TOTVS.'
                  : 'Importe os arquivos do Qive e TOTVS para apurar pendências de fornecedores.'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: DETAILED CHARTS (COMPARATIVOS E COMPOSIÇÃO) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Funil de Escrituração SEFAZ x TOTVS */}
        {(activeScope === 'ALL' || activeScope === 'ENTRADA') && (
          <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#E2D9CE]">
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-[#1E2D23]" />
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wide font-['Montserrat',sans-serif]">
                    Funil de Eficiência de Entradas
                  </h3>
                </div>
                <span className="text-[11px] text-neutral-500 font-mono">SEFAZ vs ERP</span>
              </div>

              <div className="space-y-4">
                {/* Stage 1 */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-[#1E2D23]">1. Notas Recebidas na SEFAZ (Qive)</span>
                    <span className="font-mono font-bold">{entradaMetrics.totalQive} docs • {formatBRL(entradaMetrics.totalValueQive)}</span>
                  </div>
                  <div className="w-full bg-[#EAE4DC] rounded h-3 overflow-hidden">
                    <div className="bg-[#1E2D23] h-full rounded w-full" />
                  </div>
                </div>

                {/* Stage 2 */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-emerald-800">2. Escrituradas no TOTVS (Conciliadas)</span>
                    <span className="font-mono font-bold text-emerald-900">
                      {entradaMetrics.matched} docs • {formatBRL(entradaMetrics.matchedVal)}
                    </span>
                  </div>
                  <div className="w-full bg-[#EAE4DC] rounded h-3 overflow-hidden">
                    <div
                      className="bg-emerald-700 h-full rounded transition-all duration-500"
                      style={{
                        width: entradaMetrics.totalQive > 0 ? `${(entradaMetrics.matched / entradaMetrics.totalQive) * 100}%` : '0%',
                      }}
                    />
                  </div>
                </div>

                {/* Stage 3 */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-amber-800">3. Pendentes de Lançamento (Passivo)</span>
                    <span className="font-mono font-bold text-amber-900">
                      {entradaMetrics.pending} docs • {formatBRL(entradaMetrics.pendingVal)}
                    </span>
                  </div>
                  <div className="w-full bg-[#EAE4DC] rounded h-3 overflow-hidden">
                    <div
                      className="bg-amber-600 h-full rounded transition-all duration-500"
                      style={{
                        width: entradaMetrics.totalQive > 0 ? `${(entradaMetrics.pending / entradaMetrics.totalQive) * 100}%` : '0%',
                      }}
                    />
                  </div>
                </div>

                {/* Stage 4 */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-rose-800">4. Divergências de Valores / Centavos</span>
                    <span className="font-mono font-bold text-rose-900">
                      {entradaMetrics.divergences} docs • {formatBRL(entradaMetrics.divergenceVal)}
                    </span>
                  </div>
                  <div className="w-full bg-[#EAE4DC] rounded h-3 overflow-hidden">
                    <div
                      className="bg-rose-600 h-full rounded transition-all duration-500"
                      style={{
                        width: entradaMetrics.matched > 0 ? `${(entradaMetrics.divergences / entradaMetrics.matched) * 100}%` : '0%',
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#E2D9CE] text-xs text-neutral-500 flex items-center justify-between">
              <span>Tipos de Documento na SEFAZ:</span>
              <span className="font-mono">
                {entradaMetrics.docTypes.nfe} NF-e • {entradaMetrics.docTypes.cte} CT-e • {entradaMetrics.docTypes.nfse} NFS-e
              </span>
            </div>
          </div>
        )}

        {/* Chart 2: Composição da Carga Tributária (Saídas) */}
        {(activeScope === 'ALL' || activeScope === 'SAIDA') && (
          <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#E2D9CE]">
                <div className="flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-[#1E2D23]" />
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wide font-['Montserrat',sans-serif]">
                    Composição dos Tributos de Saída
                  </h3>
                </div>
                <span className="text-[11px] text-neutral-500 font-mono">
                  Total: {formatBRL(saidaMetrics.totalTaxes)}
                </span>
              </div>

              <div className="space-y-3">
                {/* ICMS */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-neutral-800">ICMS Próprio (Estadual)</span>
                    <span className="font-mono font-bold text-[#1E2D23]">{formatBRL(saidaTaxTotals.icms)}</span>
                  </div>
                  <div className="w-full bg-[#EAE4DC] rounded h-2.5 overflow-hidden">
                    <div
                      className="bg-[#1E2D23] h-full rounded"
                      style={{
                        width: saidaMetrics.totalTaxes > 0 ? `${(saidaTaxTotals.icms / saidaMetrics.totalTaxes) * 100}%` : '0%',
                      }}
                    />
                  </div>
                </div>

                {/* PIS */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-neutral-800">PIS (Federal)</span>
                    <span className="font-mono font-bold text-[#1E2D23]">{formatBRL(saidaTaxTotals.pis)}</span>
                  </div>
                  <div className="w-full bg-[#EAE4DC] rounded h-2.5 overflow-hidden">
                    <div
                      className="bg-[#3D5B47] h-full rounded"
                      style={{
                        width: saidaMetrics.totalTaxes > 0 ? `${(saidaTaxTotals.pis / saidaMetrics.totalTaxes) * 100}%` : '0%',
                      }}
                    />
                  </div>
                </div>

                {/* COFINS */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-neutral-800">COFINS (Federal)</span>
                    <span className="font-mono font-bold text-[#1E2D23]">{formatBRL(saidaTaxTotals.cofins)}</span>
                  </div>
                  <div className="w-full bg-[#EAE4DC] rounded h-2.5 overflow-hidden">
                    <div
                      className="bg-[#56735F] h-full rounded"
                      style={{
                        width: saidaMetrics.totalTaxes > 0 ? `${(saidaTaxTotals.cofins / saidaMetrics.totalTaxes) * 100}%` : '0%',
                      }}
                    />
                  </div>
                </div>

                {/* IPI */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-neutral-800">IPI (Federal Industrial)</span>
                    <span className="font-mono font-bold text-[#1E2D23]">{formatBRL(saidaTaxTotals.ipi)}</span>
                  </div>
                  <div className="w-full bg-[#EAE4DC] rounded h-2.5 overflow-hidden">
                    <div
                      className="bg-[#8C6D4C] h-full rounded"
                      style={{
                        width: saidaMetrics.totalTaxes > 0 ? `${(saidaTaxTotals.ipi / saidaMetrics.totalTaxes) * 100}%` : '0%',
                      }}
                    />
                  </div>
                </div>

                {/* ICMS ST */}
                {saidaTaxTotals.icmsSt > 0 && (
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="font-semibold text-neutral-800">ICMS Substituição Tributária (ST)</span>
                      <span className="font-mono font-bold text-[#1E2D23]">{formatBRL(saidaTaxTotals.icmsSt)}</span>
                    </div>
                    <div className="w-full bg-[#EAE4DC] rounded h-2.5 overflow-hidden">
                      <div
                        className="bg-[#D5BEA4] h-full rounded"
                        style={{
                          width: saidaMetrics.totalTaxes > 0 ? `${(saidaTaxTotals.icmsSt / saidaMetrics.totalTaxes) * 100}%` : '0%',
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#E2D9CE] text-xs text-neutral-500 flex items-center justify-between">
              <span>Base de Cálculo ICMS:</span>
              <span className="font-mono font-bold text-[#1E2D23]">{formatBRL(saidaTaxTotals.baseIcms)}</span>
            </div>
          </div>
        )}
      </div>

      {/* SECTION: APURAÇÃO FISCAL CONSOLIDADA (DÉBITOS - CRÉDITOS) */}
      {(hasSaidaData || hasEntradaData) && (
        <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#E2D9CE]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4]">
                <Scale className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wide font-['Montserrat',sans-serif]">
                    Apuração Fiscal Consolidada: Débito (Saídas) − Crédito (Entradas)
                  </h3>
                  <span className="text-[10px] bg-[#FAF3EA] text-[#8C6D4C] border border-[#E8DCCB] font-bold px-2 py-0.5 rounded uppercase">
                    Não-Cumulativo
                  </span>
                </div>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Demonstrativo sintético da compensação de débitos gerados nas vendas e créditos gerados nas compras
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigateToModule('SAIDA')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] rounded text-xs font-bold transition-colors shrink-0"
            >
              <span>Ver Apuração Completa</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#D5BEA4]" />
            </button>
          </div>

          {/* 3 Main KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 my-5">
            <div className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
                (+) Débitos Fiscais (Saídas)
              </span>
              <div className="text-2xl font-black text-[#1E2D23] font-mono">
                {formatBRL(taxAssessment.totalDebitos)}
              </div>
              <span className="text-[11px] text-neutral-500 mt-0.5 block">
                Total de tributos gerados em vendas
              </span>
            </div>

            <div className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
                (−) Créditos Fiscais (Entradas)
              </span>
              <div className="text-2xl font-black text-emerald-900 font-mono">
                {formatBRL(taxAssessment.totalCreditos)}
              </div>
              <span className="text-[11px] text-neutral-500 mt-0.5 block">
                Total de créditos obtidos em aquisições
              </span>
            </div>

            <div
              className={`rounded-lg p-4 border ${
                taxAssessment.saldoGeral > 0
                  ? 'bg-rose-50/50 border-rose-200'
                  : taxAssessment.saldoGeral < 0
                  ? 'bg-emerald-50/50 border-emerald-200'
                  : 'bg-[#FAF8F5] border-[#E2D9CE]'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#1E2D23]">
                  (=) Saldo da Apuração
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                    taxAssessment.saldoGeral > 0
                      ? 'bg-rose-100 text-rose-800'
                      : taxAssessment.saldoGeral < 0
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-neutral-100 text-neutral-700'
                  }`}
                >
                  {taxAssessment.saldoGeral > 0 ? 'A Recolher' : taxAssessment.saldoGeral < 0 ? 'Saldo Credor' : 'Zerado'}
                </span>
              </div>
              <div
                className={`text-2xl font-black font-mono ${
                  taxAssessment.saldoGeral > 0
                    ? 'text-[#8F3E35]'
                    : taxAssessment.saldoGeral < 0
                    ? 'text-emerald-900'
                    : 'text-[#1E2D23]'
                }`}
              >
                {formatBRL(Math.abs(taxAssessment.saldoGeral))}
              </div>
              <span className="text-[11px] text-neutral-600 mt-0.5 block">
                {taxAssessment.saldoGeral > 0
                  ? 'Valor líquido a pagar via DARE / DARF'
                  : taxAssessment.saldoGeral < 0
                  ? 'Crédito acumulado para compensação'
                  : 'Débitos e créditos equalizados'}
              </span>
            </div>
          </div>

          {/* Synthetic Matrix */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-3 border-t border-[#E2D9CE]">
            {/* ICMS */}
            <div className="p-3 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg text-xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-[#1E2D23]">ICMS Próprio</span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    taxAssessment.saldoIcms > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {taxAssessment.saldoIcms > 0 ? 'A Pagar' : 'Credor'}
                </span>
              </div>
              <div className="flex justify-between text-neutral-500 text-[11px] mb-0.5">
                <span>(+) Déb: {formatBRL(taxAssessment.debitoIcms)}</span>
                <span>(−) Créd: {formatBRL(taxAssessment.creditoIcms)}</span>
              </div>
              <div className="text-right font-mono font-bold text-xs text-[#1E2D23] pt-1 border-t border-[#E2D9CE]">
                Saldo: {formatBRL(taxAssessment.saldoIcms)}
              </div>
            </div>

            {/* PIS */}
            <div className="p-3 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg text-xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-[#1E2D23]">PIS (Federal)</span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    taxAssessment.saldoPis > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {taxAssessment.saldoPis > 0 ? 'A Pagar' : 'Credor'}
                </span>
              </div>
              <div className="flex justify-between text-neutral-500 text-[11px] mb-0.5">
                <span>(+) Déb: {formatBRL(taxAssessment.debitoPis)}</span>
                <span>(−) Créd: {formatBRL(taxAssessment.creditoPis)}</span>
              </div>
              <div className="text-right font-mono font-bold text-xs text-[#1E2D23] pt-1 border-t border-[#E2D9CE]">
                Saldo: {formatBRL(taxAssessment.saldoPis)}
              </div>
            </div>

            {/* COFINS */}
            <div className="p-3 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg text-xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-[#1E2D23]">COFINS (Federal)</span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    taxAssessment.saldoCofins > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {taxAssessment.saldoCofins > 0 ? 'A Pagar' : 'Credor'}
                </span>
              </div>
              <div className="flex justify-between text-neutral-500 text-[11px] mb-0.5">
                <span>(+) Déb: {formatBRL(taxAssessment.debitoCofins)}</span>
                <span>(−) Créd: {formatBRL(taxAssessment.creditoCofins)}</span>
              </div>
              <div className="text-right font-mono font-bold text-xs text-[#1E2D23] pt-1 border-t border-[#E2D9CE]">
                Saldo: {formatBRL(taxAssessment.saldoCofins)}
              </div>
            </div>

            {/* IPI */}
            <div className="p-3 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg text-xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-[#1E2D23]">IPI Industrial</span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    taxAssessment.saldoIpi > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {taxAssessment.saldoIpi > 0 ? 'A Pagar' : 'Credor'}
                </span>
              </div>
              <div className="flex justify-between text-neutral-500 text-[11px] mb-0.5">
                <span>(+) Déb: {formatBRL(taxAssessment.debitoIpi)}</span>
                <span>(−) Créd: {formatBRL(taxAssessment.creditoIpi)}</span>
              </div>
              <div className="text-right font-mono font-bold text-xs text-[#1E2D23] pt-1 border-t border-[#E2D9CE]">
                Saldo: {formatBRL(taxAssessment.saldoIpi)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: RECOMENDAÇÕES DE AUDITORIA & PLANO DE AÇÃO */}
      <div className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <Clock className="w-4 h-4 text-[#8C6D4C]" />
          <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wide font-['Montserrat',sans-serif]">
            Diagnóstico Automático de Conformidade & Ações Recomendadas
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Card 1 */}
          <div className="bg-white border border-[#E2D9CE] rounded-lg p-3.5">
            <div className="flex items-center gap-2 mb-1.5">
              <span className={`w-2 h-2 rounded-full ${entradaMetrics.pending > 0 ? 'bg-amber-600' : 'bg-emerald-600'}`} />
              <span className="font-bold text-xs text-[#1E2D23]">Escrituração de Notas Pendentes</span>
            </div>
            <p className="text-xs text-neutral-600 leading-relaxed">
              {entradaMetrics.pending > 0 ? (
                <>
                  Existem <strong>{entradaMetrics.pending} notas</strong> de compra emitidas na SEFAZ sem lançamento no TOTVS, totalizando <strong>{formatBRL(entradaMetrics.pendingVal)}</strong>. Priorize o lançamento para garantir créditos de ICMS/PIS/COFINS e evitar passivos.
                </>
              ) : (
                'Todas as notas mercantis da SEFAZ registradas no período foram devidamente escrituradas no TOTVS.'
              )}
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white border border-[#E2D9CE] rounded-lg p-3.5">
            <div className="flex items-center gap-2 mb-1.5">
              <span className={`w-2 h-2 rounded-full ${entradaMetrics.divergences > 0 ? 'bg-rose-600' : 'bg-emerald-600'}`} />
              <span className="font-bold text-xs text-[#1E2D23]">Acurácia e Divergências de Valores</span>
            </div>
            <p className="text-xs text-neutral-600 leading-relaxed">
              {entradaMetrics.divergences > 0 ? (
                <>
                  Foram identificadas <strong>{entradaMetrics.divergences} notas</strong> com divergência de valor entre o XML da SEFAZ e o registro no ERP (diferença acumulada de {formatBRL(entradaMetrics.divergenceVal)}). Verifique rateios de frete, descontos ou impostos retidos.
                </>
              ) : (
                'Nenhuma divergência de valores foi detectada entre o XML do Qive e o lançamento no TOTVS.'
              )}
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white border border-[#E2D9CE] rounded-lg p-3.5">
            <div className="flex items-center gap-2 mb-1.5">
              <span className={`w-2 h-2 rounded-full ${saidaMetrics.cancelledCount > 0 ? 'bg-amber-600' : 'bg-emerald-600'}`} />
              <span className="font-bold text-xs text-[#1E2D23]">Cancelamentos & Inutilizações</span>
            </div>
            <p className="text-xs text-neutral-600 leading-relaxed">
              {saidaMetrics.cancelledCount > 0 ? (
                <>
                  Foram registradas <strong>{saidaMetrics.cancelledCount} notas canceladas</strong> ({formatBRL(saidaMetrics.cancelledValue)}). Certifique-se de que os estornos de estoque e financeiro foram processados no ERP.
                </>
              ) : (
                'Nenhuma nota cancelada ou inutilizada foi identificada no arquivo de saídas carregado.'
              )}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
