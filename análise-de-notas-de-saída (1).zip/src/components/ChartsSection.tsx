import React, { useState, useMemo } from 'react';
import { BarChart3, TrendingUp, Calendar, Layers } from 'lucide-react';
import { InvoiceRecord, CfopSummary } from '../types/fiscal';
import { formatBRL } from '../utils/csvParser';

interface ChartsSectionProps {
  records: InvoiceRecord[];
  cfopSummaries: CfopSummary[];
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({ records, cfopSummaries }) => {
  const [activeTab, setActiveTab] = useState<'dailyCount' | 'dailyValue' | 'topCfops'>('dailyCount');

  // Daily aggregation sorted by date
  const dailyData = useMemo(() => {
    const map = new Map<string, { dateStr: string; timestamp: number; count: number; value: number }>();

    records.forEach((r) => {
      const dateStr = r.dtEmissao || 'Sem Data';
      const ts = r.dtEmissaoDate ? r.dtEmissaoDate.getTime() : 0;

      const existing = map.get(dateStr) || { dateStr, timestamp: ts, count: 0, value: 0 };
      existing.count += 1;
      existing.value += r.vlContabil;
      map.set(dateStr, existing);
    });

    return Array.from(map.values()).sort((a, b) => a.timestamp - b.timestamp);
  }, [records]);

  // Top CFOPs
  const topCfops = useMemo(() => {
    return [...cfopSummaries].sort((a, b) => b.count - a.count).slice(0, 8);
  }, [cfopSummaries]);

  // Max values for scaling
  const maxCount = Math.max(...dailyData.map((d) => d.count), 1);
  const maxValue = Math.max(...dailyData.map((d) => d.value), 1);
  const maxCfopCount = Math.max(...topCfops.map((c) => c.count), 1);

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-6">
      <div className="px-4 sm:px-6 py-3.5 bg-[#1E2D23] text-[#FAF7F2] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4]">
            <BarChart3 className="w-3.5 h-3.5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider font-['Montserrat',sans-serif] text-[#FAF7F2]">
              Gráficos de Acompanhamento
            </h2>
            <p className="text-[11px] text-[#C2B7A3]">
              Evolução temporal de emissões e concentração de volume fiscal
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-[#2A3F31] border border-[#3D5B47] p-1 rounded-md text-xs">
          <button
            id="tab-chart-daily-count"
            onClick={() => setActiveTab('dailyCount')}
            className={`px-3 py-1 rounded transition-colors ${
              activeTab === 'dailyCount'
                ? 'bg-[#D5BEA4] text-[#1E2D23] font-bold shadow-xs'
                : 'text-[#C2B7A3] hover:text-[#FAF7F2]'
            }`}
          >
            Volume Diário (Qtd)
          </button>
          <button
            id="tab-chart-daily-val"
            onClick={() => setActiveTab('dailyValue')}
            className={`px-3 py-1 rounded transition-colors ${
              activeTab === 'dailyValue'
                ? 'bg-[#D5BEA4] text-[#1E2D23] font-bold shadow-xs'
                : 'text-[#C2B7A3] hover:text-[#FAF7F2]'
            }`}
          >
            Faturamento Diário (R$)
          </button>
          <button
            id="tab-chart-top-cfops"
            onClick={() => setActiveTab('topCfops')}
            className={`px-3 py-1 rounded transition-colors ${
              activeTab === 'topCfops'
                ? 'bg-[#D5BEA4] text-[#1E2D23] font-bold shadow-xs'
                : 'text-[#C2B7A3] hover:text-[#FAF7F2]'
            }`}
          >
            Top CFOPs
          </button>
        </div>
      </div>

      <div className="p-4 sm:p-6">
        {/* Tab 1: Volume Diário */}
        {activeTab === 'dailyCount' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#8C6D4C]" />
                <span className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
                  Quantidade de Notas Fiscais Emitidas por Dia
                </span>
              </div>
              <span className="text-xs text-neutral-500">
                Pico: <strong>{maxCount}</strong> notas em um único dia
              </span>
            </div>

            {dailyData.length === 0 ? (
              <div className="py-12 text-center text-xs text-neutral-500">
                Nenhum dado com data disponível para exibição temporal.
              </div>
            ) : (
              <div className="relative pt-6 pb-2">
                {/* Horizontal grid lines */}
                <div className="h-48 flex items-end gap-1 sm:gap-2 border-b border-[#E2D9CE] px-2 overflow-x-auto">
                  {dailyData.map((d) => {
                    const heightPercent = Math.max(Math.round((d.count / maxCount) * 100), 4);
                    return (
                      <div
                        key={d.dateStr}
                        className="flex-1 min-w-[28px] max-w-[48px] flex flex-col items-center group relative cursor-pointer"
                      >
                        {/* Hover Tooltip */}
                        <div className="absolute -top-12 opacity-0 group-hover:opacity-100 transition-opacity bg-[#1E2D23] text-[#FAF7F2] text-[10px] rounded px-2 py-1 shadow-lg pointer-events-none whitespace-nowrap z-20">
                          <p className="font-bold">{d.dateStr}</p>
                          <p>{d.count} notas | {formatBRL(d.value)}</p>
                        </div>

                        {/* Bar */}
                        <div
                          style={{ height: `${heightPercent}%` }}
                          className="w-full bg-[#233527] group-hover:bg-[#1E2D23] rounded-t transition-all"
                        />

                        {/* Label */}
                        <span className="text-[10px] text-neutral-500 mt-2 font-mono truncate max-w-full">
                          {d.dateStr.slice(0, 5)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Faturamento Diário */}
        {activeTab === 'dailyValue' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#8C6D4C]" />
                <span className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
                  Valor Contábil Total Faturado por Dia
                </span>
              </div>
              <span className="text-xs text-neutral-500">
                Pico diário: <strong className="font-mono">{formatBRL(maxValue)}</strong>
              </span>
            </div>

            {dailyData.length === 0 ? (
              <div className="py-12 text-center text-xs text-neutral-500">
                Nenhum dado com data disponível para exibição temporal.
              </div>
            ) : (
              <div className="relative pt-6 pb-2">
                <div className="h-48 flex items-end gap-1 sm:gap-2 border-b border-[#E2D9CE] px-2 overflow-x-auto">
                  {dailyData.map((d) => {
                    const heightPercent = Math.max(Math.round((d.value / maxValue) * 100), 4);
                    return (
                      <div
                        key={d.dateStr}
                        className="flex-1 min-w-[28px] max-w-[48px] flex flex-col items-center group relative cursor-pointer"
                      >
                        {/* Tooltip */}
                        <div className="absolute -top-12 opacity-0 group-hover:opacity-100 transition-opacity bg-[#1E2D23] text-[#FAF7F2] text-[10px] rounded px-2 py-1 shadow-lg pointer-events-none whitespace-nowrap z-20">
                          <p className="font-bold">{d.dateStr}</p>
                          <p>{formatBRL(d.value)} ({d.count} notas)</p>
                        </div>

                        {/* Bar */}
                        <div
                          style={{ height: `${heightPercent}%` }}
                          className="w-full bg-[#8C6D4C] group-hover:bg-[#6E553A] rounded-t transition-all"
                        />

                        {/* Label */}
                        <span className="text-[10px] text-neutral-500 mt-2 font-mono truncate max-w-full">
                          {d.dateStr.slice(0, 5)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Top CFOPs */}
        {activeTab === 'topCfops' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#8C6D4C]" />
                <span className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
                  Concentração por Código Fiscal (Top 8 CFOPs)
                </span>
              </div>
              <span className="text-xs text-neutral-500">
                Ordenado por quantidade de documentos
              </span>
            </div>

            <div className="space-y-3">
              {topCfops.map((c) => {
                const widthPercent = Math.max(Math.round((c.count / maxCfopCount) * 100), 3);
                return (
                  <div key={c.cfop} className="text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold bg-[#F3EFE9] text-[#1E2D23] px-2 py-0.5 rounded border border-[#E2D9CE]">
                          {c.cfop || 'Sem CFOP'}
                        </span>
                        <span className="text-neutral-500 text-[11px]">
                          {c.count} {c.count === 1 ? 'documento' : 'documentos'}
                        </span>
                      </div>
                      <span className="font-bold font-mono text-[#1E2D23]">
                        {formatBRL(c.vlContabil)}
                      </span>
                    </div>

                    <div className="w-full bg-[#EAE4DC] rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-[#233527] h-2 rounded-full transition-all"
                        style={{ width: `${widthPercent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
