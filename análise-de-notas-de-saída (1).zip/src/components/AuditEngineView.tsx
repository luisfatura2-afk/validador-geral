import React, { useState, useMemo } from 'react';
import { InvoiceRecord } from '../types/fiscal';
import {
  RuleCategory,
  AlertSeverity,
  AuditFinding,
} from '../types/auditRules';
import {
  BeneficioFiscal,
  TipoBeneficioFiscal,
} from '../types/beneficioFiscal';
import { regrasService } from '../services/regrasService';
import {
  ShieldAlert,
  ShieldCheck,
  Search,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  Info,
  BookOpen,
  ArrowRight,
  Tag,
  Plus,
  Edit2,
  Trash2,
  RotateCcw,
  Check,
  Layers,
  FileCheck2,
} from 'lucide-react';
import { AlertBadge } from './common/AlertBadge';
import { EmptyState } from './common/EmptyState';
import { BeneficioFiscalModal } from './BeneficioFiscalModal';

interface AuditEngineViewProps {
  records: InvoiceRecord[];
  onSelectInvoice?: (record: InvoiceRecord) => void;
  onLoadDemoData: () => void;
}

export const AuditEngineView: React.FC<AuditEngineViewProps> = ({
  records,
  onSelectInvoice,
  onLoadDemoData,
}) => {
  const [activeTab, setActiveTab] = useState<'DIAGNOSTICO' | 'BENEFICIOS'>('DIAGNOSTICO');
  const [selectedCategory, setSelectedCategory] = useState<RuleCategory | 'ALL'>('ALL');
  const [selectedSeverity, setSelectedSeverity] = useState<AlertSeverity | 'ALL'>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [showCatalogModal, setShowCatalogModal] = useState(false);

  // Benefícios Fiscais state
  const [beneficiosList, setBeneficiosList] = useState<BeneficioFiscal[]>(() =>
    regrasService.getBeneficios()
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBeneficio, setEditingBeneficio] = useState<BeneficioFiscal | null>(null);
  const [beneficioSearch, setBeneficioSearch] = useState('');

  // Execute audit rules with current configured benefits
  const auditSummary = useMemo(() => {
    return regrasService.auditarDocumentos(records, beneficiosList);
  }, [records, beneficiosList]);

  // Filtered findings
  const filteredFindings = useMemo(() => {
    return regrasService.filtrarApontamentos(auditSummary.findings, {
      category: selectedCategory,
      severity: selectedSeverity,
      busca: searchTerm,
    });
  }, [auditSummary.findings, selectedCategory, selectedSeverity, searchTerm]);

  // Benefícios statistics
  const beneficiosStats = useMemo(() => {
    return regrasService.calcularEstatisticasBeneficios(beneficiosList, records);
  }, [beneficiosList, records]);

  // Filtered Benefícios table
  const filteredBeneficios = useMemo(() => {
    if (!beneficioSearch.trim()) return beneficiosList;
    const q = beneficioSearch.toLowerCase().trim();
    return beneficiosList.filter((b) => {
      return (
        b.codigo.toLowerCase().includes(q) ||
        b.nome.toLowerCase().includes(q) ||
        b.uf.toLowerCase().includes(q) ||
        b.baseLegal.toLowerCase().includes(q) ||
        b.cfops.some((c) => c.includes(q))
      );
    });
  }, [beneficiosList, beneficioSearch]);

  const registeredRules = useMemo(() => {
    return regrasService.getRegrasDisponiveis();
  }, []);

  const formatBRL = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const categoriesConfig: { key: RuleCategory; label: string; desc: string }[] = [
    { key: 'BENEFICIO_FISCAL', label: 'Benefícios Fiscais', desc: 'Isenções, reduções de base e diferimentos vinculados a CFOP' },
    { key: 'CFOP', label: 'CFOP', desc: 'Códigos fiscais, sentido de circulação e operações' },
    { key: 'ICMS', label: 'ICMS', desc: 'Bases de cálculo, alíquotas e destaques do imposto' },
    { key: 'PIS', label: 'PIS', desc: 'Contribuição para o PIS e assimetria de bases' },
    { key: 'COFINS', label: 'COFINS', desc: 'Contribuição para o COFINS e alíquotas' },
    { key: 'IBS', label: 'IBS', desc: 'Imposto sobre Bens e Serviços (Reforma Tributária)' },
    { key: 'CBS', label: 'CBS', desc: 'Contribuição sobre Bens e Serviços (Reforma Tributária)' },
    { key: 'CST', label: 'CST / CSOSN', desc: 'Coerência tributária e regimes tributários' },
    { key: 'DUPLICIDADE', label: 'Duplicidades', desc: 'Chaves de 44 dígitos e Número + Série duplicados' },
    { key: 'DIVERGENCIA', label: 'Divergências', desc: 'Diferenças entre valor contábil e desdobros' },
    { key: 'DOCUMENTO_INVALIDO', label: 'Doc. Inválidos', desc: 'Canceladas, denegadas ou inutilizadas' },
    { key: 'CAMPOS_AUSENTES', label: 'Campos Ausentes', desc: 'Chaves faltantes ou valores zerados' },
  ];

  // Benefício Handlers
  const handleOpenCreateModal = () => {
    setEditingBeneficio(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (beneficio: BeneficioFiscal) => {
    setEditingBeneficio(beneficio);
    setIsModalOpen(true);
  };

  const handleSaveBeneficio = (
    data: Omit<BeneficioFiscal, 'id' | 'criadoEm'> & { id?: string }
  ) => {
    regrasService.salvarBeneficio(data);
    setBeneficiosList(regrasService.getBeneficios());
  };

  const handleDeleteBeneficio = (id: string, nome: string) => {
    if (confirm(`Deseja realmente excluir o benefício fiscal "${nome}"?`)) {
      regrasService.excluirBeneficio(id);
      setBeneficiosList(regrasService.getBeneficios());
    }
  };

  const handleClearAllBeneficios = () => {
    if (confirm('Deseja realmente excluir TODOS os benefícios fiscais cadastrados?')) {
      regrasService.excluirTodosBeneficios();
      setBeneficiosList([]);
    }
  };

  const handleToggleStatus = (id: string) => {
    regrasService.alternarStatusBeneficio(id);
    setBeneficiosList(regrasService.getBeneficios());
  };

  const handleLoadExamples = () => {
    if (confirm('Deseja carregar a lista de modelos de benefícios fiscais sugeridos (Isenção Hortifruti, Redução Cesta Básica, Diferimento Agropecuário)?')) {
      const templates = regrasService.carregarExemplosSugeridos();
      setBeneficiosList(templates);
    }
  };

  const getTipoBeneficioBadge = (tipo: TipoBeneficioFiscal) => {
    switch (tipo) {
      case 'ISENCAO':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">Isenção Total</span>;
      case 'REDUCAO_BASE':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">Redução de Base</span>;
      case 'DIFERIMENTO':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-300">Diferimento</span>;
      case 'SUSPENSAO':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-300">Suspensão</span>;
      case 'NAO_INCIDENCIA':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 text-neutral-800 border border-neutral-300">Não Incidência</span>;
      case 'CREDITO_PRESUMIDO':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-800 border border-orange-300">Crédito Presumido</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 text-neutral-700 border border-neutral-200">Outros</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E2D9CE]">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#1E2D23] font-['Montserrat',sans-serif] flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-[#8C6D4C]" />
                Motor de Auditoria Fiscal & Regras de Conformidade
              </h2>
              <span className="text-[10px] bg-[#FAF3EA] text-[#8C6D4C] border border-[#E8DCCB] font-bold px-2 py-0.5 rounded uppercase">
                {auditSummary.totalAnalyzed} analisados
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              Validação automatizada de regras por categorias fiscais e conformidade de Benefícios Fiscais vinculados a CFOPs.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowCatalogModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF8F5] hover:bg-[#FAF3EA] border border-[#E2D9CE] rounded-lg text-xs font-bold text-[#1E2D23] transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#8C6D4C]" />
              <span>Catálogo de Regras ({registeredRules.length})</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 mt-4">
          <button
            onClick={() => setActiveTab('DIAGNOSTICO')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'DIAGNOSTICO'
                ? 'bg-[#1E2D23] text-[#FAF7F2] shadow-xs'
                : 'bg-[#FAF8F5] text-neutral-600 border border-[#E2D9CE] hover:bg-[#FAF3EA]'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-[#D5BEA4]" />
            <span>Diagnóstico & Ocorrências</span>
            {auditSummary.findings.length > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
                  activeTab === 'DIAGNOSTICO' ? 'bg-[#D5BEA4] text-[#1E2D23]' : 'bg-neutral-200 text-neutral-800'
                }`}
              >
                {auditSummary.findings.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('BENEFICIOS')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'BENEFICIOS'
                ? 'bg-[#1E2D23] text-[#FAF7F2] shadow-xs'
                : 'bg-[#FAF8F5] text-neutral-600 border border-[#E2D9CE] hover:bg-[#FAF3EA]'
            }`}
          >
            <Tag className="w-4 h-4 text-[#D5BEA4]" />
            <span>Benefícios Fiscais & Vínculo CFOP</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
                activeTab === 'BENEFICIOS' ? 'bg-[#D5BEA4] text-[#1E2D23]' : 'bg-[#E8DCCB] text-[#1E2D23]'
              }`}
            >
              {beneficiosList.length} cadastrados
            </span>
            {beneficiosStats.inconsistenciasDetectadas > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" title="Inconsistências em benefícios detectadas" />
            )}
          </button>
        </div>
      </div>

      {/* ======================================================== */}
      {/* TAB 1: DIAGNÓSTICO FISCAL & OCORRÊNCIAS                   */}
      {/* ======================================================== */}
      {activeTab === 'DIAGNOSTICO' && (
        <>
          {records.length === 0 ? (
            <EmptyState
              title="Nenhum registro para auditoria"
              description="Carregue notas fiscais para submetê-las à verificação automatizada pelo motor de regras fiscais e conferir aderência aos benefícios cadastrados."
              icon={ShieldCheck}
              actionButton={
                <button
                  onClick={onLoadDemoData}
                  className="px-4 py-2 bg-[#D5BEA4] hover:bg-[#C2A588] text-[#1E2D23] text-xs font-bold uppercase tracking-wider rounded-lg transition-all shadow-sm"
                >
                  Carregar Dados de Demonstração
                </button>
              }
            />
          ) : (
            <div className="space-y-6">
              {/* 4 Standardized Severity KPIs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                <div
                  onClick={() => setSelectedSeverity(selectedSeverity === 'OK' ? 'ALL' : 'OK')}
                  className={`p-4 rounded-xl border cursor-pointer transition-all bg-white ${
                    selectedSeverity === 'OK'
                      ? 'border-emerald-400 ring-2 ring-emerald-500 bg-emerald-50/40'
                      : 'border-[#E2D9CE] hover:border-emerald-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                      🟢 Documentos OK
                    </span>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-1.5 py-0.2 rounded font-mono">
                      {auditSummary.totalAnalyzed > 0
                        ? `${((auditSummary.okCount / auditSummary.totalAnalyzed) * 100).toFixed(0)}%`
                        : '0%'}
                    </span>
                  </div>
                  <div className="text-2xl font-black text-emerald-950 font-mono">
                    {auditSummary.okCount}
                  </div>
                  <span className="text-[11px] text-emerald-800 mt-0.5 block">
                    100% aderentes às regras
                  </span>
                </div>

                <div
                  onClick={() => setSelectedSeverity(selectedSeverity === 'ATENCAO' ? 'ALL' : 'ATENCAO')}
                  className={`p-4 rounded-xl border cursor-pointer transition-all bg-white ${
                    selectedSeverity === 'ATENCAO'
                      ? 'border-amber-400 ring-2 ring-amber-500 bg-amber-50/40'
                      : 'border-[#E2D9CE] hover:border-amber-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-700" />
                      🟡 Pontos de Atenção
                    </span>
                  </div>
                  <div className="text-2xl font-black text-amber-950 font-mono">
                    {auditSummary.attentionCount}
                  </div>
                  <span className="text-[11px] text-amber-800 mt-0.5 block">
                    Divergências leves ou cadastrais
                  </span>
                </div>

                <div
                  onClick={() => setSelectedSeverity(selectedSeverity === 'CRITICO' ? 'ALL' : 'CRITICO')}
                  className={`p-4 rounded-xl border cursor-pointer transition-all bg-white ${
                    selectedSeverity === 'CRITICO'
                      ? 'border-rose-400 ring-2 ring-rose-500 bg-rose-50/40'
                      : 'border-[#E2D9CE] hover:border-rose-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-rose-900 flex items-center gap-1.5">
                      <AlertOctagon className="w-4 h-4 text-rose-700" />
                      🔴 Inconsistências Críticas
                    </span>
                  </div>
                  <div className="text-2xl font-black text-rose-950 font-mono">
                    {auditSummary.criticalCount}
                  </div>
                  <span className="text-[11px] text-rose-800 mt-0.5 block">
                    Risco fiscal (Destaque indevido / Duplicidade)
                  </span>
                </div>

                <div
                  onClick={() => setSelectedSeverity(selectedSeverity === 'INFORMATIVO' ? 'ALL' : 'INFORMATIVO')}
                  className={`p-4 rounded-xl border cursor-pointer transition-all bg-white ${
                    selectedSeverity === 'INFORMATIVO'
                      ? 'border-sky-400 ring-2 ring-sky-500 bg-sky-50/40'
                      : 'border-[#E2D9CE] hover:border-sky-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-sky-900 flex items-center gap-1.5">
                      <Info className="w-4 h-4 text-sky-700" />
                      🔵 Informativos & Reforma
                    </span>
                  </div>
                  <div className="text-2xl font-black text-sky-950 font-mono">
                    {auditSummary.infoCount}
                  </div>
                  <span className="text-[11px] text-sky-800 mt-0.5 block">
                    IBS/CBS e notas sem destaque
                  </span>
                </div>
              </div>

              {/* Categories & Filter Bar */}
              <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-neutral-500">
                    Filtrar por Categoria Fiscal:
                  </div>
                  {auditSummary.findingsByCategory.BENEFICIO_FISCAL > 0 && (
                    <button
                      onClick={() => setSelectedCategory('BENEFICIO_FISCAL')}
                      className="text-xs font-bold text-rose-700 hover:underline flex items-center gap-1"
                    >
                      <Tag className="w-3.5 h-3.5" />
                      <span>{auditSummary.findingsByCategory.BENEFICIO_FISCAL} ocorrência(s) de Benefício Fiscal</span>
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={() => setSelectedCategory('ALL')}
                    className={`px-2.5 py-1 rounded text-xs font-bold transition-all ${
                      selectedCategory === 'ALL'
                        ? 'bg-[#1E2D23] text-[#FAF7F2]'
                        : 'bg-[#FAF8F5] text-neutral-600 hover:bg-[#E2D9CE]/60'
                    }`}
                  >
                    Todas ({auditSummary.findings.length})
                  </button>
                  {categoriesConfig.map((cat) => {
                    const count = auditSummary.findingsByCategory[cat.key] || 0;
                    const isSelected = selectedCategory === cat.key;
                    const isBeneficio = cat.key === 'BENEFICIO_FISCAL';
                    return (
                      <button
                        key={cat.key}
                        onClick={() => setSelectedCategory(cat.key)}
                        className={`px-2.5 py-1 rounded text-xs font-bold transition-all flex items-center gap-1.5 ${
                          isSelected
                            ? 'bg-[#1E2D23] text-[#FAF7F2]'
                            : count > 0
                            ? isBeneficio
                              ? 'bg-rose-50 text-rose-800 border border-rose-300 hover:bg-rose-100'
                              : 'bg-[#FAF8F5] text-[#1E2D23] border border-[#E2D9CE] hover:bg-[#E2D9CE]/40'
                            : 'bg-[#FAF8F5] text-neutral-400 opacity-60'
                        }`}
                      >
                        {isBeneficio && <Tag className="w-3 h-3 text-[#8C6D4C]" />}
                        <span>{cat.label}</span>
                        {count > 0 && (
                          <span
                            className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                              isSelected
                                ? 'bg-[#D5BEA4] text-[#1E2D23]'
                                : isBeneficio
                                ? 'bg-rose-200 text-rose-900 font-bold'
                                : 'bg-neutral-200 text-neutral-700'
                            }`}
                          >
                            {count}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Search */}
                <div className="mt-4 pt-3 border-t border-[#E2D9CE] flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="w-full sm:w-96 relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                    <input
                      type="text"
                      placeholder="Buscar por ocorrência, CFOP, regra, nota fiscal ou cliente..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-9 pr-3 py-1.5 text-xs border border-[#E2D9CE] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
                    />
                  </div>

                  <div className="text-xs text-neutral-500 font-medium">
                    Exibindo <strong>{filteredFindings.length}</strong> de{' '}
                    <strong>{auditSummary.findings.length}</strong> apontamentos
                  </div>
                </div>
              </div>

              {/* Findings List */}
              <div className="space-y-3">
                {filteredFindings.length === 0 ? (
                  <div className="bg-white border border-[#E2D9CE] rounded-xl p-8 text-center shadow-xs">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                    <h4 className="text-sm font-bold text-[#1E2D23]">
                      Nenhum apontamento encontrado para este filtro
                    </h4>
                    <p className="text-xs text-neutral-500 mt-1">
                      Todos os documentos correspondentes estão conformes com os critérios selecionados e com os benefícios fiscais ativos.
                    </p>
                  </div>
                ) : (
                  filteredFindings.map((finding) => {
                    const associatedRecord = records.find(
                      (r) =>
                        (finding.documentNumber && r.notaFiscal === finding.documentNumber) ||
                        (finding.documentKey && r.chaveAcesso === finding.documentKey)
                    );

                    const isBeneficioFinding = finding.category === 'BENEFICIO_FISCAL';

                    return (
                      <div
                        key={finding.id}
                        className={`bg-white border rounded-xl p-4 sm:p-5 shadow-xs transition-colors ${
                          isBeneficioFinding
                            ? 'border-amber-300 hover:border-amber-400 bg-amber-50/20'
                            : 'border-[#E2D9CE] hover:border-[#8C6D4C]/40'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                          <div className="flex items-start gap-3">
                            <div className="mt-0.5">
                              <AlertBadge severity={finding.severity} size="sm" />
                            </div>
                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="font-mono text-xs font-bold text-neutral-500">
                                  [{finding.ruleCode}]
                                </span>
                                <h4 className="text-sm font-bold text-[#1E2D23]">
                                  {finding.title}
                                </h4>
                                <span
                                  className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                                    isBeneficioFinding
                                      ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                      : 'bg-neutral-100 text-neutral-700'
                                  }`}
                                >
                                  {finding.category.replace('_', ' ')}
                                </span>
                                {finding.cfop && (
                                  <span className="text-[10px] bg-[#E8DCCB] text-[#1E2D23] font-mono font-bold px-1.5 py-0.5 rounded">
                                    CFOP {finding.cfop}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-neutral-600 mt-1 leading-relaxed">
                                {finding.description}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 self-start">
                            {isBeneficioFinding && (
                              <button
                                onClick={() => setActiveTab('BENEFICIOS')}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-[#8C6D4C] bg-[#FAF3EA] hover:bg-[#F3E7D5] border border-[#E8DCCB] rounded transition-colors"
                              >
                                <Tag className="w-3 h-3" />
                                <span>Ver Benefício</span>
                              </button>
                            )}

                            {associatedRecord && onSelectInvoice && (
                              <button
                                onClick={() => onSelectInvoice(associatedRecord)}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-[#1E2D23] bg-[#FAF8F5] hover:bg-[#FAF3EA] border border-[#E2D9CE] rounded transition-colors"
                              >
                                <span>Ver NF</span>
                                <ArrowRight className="w-3 h-3 text-[#8C6D4C]" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Details Footer */}
                        <div className="mt-3 pt-3 border-t border-[#E2D9CE]/60 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                          <div>
                            <span className="text-[10px] text-neutral-400 block uppercase">
                              Nota Fiscal / Série
                            </span>
                            <span className="font-mono font-bold text-[#1E2D23]">
                              NF {finding.documentNumber || 'S/N'} (Série {finding.documentSerie || '0'})
                            </span>
                          </div>

                          <div>
                            <span className="text-[10px] text-neutral-400 block uppercase">
                              Pessoa / Entidade
                            </span>
                            <span className="font-semibold text-neutral-700 truncate block" title={finding.entityName}>
                              {finding.entityName || 'Não informada'}
                            </span>
                          </div>

                          <div>
                            <span className="text-[10px] text-neutral-400 block uppercase">
                              Impacto / Valor
                            </span>
                            <span className="font-mono font-bold text-[#1E2D23]">
                              {finding.impactValue ? formatBRL(finding.impactValue) : '—'}
                            </span>
                          </div>

                          <div>
                            <span className="text-[10px] text-neutral-400 block uppercase">
                              Ação Recomendada
                            </span>
                            <span className="text-neutral-600 text-[11px] block truncate" title={finding.suggestedAction}>
                              {finding.suggestedAction || 'Auditar lançamento contábil.'}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </>
      )}

      {/* ======================================================== */}
      {/* TAB 2: CADASTRO DE BENEFÍCIOS FISCAIS & VÍNCULO CFOP     */}
      {/* ======================================================== */}
      {activeTab === 'BENEFICIOS' && (
        <div className="space-y-6">
          {/* Top Benefício KPIs */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
            <div className="bg-white border border-[#E2D9CE] rounded-xl p-4 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
                Benefícios Cadastrados
              </span>
              <div className="text-2xl font-black text-[#1E2D23] font-mono">
                {beneficiosStats.totalBeneficios}
              </div>
              <span className="text-[11px] text-neutral-400 mt-0.5 block">
                {beneficiosStats.beneficiosAtivos} ativos no motor
              </span>
            </div>

            <div className="bg-white border border-[#E2D9CE] rounded-xl p-4 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
                CFOPs Vinculados
              </span>
              <div className="text-2xl font-black text-[#8C6D4C] font-mono">
                {beneficiosStats.totalCfopsVinculados}
              </div>
              <span className="text-[11px] text-neutral-400 mt-0.5 block">
                Códigos sob monitoramento
              </span>
            </div>

            <div className="bg-white border border-[#E2D9CE] rounded-xl p-4 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
                Documentos no Lote
              </span>
              <div className="text-2xl font-black text-sky-950 font-mono">
                {beneficiosStats.documentosAtingidos}
              </div>
              <span className="text-[11px] text-sky-700 mt-0.5 block">
                Notas com CFOP vinculado
              </span>
            </div>

            <div className="bg-white border border-[#E2D9CE] rounded-xl p-4 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
                Valor Total Abrangido
              </span>
              <div className="text-xl font-black text-[#1E2D23] font-mono truncate" title={formatBRL(beneficiosStats.totalValorBeneficio)}>
                {formatBRL(beneficiosStats.totalValorBeneficio)}
              </div>
              <span className="text-[11px] text-neutral-400 mt-0.5 block">
                Movimentação nas operações
              </span>
            </div>

            <div className="bg-white border border-[#E2D9CE] rounded-xl p-4 shadow-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block mb-1">
                Inconsistências
              </span>
              <div
                className={`text-2xl font-black font-mono ${
                  beneficiosStats.inconsistenciasDetectadas > 0 ? 'text-rose-600' : 'text-emerald-700'
                }`}
              >
                {beneficiosStats.inconsistenciasDetectadas}
              </div>
              <span className="text-[11px] text-neutral-400 mt-0.5 block">
                {beneficiosStats.inconsistenciasDetectadas > 0 ? 'Exigem intervenção fiscal' : 'Nenhuma divergência'}
              </span>
            </div>
          </div>

          {/* Action Bar */}
          <div className="bg-white border border-[#E2D9CE] rounded-xl p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex-1 max-w-md relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="text"
                placeholder="Filtrar benefícios por CFOP, cBenef, nome ou UF..."
                value={beneficioSearch}
                onChange={(e) => setBeneficioSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs border border-[#E2D9CE] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
              />
            </div>

            <div className="flex items-center gap-2">
              {beneficiosList.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearAllBeneficios}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg text-xs font-bold text-rose-700 transition-colors flex items-center gap-1.5"
                  title="Excluir todos os benefícios fiscais cadastrados de uma só vez"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>Excluir Todos</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleLoadExamples}
                className="px-3 py-1.5 bg-[#FAF8F5] hover:bg-[#FAF3EA] border border-[#E2D9CE] rounded-lg text-xs font-bold text-neutral-700 transition-colors flex items-center gap-1.5"
                title="Carregar modelos de exemplo (Isenção Hortifruti, Redução Cesta Básica, Diferimento Agropecuário)"
              >
                <RotateCcw className="w-3.5 h-3.5 text-neutral-500" />
                <span>Carregar Exemplos</span>
              </button>

              <button
                type="button"
                onClick={handleOpenCreateModal}
                className="px-4 py-1.5 bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4 text-[#D5BEA4]" />
                <span>Cadastrar Benefício Fiscal</span>
              </button>
            </div>
          </div>

          {/* Table of Benefícios Fiscais */}
          <div className="bg-white border border-[#E2D9CE] rounded-xl shadow-xs overflow-hidden">
            <div className="p-4 border-b border-[#E2D9CE] flex items-center justify-between bg-[#FAF8F5]">
              <div className="flex items-center gap-2">
                <Tag className="w-4 h-4 text-[#8C6D4C]" />
                <h3 className="text-sm font-bold text-[#1E2D23] font-['Montserrat',sans-serif]">
                  Tabela de Benefícios Fiscais e Vínculos com CFOP
                </h3>
              </div>
              <span className="text-xs text-neutral-500 font-medium">
                {filteredBeneficios.length} de {beneficiosList.length} registros
              </span>
            </div>

            {filteredBeneficios.length === 0 ? (
              <div className="p-10 text-center">
                <div className="w-12 h-12 rounded-full bg-[#FAF3EA] text-[#8C6D4C] flex items-center justify-center mx-auto mb-3">
                  <Tag className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-[#1E2D23]">
                  Nenhum benefício fiscal cadastrado
                </h4>
                <p className="text-xs text-neutral-500 mt-1 max-w-md mx-auto mb-5 leading-relaxed">
                  Cadastre um benefício fiscal personalizado e vincule aos CFOPs desejados para que o motor valide automaticamente desonerações, bases de cálculo e alíquotas.
                </p>
                <div className="flex items-center justify-center gap-3">
                  <button
                    onClick={handleOpenCreateModal}
                    className="px-4 py-2 bg-[#1E2D23] hover:bg-[#2A3F31] text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm"
                  >
                    <Plus className="w-4 h-4 text-[#D5BEA4]" />
                    <span>Cadastrar Novo Benefício</span>
                  </button>
                  <button
                    onClick={handleLoadExamples}
                    className="px-4 py-2 bg-[#FAF8F5] hover:bg-[#FAF3EA] border border-[#E2D9CE] text-[#1E2D23] rounded-lg text-xs font-bold transition-all"
                  >
                    Carregar Modelos Sugeridos
                  </button>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF8F5] border-b border-[#E2D9CE] text-[10px] font-bold uppercase tracking-wider text-neutral-500">
                    <tr>
                      <th className="py-2.5 px-3">Código</th>
                      <th className="py-2.5 px-3">Benefício Fiscal & Base Legal</th>
                      <th className="py-2.5 px-3">Modalidade</th>
                      <th className="py-2.5 px-3">CFOPs Vinculados</th>
                      <th className="py-2.5 px-3 text-center">UF</th>
                      <th className="py-2.5 px-3 text-center">CST</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                      <th className="py-2.5 px-3 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2D9CE]/60">
                    {filteredBeneficios.map((b) => (
                      <tr key={b.id} className="hover:bg-[#FAF8F5]/80 transition-colors">
                        {/* Código */}
                        <td className="py-3 px-3 align-top font-mono font-bold text-[#1E2D23]">
                          <span className="bg-[#FAF3EA] border border-[#E8DCCB] text-[#8C6D4C] px-2 py-0.5 rounded text-[11px]">
                            {b.codigo}
                          </span>
                        </td>

                        {/* Nome + Base Legal */}
                        <td className="py-3 px-3 align-top max-w-xs">
                          <div className="font-bold text-[#1E2D23] text-xs leading-tight">
                            {b.nome}
                          </div>
                          <div className="text-[10px] text-neutral-500 mt-0.5 flex items-center gap-1 font-mono">
                            <span>Ref: {b.baseLegal}</span>
                          </div>
                          {b.percentualReducao && (
                            <div className="text-[10px] text-amber-800 font-bold mt-0.5">
                              Redução: {b.percentualReducao}% | Alíq. Efetiva: {b.aliquotaEfetiva || 0}%
                            </div>
                          )}
                        </td>

                        {/* Modalidade */}
                        <td className="py-3 px-3 align-top">
                          {getTipoBeneficioBadge(b.tipoBeneficio)}
                        </td>

                        {/* CFOPs vinculados */}
                        <td className="py-3 px-3 align-top">
                          <div className="flex flex-wrap gap-1 max-w-xs">
                            {b.cfops.map((c) => (
                              <span
                                key={c}
                                className="px-1.5 py-0.5 rounded bg-[#E8DCCB] text-[#1E2D23] font-mono font-bold text-[10px] border border-[#CBB8A1]"
                              >
                                {c}
                              </span>
                            ))}
                          </div>
                        </td>

                        {/* UF */}
                        <td className="py-3 px-3 align-top text-center font-bold text-neutral-700">
                          {b.uf}
                        </td>

                        {/* CST Esperado */}
                        <td className="py-3 px-3 align-top text-center font-mono font-bold text-neutral-600">
                          {b.cstEsperado ? `CST ${b.cstEsperado}` : '—'}
                        </td>

                        {/* Status Toggle */}
                        <td className="py-3 px-3 align-top text-center">
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(b.id)}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition-all ${
                              b.ativo
                                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                : 'bg-neutral-100 text-neutral-500 hover:bg-neutral-200'
                            }`}
                          >
                            {b.ativo ? 'Ativo' : 'Inativo'}
                          </button>
                        </td>

                        {/* Ações */}
                        <td className="py-3 px-3 align-top text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              type="button"
                              onClick={() => handleOpenEditModal(b)}
                              className="p-1 text-neutral-500 hover:text-[#1E2D23] hover:bg-neutral-100 rounded transition-colors"
                              title="Editar benefício"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteBeneficio(b.id, b.nome)}
                              className="p-1 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                              title="Excluir benefício"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Practical Application Explanatory Card */}
          <div className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-xl p-5 shadow-xs">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#D5BEA4] text-[#1E2D23] flex items-center justify-center font-bold shrink-0">
                <FileCheck2 className="w-4 h-4" />
              </div>
              <div className="space-y-1 text-xs">
                <h4 className="font-bold text-[#1E2D23] font-['Montserrat',sans-serif]">
                  Como o Vínculo com CFOP atua no Motor de Regras:
                </h4>
                <p className="text-neutral-600 leading-relaxed">
                  Ao cadastrar um benefício fiscal e vinculá-lo a uma lista de CFOPs (ex: 5.101, 5.102, 6.101), o sistema inspeciona imediatamente todas as notas carregadas:
                </p>
                <ul className="list-disc list-inside text-neutral-600 space-y-1 pt-1">
                  <li>
                    <strong>Isenção / Diferimento / Suspensão:</strong> Alerta como <span className="text-rose-700 font-bold">🔴 Crítico</span> se o documento com esse CFOP apresentar ICMS destacado maior que zero, ou <span className="text-amber-700 font-bold">🟡 Atenção</span> se o desdobro de isenção estiver zerado.
                  </li>
                  <li>
                    <strong>Redução de Base de Cálculo:</strong> Alerta como <span className="text-amber-700 font-bold">🟡 Atenção</span> se a Base de Cálculo do ICMS for igual ou superior ao Valor Contábil.
                  </li>
                  <li>
                    <strong>Exportação / Não Incidência:</strong> Valida operações com CFOPs 7.xxx garantindo imunidade constitucional sem tributação indevida.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Catalog Modal */}
      {showCatalogModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-[#E2D9CE] max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl">
            <div className="p-5 border-b border-[#E2D9CE] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#8C6D4C]" />
                <h3 className="text-base font-bold text-[#1E2D23] font-['Montserrat',sans-serif]">
                  Catálogo de Regras Fiscais Cadastradas
                </h3>
              </div>
              <button
                onClick={() => setShowCatalogModal(false)}
                className="text-neutral-400 hover:text-neutral-700 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-3 flex-1 text-xs">
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-lg">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-amber-900">[BENEF-CFOP]</span>
                    <span className="font-bold text-[#1E2D23]">Regras Dinâmicas de Benefício Fiscal por CFOP</span>
                  </div>
                  <AlertBadge severity="CRITICO" size="sm" />
                </div>
                <p className="text-neutral-600 mt-1">
                  Verifica notas fiscais com CFOP vinculado a benefícios ativos (Isenção, Redução de Base, Diferimento). Aponta destaque indevido de ICMS ou falta de desoneração.
                </p>
                <div className="text-[10px] text-neutral-500 mt-1.5 font-mono">
                  Ref. Legal: Tabela cBenef SEFAZ / Legislação Estadual Específica
                </div>
              </div>

              {registeredRules.map((rule) => (
                <div key={rule.id} className="p-3 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-neutral-600">[{rule.code}]</span>
                      <span className="font-bold text-[#1E2D23]">{rule.name}</span>
                    </div>
                    <AlertBadge severity={rule.defaultSeverity} size="sm" />
                  </div>
                  <p className="text-neutral-600 mt-1">{rule.description}</p>
                  {rule.legalReference && (
                    <div className="text-[10px] text-neutral-400 mt-1.5 font-mono">
                      Ref. Legal: {rule.legalReference}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-[#E2D9CE] flex justify-end">
              <button
                onClick={() => setShowCatalogModal(false)}
                className="px-4 py-2 bg-[#1E2D23] text-white rounded-lg text-xs font-bold"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cadastro / Edição de Benefício Fiscal Modal */}
      <BeneficioFiscalModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveBeneficio}
        editingBeneficio={editingBeneficio}
      />
    </div>
  );
};
