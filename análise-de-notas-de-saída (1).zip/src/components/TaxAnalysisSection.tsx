import React, { useState, useMemo } from 'react';
import {
  Landmark,
  ShieldAlert,
  ArrowRightLeft,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
  Layers,
  ArrowDownRight,
  ArrowUpRight,
  Receipt,
  Scale
} from 'lucide-react';
import { TaxTotals } from '../types/fiscal';
import { formatBRL } from '../utils/csvParser';

interface TaxAnalysisSectionProps {
  taxTotals: TaxTotals; // Débitos (Saídas)
  totalContabil: number;
  creditoTaxTotals?: TaxTotals; // Créditos (Entradas)
  hasEntradaData?: boolean;
  entradaSourceLabel?: string;
  onNavigateToEntrada?: () => void;
  onLoadDemoData?: () => void;
}

interface TaxLineCalculation {
  code: string;
  name: string;
  category: 'ESTADUAL' | 'FEDERAL' | 'REFORMA';
  debito: number;
  credito: number;
  saldo: number; // debito - credito
  status: 'DEVEDOR' | 'CREDOR' | 'ZERADO';
  desc: string;
}

export const TaxAnalysisSection: React.FC<TaxAnalysisSectionProps> = ({
  taxTotals,
  totalContabil,
  creditoTaxTotals,
  hasEntradaData = false,
  entradaSourceLabel,
  onNavigateToEntrada,
  onLoadDemoData,
}) => {
  const [activeTab, setActiveTab] = useState<'APURACAO' | 'DEBITOS' | 'CREDITOS'>('APURACAO');
  const [manualCreditAdjustments, setManualCreditAdjustments] = useState<Partial<Record<string, number>>>({});
  const [showSimulador, setShowSimulador] = useState(false);

  // Safe credit totals (default to 0 if not provided)
  const defaultCredits: TaxTotals = useMemo(
    () =>
      creditoTaxTotals || {
        icms: 0,
        baseIcms: 0,
        isentoIcms: 0,
        outroIcms: 0,
        icmsSt: 0,
        ipi: 0,
        pis: 0,
        cofins: 0,
        fcp: 0,
        fcpSt: 0,
        ibs: 0,
        cbs: 0,
        is: 0,
      },
    [creditoTaxTotals]
  );

  // Combine automatic credits with any user simulation
  const effectiveCredits = useMemo<TaxTotals>(() => {
    return {
      icms: (defaultCredits.icms || 0) + (manualCreditAdjustments['ICMS'] || 0),
      baseIcms: defaultCredits.baseIcms || 0,
      isentoIcms: defaultCredits.isentoIcms || 0,
      outroIcms: defaultCredits.outroIcms || 0,
      icmsSt: (defaultCredits.icmsSt || 0) + (manualCreditAdjustments['ICMS ST'] || 0),
      ipi: (defaultCredits.ipi || 0) + (manualCreditAdjustments['IPI'] || 0),
      pis: (defaultCredits.pis || 0) + (manualCreditAdjustments['PIS'] || 0),
      cofins: (defaultCredits.cofins || 0) + (manualCreditAdjustments['COFINS'] || 0),
      fcp: (defaultCredits.fcp || 0) + (manualCreditAdjustments['FCP'] || 0),
      fcpSt: (defaultCredits.fcpSt || 0) + (manualCreditAdjustments['FCP ST'] || 0),
      ibs: (defaultCredits.ibs || 0) + (manualCreditAdjustments['IBS'] || 0),
      cbs: (defaultCredits.cbs || 0) + (manualCreditAdjustments['CBS'] || 0),
      is: (defaultCredits.is || 0) + (manualCreditAdjustments['IS'] || 0),
    };
  }, [defaultCredits, manualCreditAdjustments]);

  // Line-by-line calculations (Debit - Credit)
  const taxLines = useMemo<TaxLineCalculation[]>(() => {
    const lines = [
      {
        code: 'ICMS',
        name: 'ICMS Próprio',
        category: 'ESTADUAL' as const,
        debito: taxTotals.icms,
        credito: effectiveCredits.icms,
        desc: 'Imposto Estadual sobre Circulação de Mercadorias',
      },
      {
        code: 'PIS',
        name: 'PIS / PASEP',
        category: 'FEDERAL' as const,
        debito: taxTotals.pis,
        credito: effectiveCredits.pis,
        desc: 'Contribuição Programa Integração Social',
      },
      {
        code: 'COFINS',
        name: 'COFINS',
        category: 'FEDERAL' as const,
        debito: taxTotals.cofins,
        credito: effectiveCredits.cofins,
        desc: 'Financiamento da Seguridade Social',
      },
      {
        code: 'IPI',
        name: 'IPI Industrial',
        category: 'FEDERAL' as const,
        debito: taxTotals.ipi,
        credito: effectiveCredits.ipi,
        desc: 'Imposto sobre Produtos Industrializados',
      },
      {
        code: 'ICMS ST',
        name: 'ICMS Substituição Tributária',
        category: 'ESTADUAL' as const,
        debito: taxTotals.icmsSt,
        credito: effectiveCredits.icmsSt,
        desc: 'Retenção por Substituição Tributária',
      },
      {
        code: 'FCP',
        name: 'FCP (Fundo Combate Pobreza)',
        category: 'ESTADUAL' as const,
        debito: taxTotals.fcp + taxTotals.fcpSt,
        credito: effectiveCredits.fcp + effectiveCredits.fcpSt,
        desc: 'Adicional estadual destinado ao fundo de combate à pobreza',
      },
      {
        code: 'IBS',
        name: 'IBS (Reforma Tributária)',
        category: 'REFORMA' as const,
        debito: taxTotals.ibs,
        credito: effectiveCredits.ibs,
        desc: 'Imposto sobre Bens e Serviços (Est./Mun.)',
      },
      {
        code: 'CBS',
        name: 'CBS (Reforma Tributária)',
        category: 'REFORMA' as const,
        debito: taxTotals.cbs,
        credito: effectiveCredits.cbs,
        desc: 'Contribuição sobre Bens e Serviços (Federal)',
      },
    ];

    return lines.map((line) => {
      const saldo = line.debito - line.credito;
      let status: 'DEVEDOR' | 'CREDOR' | 'ZERADO' = 'ZERADO';
      if (saldo > 0.01) status = 'DEVEDOR';
      else if (saldo < -0.01) status = 'CREDOR';

      return {
        ...line,
        saldo,
        status,
      };
    });
  }, [taxTotals, effectiveCredits]);

  // Overall totals
  const totalDebitos = useMemo(
    () => taxLines.reduce((acc, l) => acc + l.debito, 0),
    [taxLines]
  );
  const totalCreditos = useMemo(
    () => taxLines.reduce((acc, l) => acc + l.credito, 0),
    [taxLines]
  );
  const totalARecolher = useMemo(
    () => taxLines.filter((l) => l.saldo > 0).reduce((acc, l) => acc + l.saldo, 0),
    [taxLines]
  );
  const totalSaldoCredor = useMemo(
    () => taxLines.filter((l) => l.saldo < 0).reduce((acc, l) => acc + Math.abs(l.saldo), 0),
    [taxLines]
  );
  const saldoLiquidoGeral = totalDebitos - totalCreditos;

  // Export Apuração as CSV
  const handleExportApuracaoCSV = () => {
    const headers = [
      'Tributo',
      'Denominação',
      'Âmbito',
      '(+) Débito Saídas',
      '(-) Crédito Entradas',
      '(=) Saldo Apurado (Débito - Crédito)',
      'Situação da Guia',
      'Valor a Recolher',
      'Saldo Credor a Compensar',
    ];

    const rows = taxLines.map((line) => [
      line.code,
      line.name,
      line.category,
      line.debito.toFixed(2).replace('.', ','),
      line.credito.toFixed(2).replace('.', ','),
      line.saldo.toFixed(2).replace('.', ','),
      line.status === 'DEVEDOR' ? 'A RECOLHER (DEVEDOR)' : line.status === 'CREDOR' ? 'SALDO CREDOR ACUMULADO' : 'ZERADO',
      line.saldo > 0 ? line.saldo.toFixed(2).replace('.', ',') : '0,00',
      line.saldo < 0 ? Math.abs(line.saldo).toFixed(2).replace('.', ',') : '0,00',
    ]);

    // Summary row
    rows.push([
      'TOTAL GERAL',
      'Apuração Consolidada',
      'TODOS',
      totalDebitos.toFixed(2).replace('.', ','),
      totalCreditos.toFixed(2).replace('.', ','),
      saldoLiquidoGeral.toFixed(2).replace('.', ','),
      saldoLiquidoGeral > 0 ? 'SALDO DEVEDOR LÍQUIDO' : 'SALDO CREDOR LÍQUIDO',
      totalARecolher.toFixed(2).replace('.', ','),
      totalSaldoCredor.toFixed(2).replace('.', ','),
    ]);

    const csvContent =
      '\uFEFF' +
      [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Apuracao_Fiscal_Debito_Credito_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-xl shadow-xs overflow-hidden mb-8">
      {/* Header */}
      <div className="px-4 sm:px-6 py-4 bg-[#1E2D23] text-[#FAF7F2] flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4] shrink-0">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold uppercase tracking-wider font-['Montserrat',sans-serif] text-[#FAF7F2]">
                Apuração Fiscal: Débito − Crédito
              </h2>
              <span className="text-[10px] bg-[#D5BEA4] text-[#1E2D23] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                Não-Cumulatividade
              </span>
            </div>
            <p className="text-xs text-[#C2B7A3]">
              Compensação dos impostos de saída (débitos) com os créditos fiscais das notas de entrada
            </p>
          </div>
        </div>

        {/* Source & Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          {hasEntradaData ? (
            <div className="flex items-center gap-1.5 bg-[#2A3F31] border border-[#3D5B47] px-2.5 py-1 rounded text-xs text-[#FAF7F2]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[#C2B7A3]">Créditos vinculados:</span>
              <strong className="text-[#D5BEA4] font-medium">{entradaSourceLabel || 'Entradas importadas'}</strong>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 bg-[#312519] border border-[#5C4328] px-2.5 py-1 rounded text-xs text-[#F2DFCB]">
              <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              <span>Sem entradas importadas</span>
            </div>
          )}

          <button
            type="button"
            onClick={handleExportApuracaoCSV}
            className="inline-flex items-center gap-1.5 bg-[#2A3F31] hover:bg-[#344E3D] text-[#FAF7F2] border border-[#3D5B47] px-3 py-1 rounded text-xs font-semibold transition-colors"
            title="Exportar memória de cálculo da apuração em CSV"
          >
            <Download className="w-3.5 h-3.5 text-[#D5BEA4]" />
            <span>Exportar Apuração</span>
          </button>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex border-b border-[#E2D9CE] bg-[#FAF8F5] px-4 sm:px-6">
        <button
          type="button"
          onClick={() => setActiveTab('APURACAO')}
          className={`py-3 px-4 text-xs font-bold uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'APURACAO'
              ? 'border-[#1E2D23] text-[#1E2D23] bg-white'
              : 'border-transparent text-neutral-500 hover:text-[#1E2D23]'
          }`}
        >
          <ArrowRightLeft className="w-3.5 h-3.5" />
          <span>Apuração (Débito − Crédito)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('DEBITOS')}
          className={`py-3 px-4 text-xs font-bold uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'DEBITOS'
              ? 'border-[#1E2D23] text-[#1E2D23] bg-white'
              : 'border-transparent text-neutral-500 hover:text-[#1E2D23]'
          }`}
        >
          <ArrowUpRight className="w-3.5 h-3.5 text-rose-700" />
          <span>(+) Débitos das Saídas ({formatBRL(totalDebitos)})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('CREDITOS')}
          className={`py-3 px-4 text-xs font-bold uppercase tracking-wider flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'CREDITOS'
              ? 'border-[#1E2D23] text-[#1E2D23] bg-white'
              : 'border-transparent text-neutral-500 hover:text-[#1E2D23]'
          }`}
        >
          <ArrowDownRight className="w-3.5 h-3.5 text-emerald-700" />
          <span>(−) Créditos das Entradas ({formatBRL(totalCreditos)})</span>
        </button>
      </div>

      <div className="p-4 sm:p-6 space-y-6">
        {/* TAB 1: APURAÇÃO DÉBITO - CRÉDITO */}
        {activeTab === 'APURACAO' && (
          <>
            {/* Top KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Card 1: Débitos Totais */}
              <div className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-neutral-500 mb-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider">
                      (+) Débitos (Saídas)
                    </span>
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                  </div>
                  <div className="text-2xl font-black text-[#1E2D23] font-mono">
                    {formatBRL(totalDebitos)}
                  </div>
                  <p className="text-[11px] text-neutral-500 mt-1">
                    Impostos gerados sobre faturamento de vendas
                  </p>
                </div>
              </div>

              {/* Card 2: Créditos Totais */}
              <div className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-neutral-500 mb-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider">
                      (−) Créditos (Entradas)
                    </span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                  </div>
                  <div className="text-2xl font-black text-emerald-900 font-mono">
                    {formatBRL(totalCreditos)}
                  </div>
                  <p className="text-[11px] text-neutral-500 mt-1">
                    Créditos fiscais obtidos nas compras e aquisições
                  </p>
                </div>
              </div>

              {/* Card 3: Saldo Líquido Apurado */}
              <div
                className={`rounded-xl p-4 border flex flex-col justify-between ${
                  saldoLiquidoGeral > 0
                    ? 'bg-[#FDF7F5] border-[#EAD2CC]'
                    : saldoLiquidoGeral < 0
                    ? 'bg-[#F2F8F3] border-[#C8E0CD]'
                    : 'bg-[#FAF8F5] border-[#E2D9CE]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#1E2D23]">
                      (=) Saldo Geral da Apuração
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        saldoLiquidoGeral > 0
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : saldoLiquidoGeral < 0
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-neutral-100 text-neutral-700'
                      }`}
                    >
                      {saldoLiquidoGeral > 0 ? 'A Recolher' : saldoLiquidoGeral < 0 ? 'Saldo Credor' : 'Equilibrado'}
                    </span>
                  </div>

                  <div
                    className={`text-2xl font-black font-mono ${
                      saldoLiquidoGeral > 0 ? 'text-[#8F3E35]' : saldoLiquidoGeral < 0 ? 'text-emerald-900' : 'text-[#1E2D23]'
                    }`}
                  >
                    {formatBRL(Math.abs(saldoLiquidoGeral))}
                  </div>

                  <p className="text-[11px] text-neutral-600 mt-1">
                    {saldoLiquidoGeral > 0
                      ? 'Saldo devedor consolidado a pagar via guias (DARE/DARF).'
                      : saldoLiquidoGeral < 0
                      ? 'Crédito fiscal acumulado a transportar para o mês seguinte.'
                      : 'Débitos e créditos perfeitamente equalizados.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Informational Banner if no entrada data */}
            {!hasEntradaData && (
              <div className="p-4 bg-[#FAF5EE] border border-[#E8DEC8] rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded bg-[#F0E4D0] border border-[#E0D0B5] flex items-center justify-center text-[#8C6D4C] shrink-0 mt-0.5">
                    <Receipt className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wide">
                      Deseja abater os créditos reais das notas de entrada?
                    </h4>
                    <p className="text-xs text-neutral-600 mt-0.5">
                      Para apurar com 100% de exatidão o saldo devedor ou credor, importe o arquivo de entradas (Qive ou TOTVS) na conciliação, ou carregue dados de demonstração.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {onLoadDemoData && (
                    <button
                      type="button"
                      onClick={onLoadDemoData}
                      className="px-3 py-1.5 bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] rounded text-xs font-bold transition-colors inline-flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#D5BEA4]" />
                      <span>Carregar Dados Demonstrativos</span>
                    </button>
                  )}

                  {onNavigateToEntrada && (
                    <button
                      type="button"
                      onClick={onNavigateToEntrada}
                      className="px-3 py-1.5 bg-white hover:bg-[#F5EFE6] text-[#1E2D23] border border-[#D5BEA4] rounded text-xs font-bold transition-colors"
                    >
                      Ir para Conciliação
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Apuração Table (Débito - Crédito) */}
            <div className="border border-[#E2D9CE] rounded-xl overflow-hidden shadow-xs">
              <div className="bg-[#FAF8F5] px-4 py-3 border-b border-[#E2D9CE] flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider font-['Montserrat',sans-serif]">
                    Memória de Cálculo da Apuração por Tributo
                  </h3>
                  <p className="text-[11px] text-neutral-500">
                    Débitos apurados na saída subtraídos dos créditos apurados na entrada
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setShowSimulador(!showSimulador)}
                  className="text-xs font-bold text-[#8C6D4C] hover:text-[#1E2D23] inline-flex items-center gap-1 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{showSimulador ? 'Ocultar Simulador de Créditos' : 'Simular / Ajustar Créditos'}</span>
                </button>
              </div>

              {/* Simulation drawer */}
              {showSimulador && (
                <div className="p-4 bg-[#F7F4EE] border-b border-[#E2D9CE] text-xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-[#1E2D23] uppercase tracking-wide">
                      Simulação / Créditos Adicionais de Entrada:
                    </span>
                    <button
                      type="button"
                      onClick={() => setManualCreditAdjustments({})}
                      className="text-[11px] text-rose-700 hover:underline font-semibold"
                    >
                      Zerar simulações
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {['ICMS', 'PIS', 'COFINS', 'IPI'].map((tax) => (
                      <div key={tax} className="bg-white border border-[#E2D9CE] rounded p-2">
                        <label className="block text-[10px] font-bold text-neutral-600 uppercase mb-1">
                          Crédito Adicional {tax} (R$)
                        </label>
                        <input
                          type="number"
                          step="any"
                          value={manualCreditAdjustments[tax] || ''}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            setManualCreditAdjustments({
                              ...manualCreditAdjustments,
                              [tax]: val,
                            });
                          }}
                          placeholder="0,00"
                          className="w-full text-xs font-mono border border-neutral-300 rounded px-2 py-1"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF8F5] border-b border-[#E2D9CE] text-[#1E2D23] font-semibold uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="py-3 px-4">Tributo</th>
                      <th className="py-3 px-4">Âmbito</th>
                      <th className="py-3 px-4 text-right">(+) Débito (Saídas)</th>
                      <th className="py-3 px-4 text-right">(−) Crédito (Entradas)</th>
                      <th className="py-3 px-4 text-right">(=) Saldo Apurado</th>
                      <th className="py-3 px-4 text-center">Status da Guia</th>
                      <th className="py-3 px-4 text-center">Proporção</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2D9CE]">
                    {taxLines.map((line) => {
                      const maxVal = Math.max(line.debito, line.credito, 1);
                      const debPct = (line.debito / maxVal) * 100;
                      const credPct = (line.credito / maxVal) * 100;

                      return (
                        <tr key={line.code} className="hover:bg-[#FAF8F5] transition-colors">
                          {/* Tributo */}
                          <td className="py-3 px-4 font-semibold text-[#1E2D23] whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full bg-[#1E2D23]" />
                              <div>
                                <div className="font-bold text-[#1E2D23]">{line.code}</div>
                                <div className="text-[10px] text-neutral-500 font-normal">{line.name}</div>
                              </div>
                            </div>
                          </td>

                          {/* Âmbito */}
                          <td className="py-3 px-4 whitespace-nowrap">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                                line.category === 'ESTADUAL'
                                  ? 'bg-[#EFF5F0] text-[#233527] border border-[#D0E2D4]'
                                  : line.category === 'FEDERAL'
                                  ? 'bg-[#FAF3EA] text-[#8C6D4C] border border-[#E8DCCB]'
                                  : 'bg-[#F2EFF7] text-[#59427B] border border-[#DDD6EB]'
                              }`}
                            >
                              {line.category}
                            </span>
                          </td>

                          {/* Débito (Saídas) */}
                          <td className="py-3 px-4 text-right font-mono font-bold text-[#1E2D23] whitespace-nowrap">
                            {formatBRL(line.debito)}
                          </td>

                          {/* Crédito (Entradas) */}
                          <td className="py-3 px-4 text-right font-mono font-bold text-emerald-900 whitespace-nowrap">
                            {formatBRL(line.credito)}
                          </td>

                          {/* Saldo Apurado */}
                          <td className="py-3 px-4 text-right font-mono font-bold whitespace-nowrap">
                            <span
                              className={`${
                                line.saldo > 0
                                  ? 'text-[#8F3E35]'
                                  : line.saldo < 0
                                  ? 'text-emerald-800'
                                  : 'text-neutral-500'
                              }`}
                            >
                              {line.saldo > 0 ? '+' : ''}
                              {formatBRL(line.saldo)}
                            </span>
                          </td>

                          {/* Status da Guia */}
                          <td className="py-3 px-4 text-center whitespace-nowrap">
                            {line.status === 'DEVEDOR' ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-800 border border-rose-200">
                                <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                                A Recolher
                              </span>
                            ) : line.status === 'CREDOR' ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                                Saldo Credor
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-neutral-100 text-neutral-600">
                                Zerado
                              </span>
                            )}
                          </td>

                          {/* Visual Proportion Bar */}
                          <td className="py-3 px-4 text-center min-w-[120px]">
                            <div className="w-full bg-[#EAE4DC] rounded-full h-2 overflow-hidden flex shadow-inner">
                              <div
                                title={`Débito: ${debPct.toFixed(0)}%`}
                                style={{ width: `${debPct}%` }}
                                className="bg-[#8F3E35] h-full transition-all"
                              />
                              <div
                                title={`Crédito: ${credPct}%`}
                                style={{ width: `${credPct}%` }}
                                className="bg-emerald-700 h-full transition-all"
                              />
                            </div>
                            <div className="flex justify-between text-[9px] text-neutral-400 mt-0.5 font-mono">
                              <span>Déb</span>
                              <span>Créd</span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>

                  {/* Summary Footer */}
                  <tfoot className="bg-[#FAF8F5] border-t-2 border-[#1E2D23] font-bold">
                    <tr>
                      <td colSpan={2} className="py-3 px-4 text-[#1E2D23] uppercase tracking-wider text-xs">
                        Total Consolidado da Apuração
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-[#1E2D23]">
                        {formatBRL(totalDebitos)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-emerald-900">
                        {formatBRL(totalCreditos)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-sm">
                        <span
                          className={`${
                            saldoLiquidoGeral > 0
                              ? 'text-[#8F3E35]'
                              : saldoLiquidoGeral < 0
                              ? 'text-emerald-900'
                              : 'text-neutral-700'
                          }`}
                        >
                          {saldoLiquidoGeral > 0 ? '+' : ''}
                          {formatBRL(saldoLiquidoGeral)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="text-xs font-bold text-[#1E2D23]">
                          {saldoLiquidoGeral > 0 ? 'PAGAMENTO' : 'COMPENSAÇÃO'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center text-[10px] text-neutral-500 font-mono">
                        Débito − Crédito
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </>
        )}

        {/* TAB 2: DETALHAMENTO DE DÉBITOS (SAÍDAS) */}
        {activeTab === 'DEBITOS' && (
          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="w-2.5 h-2.5 rounded-full bg-[#233527]" />
                <h3 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
                  ICMS e Adicionais Estaduais (Saídas)
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: 'Valor do ICMS', value: taxTotals.icms, code: 'ICMS', desc: 'Imposto Estadual próprio' },
                  { label: 'Base de Cálculo ICMS', value: taxTotals.baseIcms, code: 'Base ICMS', desc: 'Base tributada destacada' },
                  { label: 'ICMS Isento', value: taxTotals.isentoIcms, code: 'Isento ICMS', desc: 'Operações isentas' },
                  { label: 'Outros Valores ICMS', value: taxTotals.outroIcms, code: 'Outros ICMS', desc: 'Outras desonerações' },
                  { label: 'ICMS ST', value: taxTotals.icmsSt, code: 'ICMS ST', desc: 'Retenção por substituição' },
                  { label: 'Fundo Combate Pobreza', value: taxTotals.fcp, code: 'FCP', desc: 'Adicional estadual' },
                  { label: 'FCP Retido ST', value: taxTotals.fcpSt, code: 'FCP ST', desc: 'FCP substituição' },
                ].map((tax) => (
                  <div key={tax.code} className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg p-3">
                    <span className="text-[11px] font-bold text-[#8C6D4C] uppercase tracking-wider block mb-1">
                      {tax.code}
                    </span>
                    <div className="text-lg font-bold text-[#1E2D23] font-mono tracking-tight">
                      {formatBRL(tax.value)}
                    </div>
                    <p className="text-[10px] text-neutral-500 mt-1">{tax.label}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="w-2.5 h-2.5 rounded-full bg-[#8C6D4C]" />
                <h3 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
                  Tributos Federais (Saídas)
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { label: 'Valor IPI', value: taxTotals.ipi, code: 'IPI' },
                  { label: 'Valor PIS', value: taxTotals.pis, code: 'PIS' },
                  { label: 'Valor COFINS', value: taxTotals.cofins, code: 'COFINS' },
                ].map((tax) => (
                  <div key={tax.code} className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg p-3">
                    <span className="text-[11px] font-bold text-[#8C6D4C] uppercase tracking-wider block mb-1">
                      {tax.code}
                    </span>
                    <div className="text-lg font-bold text-[#1E2D23] font-mono tracking-tight">
                      {formatBRL(tax.value)}
                    </div>
                    <p className="text-[10px] text-neutral-500 mt-1">{tax.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: DETALHAMENTO DE CRÉDITOS (ENTRADAS) */}
        {activeTab === 'CREDITOS' && (
          <div className="space-y-6">
            <div className="p-4 bg-[#F2F8F3] border border-[#C8E0CD] rounded-xl flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wide">
                  Créditos Tributários Originados em Entradas
                </h4>
                <p className="text-xs text-emerald-800 mt-0.5">
                  Valores apurados através das notas de aquisição lançadas no ERP ou capturadas na SEFAZ
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 px-2.5 py-1 rounded">
                Total Créditos: {formatBRL(totalCreditos)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Crédito ICMS', value: effectiveCredits.icms, code: 'Crédito ICMS' },
                { label: 'Crédito PIS', value: effectiveCredits.pis, code: 'Crédito PIS' },
                { label: 'Crédito COFINS', value: effectiveCredits.cofins, code: 'Crédito COFINS' },
                { label: 'Crédito IPI', value: effectiveCredits.ipi, code: 'Crédito IPI' },
                { label: 'Crédito ICMS ST', value: effectiveCredits.icmsSt, code: 'Crédito ST' },
                { label: 'Crédito IBS', value: effectiveCredits.ibs, code: 'Crédito IBS' },
                { label: 'Crédito CBS', value: effectiveCredits.cbs, code: 'Crédito CBS' },
              ].map((tax) => (
                <div key={tax.code} className="bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg p-3">
                  <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block mb-1">
                    {tax.code}
                  </span>
                  <div className="text-lg font-bold text-[#1E2D23] font-mono tracking-tight">
                    {formatBRL(tax.value)}
                  </div>
                  <p className="text-[10px] text-neutral-500 mt-1">{tax.label}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Informative Disclaimer */}
        <div className="p-3.5 bg-[#FAF8F5] border border-[#E2D9CE] rounded-lg text-xs text-neutral-700 flex items-start gap-2.5">
          <ShieldAlert className="w-4 h-4 text-[#8C6D4C] shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-[#1E2D23]">Diretriz de Apuração Fiscal:</span> O cálculo da apuração segue estritamente a fórmula legal{' '}
            <strong className="text-[#1E2D23]">Débito (Saídas) − Crédito (Entradas)</strong>. Saldos positivos indicam valor devido aos cofres públicos (SEFAZ/Receita Federal), enquanto saldos negativos representam créditos acumulados a compensar em períodos subsequentes.
          </div>
        </div>
      </div>
    </div>
  );
};
