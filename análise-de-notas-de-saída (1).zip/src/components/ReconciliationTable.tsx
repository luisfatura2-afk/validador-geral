import React, { useState } from 'react';
import {
  Copy,
  Check,
  CheckCircle2,
  AlertOctagon,
  Scale,
  FileQuestion,
  XCircle,
  Eye,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { ReconciledItem } from '../types/reconciliation';
import { formatBRL } from '../utils/reconciliationEngine';

interface ReconciliationTableProps {
  items: ReconciledItem[];
  onSelectItem: (item: ReconciledItem) => void;
}

export const ReconciliationTable: React.FC<ReconciliationTableProps> = ({
  items,
  onSelectItem,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const handleCopyKey = (e: React.MouseEvent, chave: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(chave);
    setCopiedKey(chave);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const totalPages = Math.ceil(items.length / pageSize) || 1;
  const startIndex = (currentPage - 1) * pageSize;
  const pageItems = items.slice(startIndex, startIndex + pageSize);

  const renderStatusBadge = (status: string, label: string) => {
    switch (status) {
      case 'MATCHED':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#EFF6F1] text-[#233527] border border-[#C5DAC9] whitespace-nowrap">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Conciliada
          </span>
        );
      case 'PENDING_IN_TOTVS':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#FAF0EE] text-[#8F3E35] border border-[#E8D0CE] whitespace-nowrap">
            <AlertOctagon className="w-3 h-3 text-red-600" />
            Falta no TOTVS
          </span>
        );
      case 'VALUE_DIVERGENCE':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#FAF4E8] text-[#845E28] border border-[#EADFCB] whitespace-nowrap">
            <Scale className="w-3 h-3 text-amber-600" />
            Divergência R$
          </span>
        );
      case 'ONLY_IN_TOTVS':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#EFF3F0] text-[#334D3C] border border-[#D5E0D8] whitespace-nowrap">
            <FileQuestion className="w-3 h-3 text-neutral-600" />
            Apenas no TOTVS
          </span>
        );
      case 'CANCELLED_SEFAZ':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-700 border border-neutral-300 whitespace-nowrap">
            <XCircle className="w-3 h-3 text-neutral-500" />
            Cancelada SEFAZ
          </span>
        );
      default:
        return (
          <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-600">
            {label}
          </span>
        );
    }
  };

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-6">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-[#FAF8F5] border-b border-[#E2D9CE] text-neutral-600 font-bold uppercase tracking-wider text-[11px]">
              <th className="py-3 px-3.5">Status Conciliação</th>
              <th className="py-3 px-3.5">Chave de Acesso</th>
              <th className="py-3 px-3.5">Tipo / NF / Série</th>
              <th className="py-3 px-3.5">Fornecedor / Emitente</th>
              <th className="py-3 px-3.5">Emissão</th>
              <th className="py-3 px-3.5 text-right">Valor Qive (SEFAZ)</th>
              <th className="py-3 px-3.5 text-right">Valor TOTVS (ERP)</th>
              <th className="py-3 px-3.5 text-right">Diferença</th>
              <th className="py-3 px-3.5 text-center">CFOPs</th>
              <th className="py-3 px-3.5 text-center">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#F0EAE1]">
            {pageItems.length === 0 ? (
              <tr>
                <td colSpan={10} className="py-12 text-center text-neutral-500">
                  Nenhum documento encontrado com os filtros selecionados.
                </td>
              </tr>
            ) : (
              pageItems.map((item) => {
                const hasDivergence = item.status === 'VALUE_DIVERGENCE';
                const isPending = item.status === 'PENDING_IN_TOTVS';

                return (
                  <tr
                    key={item.id}
                    onClick={() => onSelectItem(item)}
                    className={`hover:bg-[#FAF8F5] cursor-pointer transition-colors ${
                      isPending ? 'bg-red-50/20' : hasDivergence ? 'bg-amber-50/20' : ''
                    }`}
                  >
                    <td className="py-3 px-3.5">
                      {renderStatusBadge(item.status, item.statusLabel)}
                    </td>

                    <td className="py-3 px-3.5 font-mono">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] text-neutral-700 max-w-[130px] truncate" title={item.chaveAcesso}>
                          {item.chaveAcesso ? `${item.chaveAcesso.slice(0, 8)}...${item.chaveAcesso.slice(-6)}` : 'S/ Chave'}
                        </span>
                        {item.chaveAcesso && (
                          <button
                            onClick={(e) => handleCopyKey(e, item.chaveAcesso)}
                            className="p-1 hover:bg-[#EFEAE2] rounded text-neutral-400 hover:text-[#1E2D23] transition-colors"
                            title="Copiar chave de acesso completa"
                          >
                            {copiedKey === item.chaveAcesso ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-3.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-neutral-100 text-neutral-700">
                          {item.tipoDocumento}
                        </span>
                        <span className="font-semibold font-mono text-[#1E2D23]">
                          {item.numero || 'S/N'}
                        </span>
                        {item.serie && (
                          <span className="text-[10px] text-neutral-400 font-mono">
                            s.{item.serie}
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-3.5">
                      <div className="font-semibold text-[#1E2D23] max-w-[200px] truncate" title={item.nomeEmitente}>
                        {item.nomeEmitente || 'Não identificado'}
                      </div>
                      {item.cnpjEmitente && (
                        <span className="text-[10px] text-neutral-500 font-mono">
                          {item.cnpjEmitente}
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-3.5 text-neutral-600 font-mono whitespace-nowrap">
                      {item.dataEmissao || '-'}
                    </td>

                    <td className="py-3 px-3.5 text-right font-mono font-bold text-[#1E2D23]">
                      {item.valorQive > 0 ? formatBRL(item.valorQive) : '-'}
                    </td>

                    <td className="py-3 px-3.5 text-right font-mono font-bold text-[#1E2D23]">
                      {item.valorTotvs > 0 ? formatBRL(item.valorTotvs) : (
                        <span className="text-red-600 font-semibold italic text-[11px]">Não lançado</span>
                      )}
                    </td>

                    <td className="py-3 px-3.5 text-right font-mono font-semibold">
                      {item.diferencaValor > 0.05 ? (
                        <span className="text-[#8F3E35] font-bold">
                          {formatBRL(item.diferencaValor)}
                        </span>
                      ) : (
                        <span className="text-emerald-700">R$ 0,00</span>
                      )}
                    </td>

                    <td className="py-3 px-3.5 text-center font-mono text-[11px] text-neutral-600 max-w-[80px] truncate" title={item.cfops}>
                      {item.cfops || '-'}
                    </td>

                    <td className="py-3 px-3.5 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectItem(item);
                        }}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded bg-[#FAF8F5] hover:bg-[#1E2D23] text-[#1E2D23] hover:text-[#D5BEA4] border border-[#E2D9CE] text-[11px] font-semibold transition-all shadow-2xs"
                        title="Ver auditoria lado a lado"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Auditar</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-3.5 bg-[#FAF8F5] border-t border-[#E2D9CE] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-neutral-500">Exibir:</span>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="border border-[#E2D9CE] rounded px-2 py-1 bg-white text-[#1E2D23] font-medium"
          >
            <option value={25}>25 por página</option>
            <option value={50}>50 por página</option>
            <option value={100}>100 por página</option>
          </select>
          <span className="text-neutral-500">
            Total de {items.length} registro(s)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-neutral-600">
            Página <strong>{currentPage}</strong> de <strong>{totalPages}</strong>
          </span>
          <div className="inline-flex items-center gap-1">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1 rounded border border-[#E2D9CE] bg-white hover:bg-[#FAF8F5] disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1 rounded border border-[#E2D9CE] bg-white hover:bg-[#FAF8F5] disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
