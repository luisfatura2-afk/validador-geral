import React from 'react';
import { AlertSeverity } from '../../types/auditRules';
import { CheckCircle2, AlertTriangle, AlertOctagon, Info } from 'lucide-react';

interface AlertBadgeProps {
  severity: AlertSeverity;
  label?: string;
  showIcon?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const AlertBadge: React.FC<AlertBadgeProps> = ({
  severity,
  label,
  showIcon = true,
  size = 'md',
  className = '',
}) => {
  const config = {
    OK: {
      text: label || 'OK',
      bg: 'bg-emerald-50 text-emerald-800 border-emerald-300',
      icon: CheckCircle2,
      dot: 'bg-emerald-500',
      symbol: '🟢',
    },
    ATENCAO: {
      text: label || 'ATENÇÃO',
      bg: 'bg-amber-50 text-amber-900 border-amber-300',
      icon: AlertTriangle,
      dot: 'bg-amber-500',
      symbol: '🟡',
    },
    CRITICO: {
      text: label || 'CRÍTICO',
      bg: 'bg-rose-50 text-rose-900 border-rose-300',
      icon: AlertOctagon,
      dot: 'bg-rose-500',
      symbol: '🔴',
    },
    INFORMATIVO: {
      text: label || 'INFORMATIVO',
      bg: 'bg-sky-50 text-sky-900 border-sky-300',
      icon: Info,
      dot: 'bg-sky-500',
      symbol: '🔵',
    },
  }[severity];

  const IconComponent = config.icon;

  const sizeClasses = {
    sm: 'text-[10px] px-1.5 py-0.5 gap-1',
    md: 'text-xs px-2 py-0.5 gap-1.5',
    lg: 'text-sm px-3 py-1 gap-2',
  }[size];

  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4 h-4',
  }[size];

  return (
    <span
      className={`inline-flex items-center font-bold uppercase tracking-wider rounded-md border ${config.bg} ${sizeClasses} ${className}`}
    >
      {showIcon && <IconComponent className={`${iconSizes} shrink-0`} />}
      <span>{config.text}</span>
    </span>
  );
};
