import React from 'react';
import { LucideIcon, Inbox } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  actionButton?: React.ReactNode;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  icon: Icon = Inbox,
  actionButton,
  className = '',
}) => {
  return (
    <div
      className={`flex flex-col items-center justify-center p-8 sm:p-12 text-center bg-white border border-[#E2D9CE] rounded-xl shadow-xs ${className}`}
    >
      <div className="w-14 h-14 rounded-full bg-[#FAF7F2] border border-[#E2D9CE] flex items-center justify-center text-[#8C6D4C] mb-4">
        <Icon className="w-7 h-7" />
      </div>
      <h3 className="text-base font-bold text-[#1E2D23] font-['Montserrat',sans-serif] mb-1.5">
        {title}
      </h3>
      <p className="text-xs sm:text-sm text-neutral-500 max-w-md mb-5 leading-relaxed">
        {description}
      </p>
      {actionButton && <div>{actionButton}</div>}
    </div>
  );
};
