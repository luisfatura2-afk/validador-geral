import React, { useMemo } from 'react';
import { Filter, RotateCcw, Search, Calendar, Building, Tag, FileText, User } from 'lucide-react';
import { FilterState, InvoiceRecord } from '../types/fiscal';

interface FilterBarProps {
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  onResetFilters: () => void;
  allRecords: InvoiceRecord[];
  activeFilterCount: number;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onFilterChange,
  onResetFilters,
  allRecords,
  activeFilterCount,
}) => {
  const empresaOptions = useMemo(() => {
    return Array.from(new Set(allRecords.map((r) => r.empresa).filter(Boolean))).sort();
  }, [allRecords]);

  const situacaoOptions = useMemo(() => {
    return Array.from(new Set(allRecords.map((r) => r.situacao).filter(Boolean))).sort();
  }, [allRecords]);

  const cfopOptions = useMemo(() => {
    return Array.from(new Set(allRecords.map((r) => r.cfop).filter(Boolean))).sort();
  }, [allRecords]);

  const especieOptions = useMemo(() => {
    return Array.from(new Set(allRecords.map((r) => r.especie).filter(Boolean))).sort();
  }, [allRecords]);

  const serieOptions = useMemo(() => {
    return Array.from(new Set(allRecords.map((r) => r.serie).filter(Boolean))).sort();
  }, [allRecords]);

  const updateField = <K extends keyof FilterState>(key: K, value: FilterState[K]) => {
    onFilterChange({
      ...filters,
      [key]: value,
    });
  };

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-6">
      <div className="px-4 sm:px-6 py-3 bg-[#FAF8F5] border-b border-[#E2D9CE] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#8C6D4C]" />
          <h3 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
            Filtros Avançados
          </h3>
          {activeFilterCount > 0 && (
            <span className="bg-[#1E2D23] text-[#D5BEA4] text-[10px] font-bold px-2 py-0.5 rounded-full font-mono">
              {activeFilterCount} {activeFilterCount === 1 ? 'ativo' : 'ativos'}
            </span>
          )}
        </div>

        {activeFilterCount > 0 && (
          <button
            id="btn-clear-all-filters"
            onClick={onResetFilters}
            className="inline-flex items-center gap-1 text-xs text-neutral-600 hover:text-[#1E2D23] font-semibold transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Limpar filtros</span>
          </button>
        )}
      </div>

      <div className="p-4 sm:p-5 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3.5 text-xs">
        {/* 1. Data Início */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1 flex items-center gap-1">
            <Calendar className="w-3 h-3 text-[#8C6D4C]" />
            <span>Dt. Emissão Início</span>
          </label>
          <input
            type="date"
            value={filters.dataInicio}
            onChange={(e) => updateField('dataInicio', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs"
          />
        </div>

        {/* 2. Data Fim */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1 flex items-center gap-1">
            <Calendar className="w-3 h-3 text-[#8C6D4C]" />
            <span>Dt. Emissão Fim</span>
          </label>
          <input
            type="date"
            value={filters.dataFim}
            onChange={(e) => updateField('dataFim', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs"
          />
        </div>

        {/* 3. Empresa */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1 flex items-center gap-1">
            <Building className="w-3 h-3 text-[#8C6D4C]" />
            <span>Empresa / Filial</span>
          </label>
          <select
            value={filters.empresa}
            onChange={(e) => updateField('empresa', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs truncate"
          >
            <option value="">Todas as empresas ({empresaOptions.length})</option>
            {empresaOptions.map((emp) => (
              <option key={emp} value={emp}>
                {emp}
              </option>
            ))}
          </select>
        </div>

        {/* 4. Situação */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1 flex items-center gap-1">
            <Tag className="w-3 h-3 text-[#8C6D4C]" />
            <span>Situação SEFAZ</span>
          </label>
          <select
            value={filters.situacao}
            onChange={(e) => updateField('situacao', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs truncate"
          >
            <option value="">Todas as situações</option>
            {situacaoOptions.map((sit) => (
              <option key={sit} value={sit}>
                {sit}
              </option>
            ))}
          </select>
        </div>

        {/* 5. CFOP */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1 flex items-center gap-1">
            <Tag className="w-3 h-3 text-[#8C6D4C]" />
            <span>CFOP</span>
          </label>
          <select
            value={filters.cfop}
            onChange={(e) => updateField('cfop', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs"
          >
            <option value="">Todos os CFOPs ({cfopOptions.length})</option>
            {cfopOptions.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        {/* 6. Número da NF */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1 flex items-center gap-1">
            <FileText className="w-3 h-3 text-[#8C6D4C]" />
            <span>Número da Nota</span>
          </label>
          <input
            type="text"
            placeholder="Ex: 10234..."
            value={filters.numeroNf}
            onChange={(e) => updateField('numeroNf', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs font-mono"
          />
        </div>

        {/* 7. Nome / Razão Social do Destinatário */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1 flex items-center gap-1">
            <User className="w-3 h-3 text-[#8C6D4C]" />
            <span>Destinatário / Cliente</span>
          </label>
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar por nome..."
              value={filters.nomePessoa}
              onChange={(e) => updateField('nomePessoa', e.target.value)}
              className="w-full pl-7 pr-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs"
            />
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2 top-2 pointer-events-none" />
          </div>
        </div>

        {/* 8. Código da Pessoa */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1 flex items-center gap-1">
            <User className="w-3 h-3 text-[#8C6D4C]" />
            <span>Cód. Pessoa / CPF / CNPJ</span>
          </label>
          <input
            type="text"
            placeholder="Código ou doc..."
            value={filters.cdPessoa}
            onChange={(e) => updateField('cdPessoa', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs font-mono"
          />
        </div>

        {/* 9. Série */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1">Série</label>
          <select
            value={filters.serie}
            onChange={(e) => updateField('serie', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs"
          >
            <option value="">Todas ({serieOptions.length})</option>
            {serieOptions.map((s) => (
              <option key={s} value={s}>
                Série {s}
              </option>
            ))}
          </select>
        </div>

        {/* 10. Espécie */}
        <div>
          <label className="block text-[11px] font-semibold text-neutral-600 mb-1">Espécie</label>
          <select
            value={filters.especie}
            onChange={(e) => updateField('especie', e.target.value)}
            className="w-full px-2.5 py-1.5 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] focus:outline-hidden focus:border-[#1E2D23] focus:ring-1 focus:ring-[#1E2D23] transition-colors text-xs"
          >
            <option value="">Todas ({especieOptions.length})</option>
            {especieOptions.map((esp) => (
              <option key={esp} value={esp}>
                {esp}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
