import React from 'react';
import { AlertTriangle, AlertOctagon, Scale, XCircle, Truck, FileText } from 'lucide-react';
import { ReconciledItem, ReconciliationKPIs } from '../types/reconciliation';
import { formatBRL } from '../utils/reconciliationEngine';

interface ReconciliationAttentionPointsProps {
  items: ReconciledItem[];
  kpis: ReconciliationKPIs;
  onFilterClick: (filterType: string, filterVal: string) => void;
}

export const ReconciliationAttentionPoints: React.FC<ReconciliationAttentionPointsProps> = ({
  items,
  kpis,
  onFilterClick,
}) => {
  const cteCount = items.filter((i) => i.tipoDocumento === 'CTe').length;
  const nfeCount = items.filter((i) => i.tipoDocumento === 'NFe').length;

  const points = [
    {
      id: 'pending_totvs',
      title: 'Notas Pendentes de Entrada no TOTVS',
      severity: 'critical' as const,
      term: 'Prioridade Fiscal',
      count: kpis.pendingTotvsCount,
      amount: kpis.pendingTotvsValue,
      description: `${kpis.pendingTotvsCount} nota(s) foram autorizadas na SEFAZ e recebidas no Qive, porém NÃO foram localizadas no relatório de entradas do TOTVS. Risco de apropriação indevida ou perda de prazos fiscais.`,
      icon: AlertOctagon,
      actionFilter: { type: 'status', val: 'PENDING_IN_TOTVS' },
    },
    {
      id: 'value_divergence',
      title: 'Divergência de Valores (Qive vs TOTVS)',
      severity: 'warning' as const,
      term: 'Diferença de Valor',
      count: kpis.divergenceCount,
      amount: kpis.divergenceValueSum,
      description: `${kpis.divergenceCount} nota(s) possuem valor total no Qive diferente do valor contábil escriturado no ERP TOTVS (diferença acumulada de ${formatBRL(kpis.divergenceValueSum)}).`,
      icon: Scale,
      actionFilter: { type: 'status', val: 'VALUE_DIVERGENCE' },
    },
    {
      id: 'cancelled_sefaz',
      title: 'Notas com Cancelamento na SEFAZ',
      severity: 'warning' as const,
      term: 'Status SEFAZ',
      count: kpis.cancelledCount,
      amount: kpis.cancelledValue,
      description: `${kpis.cancelledCount} nota(s) constam como Canceladas na SEFAZ. Verifique se alguma delas foi escriturada no ERP por engano.`,
      icon: XCircle,
      actionFilter: { type: 'status', val: 'CANCELLED_SEFAZ' },
    },
    {
      id: 'cte_breakdown',
      title: 'Conhecimentos de Transporte (CT-e) Recebidos',
      severity: 'info' as const,
      term: 'Fretes & Cargas',
      count: cteCount,
      amount: items.filter((i) => i.tipoDocumento === 'CTe').reduce((a, b) => a + (b.valorQive || b.valorTotvs), 0),
      description: `${cteCount} documentos de frete (CT-e modelo 57) identificados no cruzamento. Recomendado conciliar com as transportadoras parceiras (ex: Rodonaves, Transpress).`,
      icon: Truck,
      actionFilter: { type: 'tipoDocumento', val: 'CTe' },
    },
  ];

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg p-5 shadow-xs mb-6">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#E2D9CE]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-xs text-[#1E2D23] uppercase tracking-wider font-['Montserrat',sans-serif]">
              Diagnóstico e Pontos de Atenção na Entrada
            </h3>
            <p className="text-[11px] text-neutral-500">
              Inconsistências e pendências identificadas automaticamente pelo cruzamento de chaves
            </p>
          </div>
        </div>
        <span className="text-xs font-semibold text-neutral-500">
          Total de {items.length} chaves analisadas
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {points.map((pt) => {
          const IconComponent = pt.icon;
          const isZero = pt.count === 0;

          return (
            <div
              key={pt.id}
              onClick={() => {
                if (!isZero) {
                  onFilterClick(pt.actionFilter.type, pt.actionFilter.val);
                }
              }}
              className={`p-4 rounded-lg border transition-all ${
                isZero
                  ? 'border-neutral-200 bg-neutral-50/50 opacity-70'
                  : pt.severity === 'critical'
                  ? 'border-[#E8D0CE] bg-[#FAF0EE] hover:border-[#8F3E35] cursor-pointer'
                  : pt.severity === 'warning'
                  ? 'border-[#EADFCB] bg-[#FAF4E8] hover:border-[#A07335] cursor-pointer'
                  : 'border-[#E2D9CE] bg-[#FAF8F5] hover:border-[#1E2D23] cursor-pointer'
              }`}
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded flex items-center justify-center shrink-0 ${
                      pt.severity === 'critical'
                        ? 'bg-[#8F3E35] text-white'
                        : pt.severity === 'warning'
                        ? 'bg-[#A07335] text-white'
                        : 'bg-[#1E2D23] text-[#D5BEA4]'
                    }`}
                  >
                    <IconComponent className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#1E2D23] font-['Montserrat',sans-serif]">
                      {pt.title}
                    </h4>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.2 rounded inline-block ${
                        pt.severity === 'critical'
                          ? 'bg-red-100 text-[#8F3E35]'
                          : pt.severity === 'warning'
                          ? 'bg-amber-100 text-[#845E28]'
                          : 'bg-emerald-100 text-[#233527]'
                      }`}
                    >
                      {pt.term}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-base font-bold font-mono text-[#1E2D23]">
                    {pt.count.toLocaleString('pt-BR')}
                  </span>
                  {pt.amount > 0 && (
                    <div className="text-[11px] font-mono font-semibold text-neutral-600">
                      {formatBRL(pt.amount)}
                    </div>
                  )}
                </div>
              </div>

              <p className="text-[11px] text-neutral-600 leading-relaxed">
                {pt.description}
              </p>

              {!isZero && (
                <div className="mt-2.5 pt-2 border-t border-black/5 flex items-center justify-between text-[11px] text-[#8C6D4C] font-semibold">
                  <span>Clique para filtrar na tabela</span>
                  <span>→</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
