import React, { useRef, useState } from 'react';
import { UploadCloud, CheckCircle2, ShieldCheck, ArrowRightLeft, FileSpreadsheet, AlertTriangle, RefreshCw } from 'lucide-react';
import { QiveParseResult } from '../utils/qiveParser';
import { ParseResult } from '../utils/csvParser';
import { formatBRL } from '../utils/reconciliationEngine';

interface ReconciliationUploaderProps {
  qiveResult: QiveParseResult | null;
  qiveFileName: string;
  onQiveLoaded: (content: string, fileName: string) => void;
  onClearQive: () => void;

  totvsResult: ParseResult | null;
  totvsFileName: string;
  onTotvsLoaded: (content: string, fileName: string) => void;
  onClearTotvs: () => void;
}

export const ReconciliationUploader: React.FC<ReconciliationUploaderProps> = ({
  qiveResult,
  qiveFileName,
  onQiveLoaded,
  onClearQive,
  totvsResult,
  totvsFileName,
  onTotvsLoaded,
  onClearTotvs,
}) => {
  const [isDraggingQive, setIsDraggingQive] = useState(false);
  const [isDraggingTotvs, setIsDraggingTotvs] = useState(false);
  const qiveInputRef = useRef<HTMLInputElement>(null);
  const totvsInputRef = useRef<HTMLInputElement>(null);

  const readFile = (file: File, onLoad: (content: string, name: string) => void) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = (e.target?.result as string) || '';
      if (text.trim()) {
        onLoad(text, file.name);
      }
    };
    reader.readAsText(file, 'UTF-8');
  };

  const bothLoaded = Boolean(qiveResult && totvsResult);

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-7 shadow-xs mb-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-6 pb-4 border-b border-[#E2D9CE]">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-['Montserrat',sans-serif] font-bold text-xs bg-[#1E2D23] text-[#D5BEA4] px-2 py-0.5 rounded tracking-wider">
              CONCILIAÇÃO FISCAL
            </span>
            <span className="text-xs text-neutral-500">•</span>
            <span className="text-xs text-neutral-600 font-medium">Cruzamento Automatizado pela Chave de Acesso (44 dígitos)</span>
          </div>
          <h2 className="font-['Cormorant_Garamond',serif] text-2xl sm:text-3xl font-bold text-[#1E2D23] mt-1">
            Importação dos Relatórios Qive e TOTVS
          </h2>
        </div>

        <div className="flex items-center gap-2 text-xs text-[#8C6D4C] bg-[#FAF8F5] border border-[#E2D9CE] px-3 py-1.5 rounded-lg">
          <ShieldCheck className="w-4 h-4 text-[#233527] shrink-0" />
          <span>Auditoria 100% no navegador (sem envio para servidores)</span>
        </div>
      </div>

      {/* Dual Upload Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* SLOT 1: QIVE */}
        <div
          className={`border-2 rounded-xl p-5 transition-all ${
            qiveResult
              ? 'border-[#233527] bg-[#FAF8F5]'
              : isDraggingQive
              ? 'border-[#1E2D23] bg-[#EFEAE2]'
              : 'border-dashed border-[#D5BEA4] hover:border-[#1E2D23] bg-[#FAF8F5]'
          }`}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDraggingQive(true);
          }}
          onDragLeave={() => setIsDraggingQive(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDraggingQive(false);
            if (e.dataTransfer.files?.[0]) {
              readFile(e.dataTransfer.files[0], onQiveLoaded);
            }
          }}
        >
          <input
            ref={qiveInputRef}
            type="file"
            accept=".csv,text/csv,text/plain"
            className="hidden"
            onChange={(e) => {
              if (e.target.files?.[0]) {
                readFile(e.target.files[0], onQiveLoaded);
              }
            }}
          />

          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center font-black text-xs font-['Montserrat',sans-serif]">
                1
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wider font-['Montserrat',sans-serif]">
                  Relatório Avançado Qive (SEFAZ)
                </h3>
                <p className="text-[11px] text-neutral-500">
                  Notas fiscais e CTe recebidos diretamente da Receita Federal
                </p>
              </div>
            </div>

            {qiveResult && (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-[#EFF6F1] text-[#233527] px-2 py-0.5 rounded border border-[#C5DAC9]">
                <CheckCircle2 className="w-3 h-3" />
                Carregado
              </span>
            )}
          </div>

          {qiveResult ? (
            <div className="bg-white border border-[#E2D9CE] rounded-lg p-3.5 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono font-semibold text-[#1E2D23] truncate max-w-[200px]" title={qiveFileName}>
                  {qiveFileName}
                </span>
                <span className="font-bold text-[#233527] bg-[#EFF6F1] px-2 py-0.5 rounded">
                  {qiveResult.totalRows} notas
                </span>
              </div>
              <div className="flex items-center justify-between text-xs pt-1 border-t border-[#F0EAE1]">
                <span className="text-neutral-500">Valor Total no Qive:</span>
                <span className="font-mono font-bold text-[#1E2D23]">{formatBRL(qiveResult.totalValue)}</span>
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  id="btn-replace-qive-file"
                  onClick={() => qiveInputRef.current?.click()}
                  className="text-[11px] text-[#8C6D4C] hover:text-[#1E2D23] font-semibold underline"
                >
                  Substituir arquivo
                </button>
                <span className="text-neutral-300">|</span>
                <button
                  id="btn-clear-qive-file"
                  onClick={onClearQive}
                  className="text-[11px] text-neutral-500 hover:text-red-700 font-semibold"
                >
                  Remover
                </button>
              </div>
            </div>
          ) : (
            <div
              onClick={() => qiveInputRef.current?.click()}
              className="cursor-pointer py-6 flex flex-col items-center justify-center text-center group"
            >
              <div className="w-12 h-12 rounded-full bg-white border border-[#E2D9CE] group-hover:border-[#1E2D23] flex items-center justify-center text-[#8C6D4C] mb-2 shadow-xs transition-colors">
                <UploadCloud className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-[#1E2D23]">
                Arraste o CSV do Qive ou <span className="text-[#8C6D4C] underline">clique aqui</span>
              </p>
              <p className="text-[11px] text-neutral-500 mt-0.5">
                Exportado do Qive com colunas: Chave de Acesso, Emitente, Valor Total...
              </p>
            </div>
          )}
        </div>

        {/* SLOT 2: TOTVS ENTRADAS */}
        <div
          className={`border-2 rounded-xl p-5 transition-all ${
            totvsResult
              ? 'border-[#233527] bg-[#FAF8F5]'
              : isDraggingTotvs
              ? 'border-[#1E2D23] bg-[#EFEAE2]'
              : 'border-dashed border-[#D5BEA4] hover:border-[#1E2D23] bg-[#FAF8F5]'
          }`}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDraggingTotvs(true);
          }}
          onDragLeave={() => setIsDraggingTotvs(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDraggingTotvs(false);
            if (e.dataTransfer.files?.[0]) {
              readFile(e.dataTransfer.files[0], onTotvsLoaded);
            }
          }}
        >
          <input
            ref={totvsInputRef}
            type="file"
            accept=".csv,text/csv,text/plain"
            className="hidden"
            onChange={(e) => {
              if (e.target.files?.[0]) {
                readFile(e.target.files[0], onTotvsLoaded);
              }
            }}
          />

          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center font-black text-xs font-['Montserrat',sans-serif]">
                2
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#1E2D23] uppercase tracking-wider font-['Montserrat',sans-serif]">
                  Entradas Lançadas no TOTVS (ERP)
                </h3>
                <p className="text-[11px] text-neutral-500">
                  Relatório fiscal de documentos escriturados no sistema TOTVS
                </p>
              </div>
            </div>

            {totvsResult && (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-[#EFF6F1] text-[#233527] px-2 py-0.5 rounded border border-[#C5DAC9]">
                <CheckCircle2 className="w-3 h-3" />
                Carregado
              </span>
            )}
          </div>

          {totvsResult ? (
            <div className="bg-white border border-[#E2D9CE] rounded-lg p-3.5 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono font-semibold text-[#1E2D23] truncate max-w-[200px]" title={totvsFileName}>
                  {totvsFileName}
                </span>
                <span className="font-bold text-[#233527] bg-[#EFF6F1] px-2 py-0.5 rounded">
                  {totvsResult.totalRows} linhas
                </span>
              </div>
              <div className="flex items-center justify-between text-xs pt-1 border-t border-[#F0EAE1]">
                <span className="text-neutral-500">Valor Total no TOTVS:</span>
                <span className="font-mono font-bold text-[#1E2D23]">
                  {formatBRL(totvsResult.records.reduce((acc, r) => acc + r.vlContabil, 0))}
                </span>
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  id="btn-replace-totvs-file"
                  onClick={() => totvsInputRef.current?.click()}
                  className="text-[11px] text-[#8C6D4C] hover:text-[#1E2D23] font-semibold underline"
                >
                  Substituir arquivo
                </button>
                <span className="text-neutral-300">|</span>
                <button
                  id="btn-clear-totvs-file"
                  onClick={onClearTotvs}
                  className="text-[11px] text-neutral-500 hover:text-red-700 font-semibold"
                >
                  Remover
                </button>
              </div>
            </div>
          ) : (
            <div
              onClick={() => totvsInputRef.current?.click()}
              className="cursor-pointer py-6 flex flex-col items-center justify-center text-center group"
            >
              <div className="w-12 h-12 rounded-full bg-white border border-[#E2D9CE] group-hover:border-[#1E2D23] flex items-center justify-center text-[#8C6D4C] mb-2 shadow-xs transition-colors">
                <UploadCloud className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-[#1E2D23]">
                Arraste o CSV de Entrada do TOTVS ou <span className="text-[#8C6D4C] underline">clique aqui</span>
              </p>
              <p className="text-[11px] text-neutral-500 mt-0.5">
                Arquivo com as 26 colunas fiscais habituais (Empresa, CFOP, Vl. Contábil, Chave...)
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Integration Status Footer */}
      <div className="mt-5 pt-4 border-t border-[#E2D9CE] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <ArrowRightLeft className="w-4 h-4 text-[#8C6D4C]" />
          {bothLoaded ? (
            <span className="text-[#233527] font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Conciliação Ativa: cruzamento automático por Chave de Acesso executado com sucesso.
            </span>
          ) : qiveResult ? (
            <span className="text-[#8C6D4C] font-semibold">
              Arquivo do Qive pronto! Importe o relatório de entradas do TOTVS para habilitar a comparação.
            </span>
          ) : totvsResult ? (
            <span className="text-[#8C6D4C] font-semibold">
              Arquivo do TOTVS pronto! Importe o relatório avançado do Qive para comparar com a SEFAZ.
            </span>
          ) : (
            <span className="text-neutral-500">
              Importe os 2 arquivos para conciliação automática, ou importe um individualmente para visualizá-lo.
            </span>
          )}
        </div>

        {bothLoaded && (
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-neutral-500">Chaves mapeadas automaticamente</span>
          </div>
        )}
      </div>
    </div>
  );
};
