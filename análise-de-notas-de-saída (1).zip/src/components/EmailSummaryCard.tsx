import React, { useState } from 'react';
import { Mail, Copy, Check, Info } from 'lucide-react';
import { generateEmailSummary } from '../utils/exporter';

interface EmailSummaryCardProps {
  minDateFormatted: string;
  maxDateFormatted: string;
  totalNotes: number;
  authorizedCount: number;
  authorizedTotalValue: number;
  canceledCount: number;
  inutilizedCount: number;
  otherCount: number;
}

export const EmailSummaryCard: React.FC<EmailSummaryCardProps> = ({
  minDateFormatted,
  maxDateFormatted,
  totalNotes,
  authorizedCount,
  authorizedTotalValue,
  canceledCount,
  inutilizedCount,
  otherCount,
}) => {
  const [copied, setCopied] = useState(false);

  const emailText = generateEmailSummary(
    minDateFormatted,
    maxDateFormatted,
    totalNotes,
    authorizedCount,
    authorizedTotalValue,
    canceledCount,
    inutilizedCount,
    otherCount
  );

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(emailText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      const textArea = document.createElement('textarea');
      textArea.value = emailText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-6">
      <div className="px-4 sm:px-6 py-3.5 bg-[#1E2D23] text-[#FAF7F2] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4]">
            <Mail className="w-3.5 h-3.5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider font-['Montserrat',sans-serif] text-[#FAF7F2]">
              Resumo da Análise (Padrão de E-mail)
            </h2>
            <p className="text-[11px] text-[#C2B7A3]">
              Texto pronto para envio e comunicação com a equipe fiscal/contábil
            </p>
          </div>
        </div>

        <button
          id="btn-copy-gmail-summary"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded bg-[#D5BEA4] hover:bg-[#C2A588] text-[#1E2D23] transition-all shadow-xs active:scale-98 uppercase tracking-wider"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-[#1E2D23]" />
              <span>Copiado com sucesso!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copiar Resumo do E-mail</span>
            </>
          )}
        </button>
      </div>

      <div className="p-4 sm:p-6 bg-[#FAF8F5]">
        <div className="relative bg-white border border-[#E2D9CE] rounded-md p-4 font-mono text-xs text-[#1E2D23] leading-relaxed whitespace-pre-wrap selection:bg-[#1E2D23] selection:text-[#D5BEA4]">
          {emailText}
        </div>

        <div className="mt-3 flex items-center gap-2 text-[11px] text-neutral-600">
          <Info className="w-3.5 h-3.5 text-[#8C6D4C] shrink-0" />
          <span>
            Os indicadores de conciliação ERP ("Lançadas", "Pendentes", "Indevidas") exibem{' '}
            <strong className="text-[#1E2D23] font-semibold">"Não disponível neste arquivo"</strong> pois
            o arquivo original de notas de saída contém dados de faturamento sem status de conferência de entrada.
          </span>
        </div>
      </div>
    </div>
  );
};
