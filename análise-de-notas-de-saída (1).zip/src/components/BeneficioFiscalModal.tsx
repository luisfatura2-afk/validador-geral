import React, { useState, useEffect } from 'react';
import {
  BeneficioFiscal,
  TipoBeneficioFiscal,
} from '../types/beneficioFiscal';
import { X, Tag, Plus, Check, HelpCircle } from 'lucide-react';

interface BeneficioFiscalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<BeneficioFiscal, 'id' | 'criadoEm'> & { id?: string }) => void;
  editingBeneficio?: BeneficioFiscal | null;
}

const COMMON_CFOPS = [
  { code: '5101', label: '5.101 - Venda prod. estab.' },
  { code: '5102', label: '5.102 - Venda merc. adq.' },
  { code: '5103', label: '5.103 - Venda prod. fora estab.' },
  { code: '6101', label: '6.101 - Venda interestadual prod.' },
  { code: '6102', label: '6.102 - Venda interestadual adq.' },
  { code: '7101', label: '7.101 - Exportação prod.' },
  { code: '7102', label: '7.102 - Exportação adq.' },
  { code: '1102', label: '1.102 - Compra merc. revenda' },
  { code: '2102', label: '2.102 - Compra interestadual' },
];

const UF_LIST = [
  'TODOS',
  'AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO',
  'MA', 'MG', 'MS', 'MT', 'PA', 'PB', 'PE', 'PI', 'PR',
  'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO',
];

export const BeneficioFiscalModal: React.FC<BeneficioFiscalModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingBeneficio,
}) => {
  const [codigo, setCodigo] = useState('');
  const [nome, setNome] = useState('');
  const [tipoBeneficio, setTipoBeneficio] = useState<TipoBeneficioFiscal>('ISENCAO');
  const [cfops, setCfops] = useState<string[]>([]);
  const [cfopInput, setCfopInput] = useState('');
  const [cstEsperado, setCstEsperado] = useState('');
  const [percentualReducao, setPercentualReducao] = useState<number | ''>('');
  const [aliquotaEfetiva, setAliquotaEfetiva] = useState<number | ''>('');
  const [uf, setUf] = useState('TODOS');
  const [baseLegal, setBaseLegal] = useState('');
  const [descricao, setDescricao] = useState('');
  const [ativo, setAtivo] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (editingBeneficio) {
      setCodigo(editingBeneficio.codigo);
      setNome(editingBeneficio.nome);
      setTipoBeneficio(editingBeneficio.tipoBeneficio);
      setCfops([...editingBeneficio.cfops]);
      setCstEsperado(editingBeneficio.cstEsperado || '');
      setPercentualReducao(editingBeneficio.percentualReducao ?? '');
      setAliquotaEfetiva(editingBeneficio.aliquotaEfetiva ?? '');
      setUf(editingBeneficio.uf || 'TODOS');
      setBaseLegal(editingBeneficio.baseLegal || '');
      setDescricao(editingBeneficio.descricao || '');
      setAtivo(editingBeneficio.ativo);
      setErrorMsg(null);
    } else {
      // Defaults for new
      setCodigo('');
      setNome('');
      setTipoBeneficio('ISENCAO');
      setCfops(['5101', '5102']);
      setCstEsperado('40');
      setPercentualReducao('');
      setAliquotaEfetiva('');
      setUf('TODOS');
      setBaseLegal('');
      setDescricao('');
      setAtivo(true);
      setErrorMsg(null);
    }
  }, [editingBeneficio, isOpen]);

  // Adjust suggested CST when tipoBeneficio changes (if creating new)
  const handleTipoChange = (tipo: TipoBeneficioFiscal) => {
    setTipoBeneficio(tipo);
    if (!editingBeneficio) {
      if (tipo === 'ISENCAO') setCstEsperado('40');
      else if (tipo === 'REDUCAO_BASE') {
        setCstEsperado('20');
        if (!percentualReducao) setPercentualReducao(33.33);
      } else if (tipo === 'DIFERIMENTO') setCstEsperado('51');
      else if (tipo === 'SUSPENSAO') setCstEsperado('50');
      else if (tipo === 'NAO_INCIDENCIA') setCstEsperado('41');
      else setCstEsperado('');
    }
  };

  const handleAddCfop = (codeToAdd?: string) => {
    const raw = codeToAdd || cfopInput;
    if (!raw) return;

    // Split by comma, semicolon or space
    const parts = raw
      .split(/[,;\s]+/)
      .map((c) => c.replace(/\D/g, '').trim())
      .filter((c) => c.length > 0);

    const newSet = new Set(cfops);
    parts.forEach((p) => newSet.add(p));
    setCfops(Array.from(newSet));
    setCfopInput('');
  };

  const handleRemoveCfop = (cToRemove: string) => {
    setCfops(cfops.filter((c) => c !== cToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!codigo.trim()) {
      setErrorMsg('Informe o código do benefício (ex: cBenef ou código interno).');
      return;
    }
    if (!nome.trim()) {
      setErrorMsg('Informe a descrição/nome do benefício fiscal.');
      return;
    }
    if (cfops.length === 0) {
      setErrorMsg('Vincule ao menos um código CFOP a este benefício fiscal.');
      return;
    }
    if (!baseLegal.trim()) {
      setErrorMsg('Informe a base legal ou fundamentação (ex: Artigo do RICMS, Convênio CONFAZ).');
      return;
    }

    onSave({
      id: editingBeneficio?.id,
      codigo: codigo.trim().toUpperCase(),
      nome: nome.trim(),
      tipoBeneficio,
      cfops,
      cstEsperado: cstEsperado.trim() || undefined,
      percentualReducao: percentualReducao === '' ? undefined : Number(percentualReducao),
      aliquotaEfetiva: aliquotaEfetiva === '' ? undefined : Number(aliquotaEfetiva),
      uf: uf.trim().toUpperCase(),
      baseLegal: baseLegal.trim(),
      descricao: descricao.trim() || undefined,
      ativo,
    });

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl border border-[#E2D9CE] shadow-2xl max-w-2xl w-full my-8 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#E2D9CE] flex items-center justify-between bg-[#FAF8F5] rounded-t-xl">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center font-bold">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1E2D23] font-['Montserrat',sans-serif]">
                {editingBeneficio ? 'Editar Benefício Fiscal' : 'Cadastrar Benefício Fiscal & Vínculo CFOP'}
              </h3>
              <p className="text-xs text-neutral-500">
                Parametrize incentivos de ICMS vinculados a CFOPs para validação preventiva no motor de regras.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-700 p-1.5 rounded-lg hover:bg-neutral-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 text-xs">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-xs font-semibold flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-600"></span>
              {errorMsg}
            </div>
          )}

          {/* Código + UF */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                Código do Benefício (cBenef / Código Interno) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="Ex: PR800000, SP000001, RS051000"
                value={codigo}
                onChange={(e) => setCodigo(e.target.value)}
                className="w-full px-3 py-2 border border-[#E2D9CE] rounded-lg font-mono font-bold text-sm text-[#1E2D23] focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
              />
              <span className="text-[10px] text-neutral-400 mt-0.5 block">
                Padrão da tabela cBenef da SEFAZ ou código interno da empresa.
              </span>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                UF Aplicável
              </label>
              <select
                value={uf}
                onChange={(e) => setUf(e.target.value)}
                className="w-full px-3 py-2 border border-[#E2D9CE] rounded-lg font-bold text-xs text-[#1E2D23] focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
              >
                {UF_LIST.map((u) => (
                  <option key={u} value={u}>
                    {u === 'TODOS' ? 'TODOS (Nacional)' : u}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Nome / Título */}
          <div>
            <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
              Nome do Benefício Fiscal <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Ex: Isenção de ICMS - Saídas Internas Hortifrutigranjeiros"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              className="w-full px-3 py-2 border border-[#E2D9CE] rounded-lg text-xs font-semibold text-[#1E2D23] focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
            />
          </div>

          {/* Tipo de Benefício + CST Esperado */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                Modalidade do Benefício <span className="text-rose-500">*</span>
              </label>
              <select
                value={tipoBeneficio}
                onChange={(e) => handleTipoChange(e.target.value as TipoBeneficioFiscal)}
                className="w-full px-3 py-2 border border-[#E2D9CE] rounded-lg font-bold text-xs text-[#1E2D23] focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
              >
                <option value="ISENCAO">🟢 Isenção Total de ICMS</option>
                <option value="REDUCAO_BASE">🟡 Redução de Base de Cálculo</option>
                <option value="DIFERIMENTO">🔵 Diferimento de ICMS</option>
                <option value="SUSPENSAO">🟣 Suspensão de ICMS</option>
                <option value="NAO_INCIDENCIA">⚪ Não Incidência / Imunidade</option>
                <option value="CREDITO_PRESUMIDO">🟠 Crédito Presumido / Outorgado</option>
                <option value="OUTROS">Incentivo Fiscal / Outros</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                CST / CSOSN Esperado
              </label>
              <input
                type="text"
                placeholder="Ex: 20, 40, 41, 50, 51"
                value={cstEsperado}
                onChange={(e) => setCstEsperado(e.target.value)}
                className="w-full px-3 py-2 border border-[#E2D9CE] rounded-lg font-mono text-xs text-[#1E2D23] focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
              />
              <span className="text-[10px] text-neutral-400 mt-0.5 block">
                CST usual: 20 (Redução), 40 (Isenção), 51 (Diferimento)
              </span>
            </div>
          </div>

          {/* Vínculo com CFOPs */}
          <div className="p-3 bg-[#FAF8F5] border border-[#E2D9CE] rounded-xl space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-[#1E2D23] uppercase flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-[#8C6D4C]" />
                Vínculo com Tipos de CFOP <span className="text-rose-500">*</span>
              </label>
              <span className="text-[10px] text-neutral-500 font-semibold">
                {cfops.length} CFOP{cfops.length !== 1 ? 's' : ''} vinculado{cfops.length !== 1 ? 's' : ''}
              </span>
            </div>

            <p className="text-[11px] text-neutral-500">
              O motor de regras auditará todas as notas fiscais emitidas ou escrituradas com estes CFOPs contra as regras deste benefício.
            </p>

            {/* Input to add CFOP */}
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Digite o CFOP (ex: 5101, 5102, 6101) e pressione Adicionar"
                value={cfopInput}
                onChange={(e) => setCfopInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCfop();
                  }
                }}
                className="flex-1 px-3 py-1.5 border border-[#E2D9CE] rounded-lg font-mono text-xs text-[#1E2D23] focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-white"
              />
              <button
                type="button"
                onClick={() => handleAddCfop()}
                className="px-3 py-1.5 bg-[#1E2D23] text-[#FAF7F2] font-bold rounded-lg text-xs hover:bg-[#2A3F31] transition-colors flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Adicionar</span>
              </button>
            </div>

            {/* Quick add chip list */}
            <div>
              <span className="text-[10px] font-bold text-neutral-400 block uppercase mb-1">
                Sugestões Rápidas:
              </span>
              <div className="flex flex-wrap gap-1">
                {COMMON_CFOPS.map((item) => {
                  const isAdded = cfops.includes(item.code);
                  return (
                    <button
                      key={item.code}
                      type="button"
                      onClick={() => (isAdded ? handleRemoveCfop(item.code) : handleAddCfop(item.code))}
                      className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold transition-all flex items-center gap-1 ${
                        isAdded
                          ? 'bg-[#1E2D23] text-white'
                          : 'bg-white border border-[#E2D9CE] text-neutral-700 hover:bg-neutral-100'
                      }`}
                    >
                      {isAdded && <Check className="w-2.5 h-2.5 text-[#D5BEA4]" />}
                      <span>{item.code}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Linked CFOP tags */}
            <div className="pt-2 border-t border-[#E2D9CE]/60">
              <span className="text-[10px] font-bold text-neutral-500 uppercase block mb-1">
                CFOPs Atualmente Vinculados:
              </span>
              {cfops.length === 0 ? (
                <span className="text-rose-600 text-xs font-semibold">
                  Nenhum CFOP vinculado ainda. Adicione ao menos um acima.
                </span>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {cfops.map((c) => (
                    <span
                      key={c}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#E8DCCB] text-[#1E2D23] font-mono font-bold text-xs border border-[#CBB8A1]"
                    >
                      <span>CFOP {c}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveCfop(c)}
                        className="hover:text-rose-600 transition-colors ml-0.5"
                        title="Remover CFOP"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Conditional: Redução de Base */}
          {tipoBeneficio === 'REDUCAO_BASE' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-amber-50/60 border border-amber-200 rounded-lg">
              <div>
                <label className="block text-[11px] font-bold text-amber-900 uppercase mb-1">
                  Percentual de Redução da Base (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="100"
                  placeholder="Ex: 33.33 ou 50"
                  value={percentualReducao}
                  onChange={(e) => setPercentualReducao(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg font-mono text-xs text-neutral-900 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-amber-900 uppercase mb-1">
                  Alíquota Efetiva Resultante (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="100"
                  placeholder="Ex: 7 ou 12"
                  value={aliquotaEfetiva}
                  onChange={(e) => setAliquotaEfetiva(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg font-mono text-xs text-neutral-900 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                />
              </div>
            </div>
          )}

          {/* Fundamentação Legal */}
          <div>
            <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
              Fundamentação Legal / Base Normativa <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Ex: Artigo 14 do Anexo II do RICMS/SP ou Convênio ICMS 52/91"
              value={baseLegal}
              onChange={(e) => setBaseLegal(e.target.value)}
              className="w-full px-3 py-2 border border-[#E2D9CE] rounded-lg text-xs font-medium text-[#1E2D23] focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
            />
          </div>

          {/* Descrição / Notas */}
          <div>
            <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
              Descrição Detalhada / Condições de Aplicação (Opcional)
            </label>
            <textarea
              rows={2}
              placeholder="Observações fiscais, mercadorias abrangidas, termos de acordo ou requisitos para fruição..."
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              className="w-full px-3 py-2 border border-[#E2D9CE] rounded-lg text-xs text-[#1E2D23] focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
            />
          </div>

          {/* Ativo switch */}
          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="beneficio-ativo"
              checked={ativo}
              onChange={(e) => setAtivo(e.target.checked)}
              className="w-4 h-4 text-[#1E2D23] rounded focus:ring-[#8C6D4C] border-[#E2D9CE]"
            />
            <label htmlFor="beneficio-ativo" className="text-xs font-bold text-[#1E2D23] cursor-pointer">
              Benefício Fiscal Ativo no Motor de Auditoria
            </label>
          </div>
        </form>

        {/* Footer */}
        <div className="p-4 border-t border-[#E2D9CE] flex items-center justify-between bg-[#FAF8F5] rounded-b-xl">
          <div className="flex items-center gap-1.5 text-neutral-500 text-[11px]">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Validações serão executadas em tempo real nos lotes de notas.</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-[#E2D9CE] text-neutral-700 hover:bg-neutral-100 rounded-lg text-xs font-bold transition-colors"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              className="px-4 py-2 bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
            >
              <Check className="w-4 h-4 text-[#D5BEA4]" />
              <span>{editingBeneficio ? 'Salvar Alterações' : 'Cadastrar Benefício'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
