import React, { useState, useRef } from 'react';
import { UploadCloud, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';
import { ParseResult } from '../utils/csvParser';

interface FileUploaderProps {
  onFileLoaded: (csvContent: string, fileName: string) => void;
  lastParseResult?: ParseResult | null;
  currentFileName?: string;
  hasData: boolean;
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  onFileLoaded,
  lastParseResult,
  currentFileName,
  hasData,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isReading, setIsReading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (!file) return;
    setErrorMessage(null);
    setIsReading(true);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        if (!text || text.trim() === '') {
          setErrorMessage('O arquivo selecionado está vazio.');
          setIsReading(false);
          return;
        }
        onFileLoaded(text, file.name);
      } catch {
        setErrorMessage('Erro ao ler o arquivo CSV. Verifique a codificação.');
      } finally {
        setIsReading(false);
      }
    };

    reader.onerror = () => {
      setErrorMessage('Falha na leitura do arquivo local.');
      setIsReading(false);
    };

    // Read as text with standard UTF-8
    reader.readAsText(file, 'UTF-8');
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  if (hasData && lastParseResult) {
    return (
      <div className="bg-white border border-[#E2D9CE] rounded-lg p-3.5 shadow-xs mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded bg-[#233527] border border-[#334D3C] flex items-center justify-center text-[#D5BEA4]">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm text-[#1E2D23] font-mono">{currentFileName}</span>
              <span className="text-xs bg-[#F3EFE9] text-[#1E2D23] px-2 py-0.5 rounded-full font-medium border border-[#E2D9CE]">
                {lastParseResult.totalRows} documentos lidos
              </span>
            </div>
            <p className="text-xs text-neutral-600">
              {lastParseResult.detectedColumns.length} colunas fiscais identificadas com sucesso no arquivo CSV.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center">
          <button
            id="btn-change-file"
            onClick={() => fileInputRef.current?.click()}
            className="text-xs font-semibold text-[#1E2D23] hover:text-black px-3 py-1.5 rounded border border-[#C8B6A2] hover:bg-[#F3EFE9] transition-colors"
          >
            Importar outro CSV
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv,text/plain"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFile(e.target.files[0]);
              }
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-xl p-6 sm:p-10 shadow-sm mb-8">
      <div className="max-w-2xl mx-auto text-center">
        {/* Concept flow indicator */}
        <div className="inline-flex items-center gap-1 sm:gap-2 px-3 py-1 bg-[#F5F1EB] border border-[#E2D9CE] rounded-full text-[11px] font-semibold text-[#1E2D23] uppercase tracking-wider mb-4">
          <span className="text-[#8C6D4C] font-bold">1. Importar CSV</span>
          <span className="text-neutral-400">→</span>
          <span>2. Análise Fiscal</span>
          <span className="text-neutral-400">→</span>
          <span>3. Pontos de Atenção</span>
          <span className="text-neutral-400">→</span>
          <span>4. Exportar</span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-bold text-[#1E2D23] tracking-tight font-['Cormorant_Garamond',serif] mb-2">
          Importe o arquivo CSV de Notas de Saída
        </h2>
        <p className="text-sm text-neutral-600 mb-6 leading-relaxed">
          Selecione ou arraste a planilha original exportada pelo sistema ERP da sua empresa. O sistema processará
          automaticamente as 26 colunas fiscais, apurando impostos, CFOPs, situações perante a SEFAZ
          e gerando o resumo executivo.
        </p>

        {/* Dropzone */}
        <div
          id="csv-dropzone"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-8 sm:p-12 cursor-pointer transition-all ${
            isDragging
              ? 'border-[#1E2D23] bg-[#EFEAE2] scale-[1.01]'
              : 'border-[#D5BEA4] hover:border-[#1E2D23] bg-[#FAF8F5] hover:bg-[#F5F1EB]'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv,text/plain"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFile(e.target.files[0]);
              }
            }}
          />

          <div className="flex flex-col items-center justify-center gap-3">
            <div className="w-16 h-16 rounded-full bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center shadow-sm">
              {isReading ? (
                <div className="w-6 h-6 border-2 border-[#D5BEA4] border-t-transparent rounded-full animate-spin" />
              ) : (
                <UploadCloud className="w-8 h-8" />
              )}
            </div>

            <div>
              <p className="text-sm font-bold text-[#1E2D23]">
                Arraste e solte o arquivo CSV aqui ou{' '}
                <span className="text-[#8C6D4C] underline font-semibold">clique para selecionar</span>
              </p>
              <p className="text-xs text-neutral-500 mt-1">
                Suporta formato padrão brasileiro com separador ponto e vírgula (;) ou vírgula (,)
              </p>
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded text-xs text-amber-900 flex items-center justify-center gap-2 text-left">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-700" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Local Security Guarantee */}
        <div className="mt-6 pt-6 border-t border-[#E2D9CE] flex items-center justify-center gap-2 text-xs text-neutral-600">
          <ShieldCheck className="w-4 h-4 text-[#233527] shrink-0" />
          <span>Processamento 100% no navegador. Nenhum dado é transmitido para a internet ou armazenado externamente.</span>
        </div>
      </div>
    </div>
  );
};
