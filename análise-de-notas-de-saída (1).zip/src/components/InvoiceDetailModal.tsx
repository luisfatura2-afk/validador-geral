import React, { useState, useEffect } from 'react';
import { X, Copy, Check, FileText, Building2, User, Landmark } from 'lucide-react';
import { InvoiceRecord } from '../types/fiscal';
import { formatBRL, formatDecimalBR } from '../utils/csvParser';

interface InvoiceDetailModalProps {
  invoice: InvoiceRecord | null;
  onClose: () => void;
}

export const InvoiceDetailModal: React.FC<InvoiceDetailModalProps> = ({ invoice, onClose }) => {
  const [copiedKey, setCopiedKey] = useState(false);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!invoice) return null;

  const handleCopyKey = () => {
    if (!invoice.chaveAcesso) return;
    navigator.clipboard.writeText(invoice.chaveAcesso);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2500);
  };

  const formatAccessKey = (key: string) => {
    if (!key) return 'Chave de acesso não informada';
    return key.replace(/(\d{4})/g, '$1 ').trim();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="bg-white border border-[#E2D9CE] rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#1E2D23] text-[#FAF7F2] flex items-center justify-between border-b border-[#2A3F31]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4] font-black text-sm font-['Montserrat',sans-serif]">
              NF
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold uppercase tracking-tight font-['Montserrat',sans-serif] text-[#FAF7F2]">
                  Nota Fiscal nº {invoice.notaFiscal || 'S/N'}
                </h3>
                <span className="text-xs font-mono bg-[#2A3F31] text-[#D5BEA4] px-2 py-0.5 rounded border border-[#3D5B47]">
                  Série {invoice.serie || '-'}
                </span>
                <span
                  className={`text-xs font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                    invoice.situacao.toLowerCase().includes('autoriz')
                      ? 'bg-[#EFF6F1] text-[#233527] border border-[#C5DAC9]'
                      : invoice.situacao.toLowerCase().includes('cancel')
                      ? 'bg-[#FAF0EE] text-[#8F3E35] border border-[#E8D0CE]'
                      : 'bg-[#FAF4E8] text-[#845E28] border border-[#EADFCB]'
                  }`}
                >
                  {invoice.situacao || 'Não informada'}
                </span>
              </div>
              <p className="text-xs text-[#C2B7A3] mt-0.5">
                {invoice.empresa} • Emissão: {invoice.dtEmissao || 'Data não informada'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#C2B7A3] hover:text-[#FAF7F2] hover:bg-[#2A3F31] rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 bg-[#FAF8F5]">
          {/* Chave de Acesso Box */}
          <div className="bg-white border border-[#E2D9CE] rounded-lg p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#1E2D23] flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#8C6D4C]" />
                Chave de Acesso Eletrônica (44 dígitos)
              </span>

              {invoice.chaveAcesso && (
                <button
                  id="btn-modal-copy-key"
                  onClick={handleCopyKey}
                  className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded bg-[#1E2D23] hover:bg-[#2A3F31] text-[#D5BEA4] transition-colors self-start sm:self-auto shadow-xs"
                >
                  {copiedKey ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Chave copiada!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copiar Chave</span>
                    </>
                  )}
                </button>
              )}
            </div>

            <div className="font-mono text-xs sm:text-sm font-semibold tracking-wider text-[#1E2D23] bg-[#FAF8F5] p-3 rounded border border-[#E2D9CE] select-all break-all">
              {formatAccessKey(invoice.chaveAcesso)}
            </div>
          </div>

          {/* Grid of details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 1. Identificação */}
            <div className="bg-white border border-[#E2D9CE] rounded-lg p-4">
              <div className="flex items-center gap-2 pb-2 mb-3 border-b border-[#F0EAE1]">
                <Building2 className="w-4 h-4 text-[#8C6D4C]" />
                <h4 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
                  Identificação do Documento
                </h4>
              </div>

              <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                <div>
                  <dt className="text-neutral-500 font-medium">Empresa:</dt>
                  <dd className="font-semibold text-[#1E2D23]">{invoice.empresa || '-'}</dd>
                </div>
                <div>
                  <dt className="text-neutral-500 font-medium">Espécie:</dt>
                  <dd className="font-semibold text-[#1E2D23]">{invoice.especie || '-'}</dd>
                </div>
                <div>
                  <dt className="text-neutral-500 font-medium">Número da NF:</dt>
                  <dd className="font-semibold text-[#1E2D23] font-mono">{invoice.notaFiscal || '-'}</dd>
                </div>
                <div>
                  <dt className="text-neutral-500 font-medium">Série:</dt>
                  <dd className="font-semibold text-[#1E2D23] font-mono">{invoice.serie || '-'}</dd>
                </div>
                <div>
                  <dt className="text-neutral-500 font-medium">Dt. Emissão:</dt>
                  <dd className="font-semibold text-[#1E2D23] font-mono">{invoice.dtEmissao || '-'}</dd>
                </div>
                <div>
                  <dt className="text-neutral-500 font-medium">Dt. Saída/Entrada:</dt>
                  <dd className="font-semibold text-[#1E2D23] font-mono">{invoice.dtSaidaEntrada || '-'}</dd>
                </div>
              </dl>
            </div>

            {/* 2. Destinatário / Pessoa */}
            <div className="bg-white border border-[#E2D9CE] rounded-lg p-4">
              <div className="flex items-center gap-2 pb-2 mb-3 border-b border-[#F0EAE1]">
                <User className="w-4 h-4 text-[#8C6D4C]" />
                <h4 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
                  Pessoa / Destinatário
                </h4>
              </div>

              <dl className="space-y-2 text-xs">
                <div>
                  <dt className="text-neutral-500 font-medium">Nome / Razão Social:</dt>
                  <dd className="font-bold text-[#1E2D23] text-sm">{invoice.nomePessoa || '-'}</dd>
                </div>
                <div className="grid grid-cols-2 gap-x-4">
                  <div>
                    <dt className="text-neutral-500 font-medium">Cód. Pessoa:</dt>
                    <dd className="font-semibold text-[#1E2D23] font-mono">{invoice.cdPessoa || '-'}</dd>
                  </div>
                  <div>
                    <dt className="text-neutral-500 font-medium">CFOP Aplicado:</dt>
                    <dd className="font-bold text-[#1E2D23] font-mono text-sm">
                      {invoice.cfop || '-'}
                    </dd>
                  </div>
                </div>
              </dl>
            </div>
          </div>

          {/* 3. Tributos e Valores */}
          <div className="bg-white border border-[#E2D9CE] rounded-lg p-4">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#F0EAE1]">
              <div className="flex items-center gap-2">
                <Landmark className="w-4 h-4 text-[#8C6D4C]" />
                <h4 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider">
                  Detalhamento dos Valores e Tributos
                </h4>
              </div>
              <span className="text-xs font-bold text-neutral-600">
                Valor Contábil: <strong className="font-mono text-[#1E2D23] text-sm">{formatBRL(invoice.vlContabil)}</strong>
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 text-xs">
              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">Valor Contábil</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlContabil)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">Alíquota ICMS</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatDecimalBR(invoice.aliqIcms)}%</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">Base ICMS</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlBaseIcms)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">Valor ICMS</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlIcms)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">ICMS Isento</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlIsentoIcms)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">Outro ICMS</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlOutroIcms)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">ICMS ST</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlIcmsSt)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">IPI</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlIpi)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">PIS</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlPis)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">COFINS</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlCofins)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">FCP</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlFcp)}</p>
              </div>

              <div className="bg-[#FAF8F5] p-2.5 rounded border border-[#E2D9CE]">
                <span className="text-[10px] text-neutral-500 font-semibold uppercase">FCP ST</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlFcpSt)}</p>
              </div>

              <div className="bg-[#FAF4E8] p-2.5 rounded border border-[#EADFCB]">
                <span className="text-[10px] text-[#845E28] font-semibold uppercase">IBS (Reforma)</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlIbs)}</p>
              </div>

              <div className="bg-[#FAF4E8] p-2.5 rounded border border-[#EADFCB]">
                <span className="text-[10px] text-[#845E28] font-semibold uppercase">CBS (Reforma)</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlCbs)}</p>
              </div>

              <div className="bg-[#FAF4E8] p-2.5 rounded border border-[#EADFCB]">
                <span className="text-[10px] text-[#845E28] font-semibold uppercase">IS (Reforma)</span>
                <p className="font-bold font-mono text-[#1E2D23]">{formatBRL(invoice.vlIs)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-[#FAF8F5] border-t border-[#E2D9CE] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold rounded bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] uppercase tracking-wider transition-colors"
          >
            Fechar Detalhes
          </button>
        </div>
      </div>
    </div>
  );
};
