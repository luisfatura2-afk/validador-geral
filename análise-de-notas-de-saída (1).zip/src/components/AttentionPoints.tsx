import React from 'react';
import { AlertTriangle, AlertCircle, Info, CheckCircle2, ChevronRight, X } from 'lucide-react';
import { AttentionPoint } from '../types/fiscal';

interface AttentionPointsProps {
  attentionPoints: AttentionPoint[];
  activeAttentionFilter?: string;
  onSelectAttentionFilter: (filterKey?: string) => void;
}

export const AttentionPoints: React.FC<AttentionPointsProps> = ({
  attentionPoints,
  activeAttentionFilter,
  onSelectAttentionFilter,
}) => {
  const getBadgeStyle = (term: AttentionPoint['term']) => {
    switch (term) {
      case 'Possível inconsistência':
        return 'bg-[#FAF0EE] text-[#8F3E35] border-[#E8D0CE]';
      case 'Verificar':
        return 'bg-[#FAF4E8] text-[#845E28] border-[#EADFCB]';
      case 'Campo não informado':
      default:
        return 'bg-[#EFF3F0] text-[#2B4434] border-[#D5E0D8]';
    }
  };

  const getIcon = (term: AttentionPoint['term']) => {
    switch (term) {
      case 'Possível inconsistência':
        return <AlertCircle className="w-4 h-4 text-[#8F3E35] shrink-0" />;
      case 'Verificar':
        return <AlertTriangle className="w-4 h-4 text-[#845E28] shrink-0" />;
      case 'Campo não informado':
      default:
        return <Info className="w-4 h-4 text-[#2B4434] shrink-0" />;
    }
  };

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-6">
      <div className="px-4 sm:px-6 py-3.5 bg-[#1E2D23] text-[#FAF7F2] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4]">
            <AlertTriangle className="w-3.5 h-3.5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider font-['Montserrat',sans-serif] text-[#FAF7F2]">
              Pontos de Atenção para Conferência
            </h2>
            <p className="text-[11px] text-[#C2B7A3]">
              Identificação automática de campos em branco, divergências cadastrais ou duplicidades
            </p>
          </div>
        </div>

        {activeAttentionFilter && (
          <button
            onClick={() => onSelectAttentionFilter(undefined)}
            className="inline-flex items-center gap-1 text-xs bg-[#2A3F31] hover:bg-[#344F3D] text-[#E8DEC8] px-2.5 py-1 rounded border border-[#3D5B47] transition-colors"
          >
            <span>Filtro ativo: {activeAttentionFilter}</span>
            <X className="w-3.5 h-3.5 ml-1 text-[#D5BEA4]" />
          </button>
        )}
      </div>

      <div className="p-4 sm:p-6">
        {attentionPoints.length === 0 ? (
          <div className="p-6 bg-[#EFF6F1] border border-[#D0E2D4] rounded-md text-center">
            <CheckCircle2 className="w-8 h-8 text-[#233527] mx-auto mb-2" />
            <p className="text-sm font-bold text-[#1E2D23]">Nenhum ponto de atenção identificado no arquivo!</p>
            <p className="text-xs text-[#35533F] mt-1">
              Todos os documentos autorizados contêm CFOP, chave de acesso de 44 dígitos e bases de cálculo preenchidas.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {attentionPoints.map((point) => {
              const isActive = activeAttentionFilter === point.filterKey;
              return (
                <div
                  key={point.id}
                  id={`attention-point-${point.id.toLowerCase()}`}
                  onClick={() => {
                    if (isActive) {
                      onSelectAttentionFilter(undefined);
                    } else {
                      onSelectAttentionFilter(point.filterKey);
                    }
                  }}
                  className={`p-3.5 rounded-lg border transition-all cursor-pointer text-left flex flex-col justify-between ${
                    isActive
                      ? 'bg-[#F7F3EB] border-[#1E2D23] ring-1 ring-[#1E2D23] shadow-xs'
                      : 'bg-white border-[#E2D9CE] hover:border-[#C5A88B] hover:bg-[#FAF8F5]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1.5">
                        {getIcon(point.term)}
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${getBadgeStyle(
                            point.term
                          )}`}
                        >
                          {point.term}
                        </span>
                      </div>
                      <span className="text-xs font-bold text-[#1E2D23] bg-[#F3EFE9] border border-[#E2D9CE] px-2 py-0.5 rounded-full">
                        {point.count} {point.count === 1 ? 'doc' : 'docs'}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-[#1E2D23] leading-snug">
                      {point.title}
                    </h4>
                    <p className="text-[11px] text-neutral-600 mt-1 leading-relaxed">
                      {point.description}
                    </p>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-[#F0EAE1] flex items-center justify-between text-[11px]">
                    <span className="text-neutral-500 font-medium">
                      {isActive ? 'Clique para remover filtro' : 'Clique para filtrar na tabela'}
                    </span>
                    <ChevronRight className={`w-3.5 h-3.5 ${isActive ? 'text-[#1E2D23]' : 'text-neutral-400'}`} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <p className="text-[11px] text-neutral-500 mt-4 leading-relaxed border-t border-[#F0EAE1] pt-3">
          <strong>Aviso legal/informativo:</strong> Os alertas acima são estritamente informativos para auxiliar a
          conferência da equipe. A ausência de determinados tributos ou campos não configura necessariamente
          irregularidade fiscal, podendo decorrer de imunidades, regimes diferenciados (ex: Simples Nacional) ou
          operações específicas (como remessas para conserto ou devoluções).
        </p>
      </div>
    </div>
  );
};
