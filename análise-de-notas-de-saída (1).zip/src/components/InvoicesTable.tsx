import React, { useState, useMemo } from 'react';
import {
  Table as TableIcon,
  Search,
  Download,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ExternalLink,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  CheckCircle,
  XCircle,
  AlertTriangle,
  HelpCircle,
  Copy,
  Check,
} from 'lucide-react';
import { InvoiceRecord } from '../types/fiscal';
import { formatBRL } from '../utils/csvParser';

interface InvoicesTableProps {
  records: InvoiceRecord[];
  onSelectInvoice: (record: InvoiceRecord) => void;
  onExportExcel: () => void;
}

type SortField =
  | 'notaFiscal'
  | 'dtEmissao'
  | 'empresa'
  | 'nomePessoa'
  | 'cfop'
  | 'situacao'
  | 'vlContabil'
  | 'vlIcms'
  | 'vlPis'
  | 'vlCofins';
type SortOrder = 'asc' | 'desc';

export const InvoicesTable: React.FC<InvoicesTableProps> = ({
  records,
  onSelectInvoice,
  onExportExcel,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [sortField, setSortField] = useState<SortField>('notaFiscal');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Quick table text search
  const filteredRecords = useMemo(() => {
    if (!searchTerm.trim()) return records;
    const term = searchTerm.toLowerCase();

    return records.filter(
      (r) =>
        r.notaFiscal.toLowerCase().includes(term) ||
        r.nomePessoa.toLowerCase().includes(term) ||
        r.cdPessoa.toLowerCase().includes(term) ||
        r.cfop.toLowerCase().includes(term) ||
        r.chaveAcesso.toLowerCase().includes(term) ||
        r.empresa.toLowerCase().includes(term)
    );
  }, [records, searchTerm]);

  // Sort
  const sortedRecords = useMemo(() => {
    return [...filteredRecords].sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];

      if (typeof aVal === 'string') {
        return sortOrder === 'asc'
          ? (aVal as string).localeCompare(bVal as string)
          : (bVal as string).localeCompare(aVal as string);
      }

      return sortOrder === 'asc' ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
    });
  }, [filteredRecords, sortField, sortOrder]);

  // Pagination calculation
  const totalPages = Math.max(Math.ceil(sortedRecords.length / pageSize), 1);
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedRecords.slice(start, start + pageSize);
  }, [sortedRecords, currentPage, pageSize]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const copyChave = (chave: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(chave);
    setCopiedKey(chave);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3 h-3 text-neutral-400 opacity-60 group-hover:opacity-100" />;
    }
    return sortOrder === 'asc' ? (
      <ArrowUp className="w-3 h-3 text-[#1E2D23]" />
    ) : (
      <ArrowDown className="w-3 h-3 text-[#1E2D23]" />
    );
  };

  const getStatusBadge = (situacao: string) => {
    const s = situacao.toLowerCase();
    if (s.includes('autoriz')) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-[#EFF6F1] text-[#233527] border border-[#C5DAC9]">
          <CheckCircle className="w-3 h-3" />
          <span>Autorizada</span>
        </span>
      );
    }
    if (s.includes('cancel')) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-[#FAF0EE] text-[#8F3E35] border border-[#E8D0CE]">
          <XCircle className="w-3 h-3" />
          <span>Cancelada</span>
        </span>
      );
    }
    if (s.includes('inutiliz')) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-[#FAF4E8] text-[#845E28] border border-[#EADFCB]">
          <AlertTriangle className="w-3 h-3" />
          <span>Inutilizada</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-[#EFF3F0] text-[#334D3C] border border-[#D5E0D8]">
        <HelpCircle className="w-3 h-3" />
        <span>{situacao || 'Outras'}</span>
      </span>
    );
  };

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-8">
      {/* Table Top Toolbar */}
      <div className="px-4 sm:px-6 py-3.5 bg-[#1E2D23] text-[#FAF7F2] flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4]">
            <TableIcon className="w-3.5 h-3.5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider font-['Montserrat',sans-serif] text-[#FAF7F2]">
              Espelho Analítico das Notas Fiscais
            </h2>
            <p className="text-[11px] text-[#C2B7A3]">
              Exibindo <strong>{sortedRecords.length}</strong> de {records.length} notas filtradas • Clique em qualquer linha para auditar os 26 campos
            </p>
          </div>
        </div>

        {/* Search & Actions */}
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <input
              type="text"
              placeholder="Buscar por NF, cliente, CFOP ou chave..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-8 pr-3 py-1.5 bg-[#2A3F31] border border-[#3D5B47] text-[#FAF7F2] placeholder-[#A39989] rounded text-xs focus:outline-hidden focus:border-[#D5BEA4] transition-colors"
            />
            <Search className="w-3.5 h-3.5 text-[#C2B7A3] absolute left-2.5 top-2.5 pointer-events-none" />
          </div>

          <button
            id="btn-export-table-excel"
            onClick={onExportExcel}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded bg-[#D5BEA4] hover:bg-[#C2A588] text-[#1E2D23] uppercase tracking-wider transition-all shrink-0 shadow-xs active:scale-98"
            title="Exportar notas da tabela atual para Excel"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Exportar</span>
          </button>
        </div>
      </div>

      {/* Main Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-[#FAF8F5] border-b border-[#E2D9CE] text-[#1E2D23] font-semibold uppercase tracking-wider text-[11px]">
            <tr>
              <th
                onClick={() => handleSort('notaFiscal')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors whitespace-nowrap"
              >
                <div className="flex items-center gap-1">
                  <span>Nota Fiscal</span>
                  {renderSortIcon('notaFiscal')}
                </div>
              </th>
              <th
                onClick={() => handleSort('dtEmissao')}
                className="py-3 px-3 cursor-pointer hover:bg-[#F0EAE1] transition-colors whitespace-nowrap"
              >
                <div className="flex items-center gap-1">
                  <span>Emissão</span>
                  {renderSortIcon('dtEmissao')}
                </div>
              </th>
              <th
                onClick={() => handleSort('empresa')}
                className="py-3 px-3 cursor-pointer hover:bg-[#F0EAE1] transition-colors whitespace-nowrap"
              >
                <div className="flex items-center gap-1">
                  <span>Empresa</span>
                  {renderSortIcon('empresa')}
                </div>
              </th>
              <th
                onClick={() => handleSort('nomePessoa')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors"
              >
                <div className="flex items-center gap-1">
                  <span>Destinatário / Cliente</span>
                  {renderSortIcon('nomePessoa')}
                </div>
              </th>
              <th
                onClick={() => handleSort('cfop')}
                className="py-3 px-3 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-center whitespace-nowrap"
              >
                <div className="flex items-center justify-center gap-1">
                  <span>CFOP</span>
                  {renderSortIcon('cfop')}
                </div>
              </th>
              <th
                onClick={() => handleSort('situacao')}
                className="py-3 px-3 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-center whitespace-nowrap"
              >
                <div className="flex items-center justify-center gap-1">
                  <span>Situação</span>
                  {renderSortIcon('situacao')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlContabil')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right whitespace-nowrap"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Vl. Contábil</span>
                  {renderSortIcon('vlContabil')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlIcms')}
                className="py-3 px-3 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right whitespace-nowrap"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>ICMS</span>
                  {renderSortIcon('vlIcms')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlPis')}
                className="py-3 px-3 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right whitespace-nowrap hidden lg:table-cell"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>PIS</span>
                  {renderSortIcon('vlPis')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlCofins')}
                className="py-3 px-3 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right whitespace-nowrap hidden lg:table-cell"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>COFINS</span>
                  {renderSortIcon('vlCofins')}
                </div>
              </th>
              <th className="py-3 px-4 text-center whitespace-nowrap">Chave de Acesso</th>
              <th className="py-3 px-3 text-center whitespace-nowrap">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2D9CE] bg-white">
            {paginatedRecords.length === 0 ? (
              <tr>
                <td colSpan={12} className="py-12 text-center text-neutral-500">
                  Nenhuma nota fiscal encontrada com os critérios de busca especificados.
                </td>
              </tr>
            ) : (
              paginatedRecords.map((r) => (
                <tr
                  key={r.id}
                  onClick={() => onSelectInvoice(r)}
                  className="hover:bg-[#FAF8F5] cursor-pointer transition-colors text-neutral-800 group"
                >
                  <td className="py-3 px-4 whitespace-nowrap font-mono font-bold text-[#1E2D23]">
                    {r.notaFiscal}
                    {r.serie && <span className="text-[10px] text-neutral-600 ml-1">({r.serie})</span>}
                  </td>
                  <td className="py-3 px-3 whitespace-nowrap font-mono text-neutral-700">
                    {r.dtEmissao || '-'}
                  </td>
                  <td className="py-3 px-3 whitespace-nowrap font-semibold text-[#1E2D23]">
                    {r.empresa || '-'}
                  </td>
                  <td className="py-3 px-4 max-w-xs truncate">
                    <div className="font-medium text-[#1E2D23] truncate" title={r.nomePessoa}>
                      {r.nomePessoa || <span className="text-amber-700 italic">Não informado</span>}
                    </div>
                    {r.cdPessoa && (
                      <div className="text-[10px] text-neutral-500 font-mono">
                        Cód: {r.cdPessoa}
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    <span className="font-mono font-bold bg-[#F3EFE9] text-[#1E2D23] px-2 py-0.5 rounded border border-[#E2D9CE]">
                      {r.cfop || <span className="text-amber-700">Vazio</span>}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    {getStatusBadge(r.situacao)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-[#1E2D23] whitespace-nowrap">
                    {formatBRL(r.vlContabil)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-neutral-700 whitespace-nowrap">
                    {formatBRL(r.vlIcms)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-neutral-700 whitespace-nowrap hidden lg:table-cell">
                    {formatBRL(r.vlPis)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-neutral-700 whitespace-nowrap hidden lg:table-cell">
                    {formatBRL(r.vlCofins)}
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    {r.chaveAcesso ? (
                      <div className="inline-flex items-center gap-1">
                        <span className="font-mono text-[10px] text-neutral-600 max-w-[130px] truncate" title={r.chaveAcesso}>
                          ...{r.chaveAcesso.slice(-14)}
                        </span>
                        <button
                          onClick={(e) => copyChave(r.chaveAcesso, e)}
                          className="p-1 text-neutral-500 hover:text-[#1E2D23] rounded transition-colors"
                          title="Copiar chave de acesso completa (44 dígitos)"
                        >
                          {copiedKey === r.chaveAcesso ? (
                            <Check className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    ) : (
                      <span className="text-[10px] text-amber-700 italic">Sem chave</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectInvoice(r);
                      }}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#8C6D4C] hover:text-[#1E2D23] transition-colors"
                    >
                      <span>Auditar</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="px-4 sm:px-6 py-3.5 bg-[#FAF8F5] border-t border-[#E2D9CE] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-neutral-600">Linhas por página:</span>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="px-2 py-1 border border-[#E2D9CE] rounded bg-white text-[#1E2D23] font-medium focus:outline-hidden focus:border-[#1E2D23]"
          >
            <option value={10}>10</option>
            <option value={15}>15</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
          <span className="text-neutral-500 ml-2">
            Mostrando {sortedRecords.length === 0 ? 0 : (currentPage - 1) * pageSize + 1} a{' '}
            {Math.min(currentPage * pageSize, sortedRecords.length)} de {sortedRecords.length} notas
          </span>
        </div>

        {/* Page navigation buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setCurrentPage(1)}
            disabled={currentPage === 1}
            className="p-1 rounded border border-[#E2D9CE] bg-white hover:bg-[#F3EFE9] disabled:opacity-40 disabled:cursor-not-allowed text-[#1E2D23]"
            title="Primeira página"
          >
            <ChevronsLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
            disabled={currentPage === 1}
            className="p-1 rounded border border-[#E2D9CE] bg-white hover:bg-[#F3EFE9] disabled:opacity-40 disabled:cursor-not-allowed text-[#1E2D23]"
            title="Página anterior"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <span className="px-3 py-1 font-mono font-medium text-[#1E2D23]">
            {currentPage} / {totalPages}
          </span>

          <button
            onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="p-1 rounded border border-[#E2D9CE] bg-white hover:bg-[#F3EFE9] disabled:opacity-40 disabled:cursor-not-allowed text-[#1E2D23]"
            title="Próxima página"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => setCurrentPage(totalPages)}
            disabled={currentPage === totalPages}
            className="p-1 rounded border border-[#E2D9CE] bg-white hover:bg-[#F3EFE9] disabled:opacity-40 disabled:cursor-not-allowed text-[#1E2D23]"
            title="Última página"
          >
            <ChevronsRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
