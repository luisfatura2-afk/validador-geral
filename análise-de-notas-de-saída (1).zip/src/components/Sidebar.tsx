import React from 'react';
import {
  BarChart3,
  FileOutput,
  ArrowRightLeft,
  Scale,
  FolderArchive,
  ShieldAlert,
  History,
  ChevronLeft,
  ChevronRight,
  HelpCircle,
  FileCheck2,
} from 'lucide-react';

export type MainNavigationModule =
  | 'DASHBOARD'
  | 'SAIDA'
  | 'ENTRADA'
  | 'APURACAO'
  | 'CENTRAL_DADOS'
  | 'AUDITORIA'
  | 'HISTORICO';

interface SidebarProps {
  currentModule: MainNavigationModule;
  onSelectModule: (module: MainNavigationModule) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onOpenHelp: () => void;
  saidaCount: number;
  entradaCount: number;
  reconciledCount: number;
  historyCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentModule,
  onSelectModule,
  isCollapsed,
  onToggleCollapse,
  onOpenHelp,
  saidaCount,
  entradaCount,
  reconciledCount,
  historyCount,
}) => {
  const navItems = [
    {
      id: 'DASHBOARD' as MainNavigationModule,
      label: 'Dashboard Executivo',
      icon: BarChart3,
      badge: saidaCount > 0 || entradaCount > 0 ? 'Ativo' : undefined,
      description: 'KPIs, saúde fiscal e visão gerencial',
    },
    {
      id: 'SAIDA' as MainNavigationModule,
      label: 'Notas de Saída',
      icon: FileOutput,
      badge: saidaCount > 0 ? `${saidaCount}` : undefined,
      description: 'TOTVS ERP - Análise de faturamento e CFOP',
    },
    {
      id: 'ENTRADA' as MainNavigationModule,
      label: 'Conciliação de Entradas',
      icon: ArrowRightLeft,
      badge: reconciledCount > 0 ? `${reconciledCount}` : undefined,
      description: 'Qive SEFAZ × TOTVS ERP',
    },
    {
      id: 'APURACAO' as MainNavigationModule,
      label: 'Apuração Fiscal',
      icon: Scale,
      badge: 'Déb − Créd',
      description: 'Compensação não-cumulativa ICMS/PIS/COFINS',
    },
    {
      id: 'CENTRAL_DADOS' as MainNavigationModule,
      label: 'Central de Dados',
      icon: FolderArchive,
      badge: saidaCount + entradaCount > 0 ? `${saidaCount + entradaCount}` : undefined,
      description: 'Entradas, Saídas, Devoluções, CT-e, NFS-e',
    },
    {
      id: 'AUDITORIA' as MainNavigationModule,
      label: 'Motor de Auditoria',
      icon: ShieldAlert,
      badge: 'Regras',
      description: 'Conformidade fiscal e alertas padronizados',
    },
    {
      id: 'HISTORICO' as MainNavigationModule,
      label: 'Histórico de Importações',
      icon: History,
      badge: historyCount > 0 ? `${historyCount}` : undefined,
      description: 'Logs de arquivos processados e integridade',
    },
  ];

  return (
    <aside
      className={`bg-[#1E2D23] text-[#FAF7F2] border-r border-[#2C4032] flex flex-col transition-all duration-200 select-none z-20 shrink-0 ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="h-16 px-4 flex items-center justify-between border-b border-[#2C4032]">
        {!isCollapsed && (
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-lg bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4] shrink-0 font-black">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div className="truncate">
              <div className="text-xs font-black uppercase tracking-wider text-[#FAF7F2] font-['Montserrat',sans-serif]">
                TXC Fiscal Control
              </div>
              <div className="text-[10px] text-[#D5BEA4] font-medium truncate">
                V2.0 • Arquitetura Modular
              </div>
            </div>
          </div>
        )}

        {isCollapsed && (
          <div className="w-full flex justify-center">
            <div className="w-8 h-8 rounded-lg bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4] font-black text-xs">
              TXC
            </div>
          </div>
        )}

        <button
          onClick={onToggleCollapse}
          className="text-[#C2B7A3] hover:text-white p-1 rounded hover:bg-[#2A3F31] transition-colors hidden sm:block shrink-0"
          title={isCollapsed ? 'Expandir menu lateral' : 'Recolher menu lateral'}
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 py-4 px-2 space-y-1.5 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = currentModule === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => onSelectModule(item.id)}
              title={isCollapsed ? `${item.label} - ${item.description}` : undefined}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all group relative text-left ${
                isActive
                  ? 'bg-[#D5BEA4] text-[#1E2D23] shadow-xs font-bold'
                  : 'text-[#E8DEC8] hover:text-white hover:bg-[#2A3F31]/70'
              }`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition-colors ${
                  isActive ? 'text-[#1E2D23]' : 'text-[#D5BEA4] group-hover:text-white'
                }`}
              />

              {!isCollapsed && (
                <div className="flex-1 truncate">
                  <div className="flex items-center justify-between">
                    <span className="truncate">{item.label}</span>
                    {item.badge && (
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full uppercase tracking-wider shrink-0 ${
                          isActive
                            ? 'bg-[#1E2D23] text-[#FAF7F2]'
                            : 'bg-[#2A3F31] text-[#D5BEA4] border border-[#3D5B47]'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </div>
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Sidebar Footer */}
      <div className="p-3 border-t border-[#2C4032]">
        <button
          onClick={onOpenHelp}
          className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs text-[#D5BEA4] hover:text-white hover:bg-[#2A3F31] rounded-lg transition-colors ${
            isCollapsed ? 'justify-center' : ''
          }`}
          title="Manual e Instruções de Uso"
        >
          <HelpCircle className="w-4 h-4 shrink-0 text-[#D5BEA4]" />
          {!isCollapsed && <span className="font-medium truncate">Guia e Ajuda</span>}
        </button>

        {!isCollapsed && (
          <div className="mt-2 pt-2 border-t border-[#2C4032]/60 text-[10px] text-neutral-400 text-center">
            Processamento 100% Client-Side
          </div>
        )}
      </div>
    </aside>
  );
};
