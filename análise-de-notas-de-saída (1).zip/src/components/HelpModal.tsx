import React from 'react';
import { X, HelpCircle, Terminal, FileSpreadsheet, ShieldCheck, ArrowRightLeft, CheckCircle2 } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const expectedColumnsTotvs = [
    'Empresa',
    'Situação',
    'Dt. emissão',
    'Dt. saída/entrada',
    'Esp.',
    'Nota fiscal',
    'série',
    'Cd. pessoa',
    'Nome pessoa',
    'CFOP',
    'Vl. contábil',
    'Aliq. ICMS',
    'Vl. base ICMS',
    'Vl. ICMS',
    'Vl. isento ICMS',
    'Vl. outro ICMS',
    'Vl. IPI',
    'Vl. ICMS ST',
    'Vl. PIS',
    'Vl. COFINS',
    'Vl. FCP',
    'Vl. FCP ST',
    'VL. IBS',
    'VL. CBS',
    'VL. IS',
    'Chave acesso',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className="bg-white border border-[#E2D9CE] rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#1E2D23] text-[#FAF7F2] flex items-center justify-between border-b border-[#2A3F31]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4]">
              <HelpCircle className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold uppercase tracking-tight font-['Montserrat',sans-serif] text-[#FAF7F2]">
              Instruções de Uso & Guia de Conciliação
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#C2B7A3] hover:text-[#FAF7F2] hover:bg-[#2A3F31] rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-neutral-700 leading-relaxed bg-[#FAF8F5]">
          {/* Section: Conciliação Qive x TOTVS */}
          <div className="bg-white border border-[#233527] rounded-lg p-4 shadow-2xs">
            <div className="flex items-center gap-2 mb-2 font-bold text-[#1E2D23] text-sm">
              <ArrowRightLeft className="w-4 h-4 text-[#8C6D4C]" />
              Como Funciona a Conciliação de Entradas (Qive × TOTVS)
            </div>
            <p className="text-neutral-600 mb-3">
              O sistema compara automaticamente as notas fiscais recebidas da SEFAZ pelo <strong>Qive</strong> com as notas escrituradas no seu sistema <strong>TOTVS</strong>:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
              <div className="p-2.5 rounded bg-[#EFF6F1] border border-[#C5DAC9]">
                <strong className="text-[#233527] block mb-0.5">1. Cruzamento por Chave de Acesso</strong>
                <span>Compara os 44 dígitos numéricos da chave eletrônica para identificar a presença de cada nota em ambos os relatórios.</span>
              </div>
              <div className="p-2.5 rounded bg-[#FAF0EE] border border-[#E8D0CE]">
                <strong className="text-[#8F3E35] block mb-0.5">2. Detecção de Pendências no TOTVS</strong>
                <span>Aponta notas autorizadas na SEFAZ que ainda NÃO foram lançadas no TOTVS (evitando perda de prazos e multas).</span>
              </div>
              <div className="p-2.5 rounded bg-[#FAF4E8] border border-[#EADFCB]">
                <strong className="text-[#845E28] block mb-0.5">3. Auditoria de Valores & CFOP</strong>
                <span>Calcula a soma de itens no TOTVS e compara com o valor total emitido no Qive para apontar divergências monetárias.</span>
              </div>
              <div className="p-2.5 rounded bg-[#EFF3F0] border border-[#D5E0D8]">
                <strong className="text-[#334D3C] block mb-0.5">4. Notas Canceladas na SEFAZ</strong>
                <span>Sinaliza notas canceladas na SEFAZ para garantir que não foram indevidamente escrituradas no ERP.</span>
              </div>
            </div>
          </div>

          {/* Section: Painel de Indicadores */}
          <div className="bg-white border border-[#E2D9CE] rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2 font-bold text-[#1E2D23] text-sm">
              <span className="w-2 h-2 rounded-full bg-[#8C6D4C]" />
              Painel de Indicadores & Métricas Estratégicas
            </div>
            <p className="text-neutral-600 mb-2">
              A tela de <strong>Indicadores</strong> consolida a visão 360° da operação fiscal:
            </p>
            <ul className="list-disc list-inside space-y-1 text-neutral-600 pl-1">
              <li><strong>Taxa de Conciliação:</strong> Percentual de documentos emitidos na SEFAZ devidamente integrados no ERP.</li>
              <li><strong>Top Fornecedores Pendentes:</strong> Relação ordenada dos emitentes com maior valor de notas aguardando lançamento no TOTVS.</li>
              <li><strong>Score de Saúde Fiscal:</strong> Nota de conformidade de 0 a 100 com semáforo de risco e diagnóstico automático.</li>
              <li><strong>Carga Tributária Efetiva:</strong> Proporção de ICMS, PIS, COFINS e IPI sobre o faturamento de saídas.</li>
            </ul>
          </div>

          {/* Section: Totvs Columns */}
          <div className="bg-white border border-[#E2D9CE] rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2 font-bold text-[#1E2D23] text-sm">
              <FileSpreadsheet className="w-4 h-4 text-[#8C6D4C]" />
              Estrutura do CSV do TOTVS (26 Colunas Padrão)
            </div>
            <p className="text-neutral-600 mb-3">
              Colunas identificadas automaticamente tanto para notas de saída quanto para entradas:
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {expectedColumnsTotvs.map((col, idx) => (
                <div
                  key={col}
                  className="bg-[#FAF8F5] border border-[#E2D9CE] px-2 py-1 rounded flex items-center gap-1.5"
                >
                  <span className="text-[10px] text-[#8C6D4C] font-mono font-bold w-4">{idx + 1}.</span>
                  <span className="font-semibold text-[#1E2D23] font-mono truncate text-[11px]">{col}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Privacy and Fiscal Control */}
          <div className="p-4 bg-[#EFF6F1] border border-[#D0E2D4] rounded-lg flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[#233527] shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-[#1E2D23] text-sm">Privacidade e Sigilo Fiscal Garantidos</h4>
              <p className="text-[#35533F] text-[11px] mt-1">
                Nenhum documento ou dado confidencial é enviado para servidores externos ou internet. Todo o processamento,
                leitura de chaves, conciliação e exportação é processado 100% no motor JavaScript do seu navegador.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-[#FAF8F5] border-t border-[#E2D9CE] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold rounded bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] uppercase tracking-wider transition-colors"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
