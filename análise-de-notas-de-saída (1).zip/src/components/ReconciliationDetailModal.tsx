import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  CheckCircle2,
  AlertOctagon,
  Scale,
  FileQuestion,
  XCircle,
  Building,
  FileText,
  ShieldCheck,
} from 'lucide-react';
import { ReconciledItem } from '../types/reconciliation';
import { formatBRL } from '../utils/reconciliationEngine';

interface ReconciliationDetailModalProps {
  item: ReconciledItem | null;
  onClose: () => void;
}

export const ReconciliationDetailModal: React.FC<ReconciliationDetailModalProps> = ({
  item,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);

  if (!item) return null;

  const handleCopyChave = () => {
    if (!item.chaveAcesso) return;
    navigator.clipboard.writeText(item.chaveAcesso);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const hasDivergence = item.status === 'VALUE_DIVERGENCE';
  const isPending = item.status === 'PENDING_IN_TOTVS';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white border border-[#E2D9CE] rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#FAF8F5] border-b border-[#E2D9CE] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-[#1E2D23] font-['Montserrat',sans-serif]">
                  Auditoria de Nota Fiscal de Entrada
                </h3>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-neutral-200 text-neutral-800">
                  {item.tipoDocumento} {item.numero} {item.serie ? `s.${item.serie}` : ''}
                </span>
              </div>
              <p className="text-xs text-neutral-500">
                Comparativo detalhado: Dados capturados da SEFAZ (Qive) × Escrituração no ERP (TOTVS)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chave de Acesso Bar */}
        <div className="px-6 py-3 bg-[#F5F1EB] border-b border-[#E2D9CE] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-neutral-600 uppercase tracking-wider">
              Chave de Acesso Eletrônica:
            </span>
            <span className="font-mono font-bold text-xs text-[#1E2D23] select-all">
              {item.chaveAcesso || 'Não informada'}
            </span>
          </div>

          {item.chaveAcesso && (
            <button
              onClick={handleCopyChave}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold bg-white border border-[#C8B6A2] hover:bg-[#FAF8F5] text-[#1E2D23] transition-colors self-start sm:self-auto"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Copiada!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-[#8C6D4C]" />
                  <span>Copiar Chave</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Modal Body: Side-by-Side Comparison */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Status Alert Banner */}
          <div
            className={`p-3.5 rounded-lg border flex items-center justify-between gap-3 text-xs ${
              item.status === 'MATCHED'
                ? 'bg-[#EFF6F1] border-[#C5DAC9] text-[#233527]'
                : item.status === 'PENDING_IN_TOTVS'
                ? 'bg-[#FAF0EE] border-[#E8D0CE] text-[#8F3E35]'
                : item.status === 'VALUE_DIVERGENCE'
                ? 'bg-[#FAF4E8] border-[#EADFCB] text-[#845E28]'
                : 'bg-neutral-100 border-neutral-300 text-neutral-700'
            }`}
          >
            <div className="flex items-center gap-2 font-bold">
              {item.status === 'MATCHED' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
              {item.status === 'PENDING_IN_TOTVS' && <AlertOctagon className="w-4 h-4 text-red-600" />}
              {item.status === 'VALUE_DIVERGENCE' && <Scale className="w-4 h-4 text-amber-600" />}
              {item.status === 'ONLY_IN_TOTVS' && <FileQuestion className="w-4 h-4 text-neutral-600" />}
              {item.status === 'CANCELLED_SEFAZ' && <XCircle className="w-4 h-4 text-neutral-600" />}
              <span>Diagnóstico: {item.statusLabel}</span>
            </div>

            {hasDivergence && (
              <span className="font-mono font-bold bg-white/80 px-2 py-0.5 rounded border border-current">
                Diferença: {formatBRL(item.diferencaValor)}
              </span>
            )}
          </div>

          {/* 2-Column Comparison Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* COLUMN 1: QIVE (SEFAZ) */}
            <div className="border border-[#E2D9CE] rounded-lg p-4 bg-[#FAF8F5]">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#E2D9CE]">
                <span className="font-bold text-xs uppercase tracking-wider text-[#1E2D23] font-['Montserrat',sans-serif]">
                  1. Relatório Avançado Qive (SEFAZ)
                </span>
                {item.qive ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#EFF6F1] text-[#233527] border border-[#C5DAC9]">
                    Presente no Qive
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-neutral-200 text-neutral-600">
                    Ausente no Qive
                  </span>
                )}
              </div>

              {item.qive ? (
                <div className="space-y-2.5 text-xs">
                  <div>
                    <span className="text-neutral-500 block text-[11px]">Emitente / Razão Social:</span>
                    <strong className="text-[#1E2D23]">{item.qive.nomeEmitente || '-'}</strong>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-neutral-500 block text-[11px]">CNPJ Emitente:</span>
                      <span className="font-mono text-[#1E2D23]">{item.qive.cnpjEmitente || '-'}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 block text-[11px]">IE Emitente:</span>
                      <span className="font-mono text-[#1E2D23]">{item.qive.ieEmitente || '-'}</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-neutral-500 block text-[11px]">Data Emissão:</span>
                      <span className="font-mono text-[#1E2D23]">{item.qive.dataEmissao || '-'}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 block text-[11px]">Status SEFAZ:</span>
                      <span className="font-semibold text-[#1E2D23]">{item.qive.status || 'Autorizada'}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[11px]">Manifestação do Destinatário:</span>
                    <span className="font-semibold text-[#8C6D4C]">{item.qive.manifestacao || '-'}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[11px]">Natureza da Operação:</span>
                    <span className="text-neutral-700">{item.qive.naturezaOperacao || '-'}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[11px]">CFOPs no XML:</span>
                    <span className="font-mono text-neutral-700">{item.qive.cfops || '-'}</span>
                  </div>
                  <div className="pt-2 border-t border-[#E2D9CE] flex items-center justify-between">
                    <span className="text-neutral-600 font-bold">Valor Total da Nota (SEFAZ):</span>
                    <span className="font-mono font-bold text-sm text-[#1E2D23]">
                      {formatBRL(item.qive.valorTotal)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-neutral-500">
                    <span>Valor ICMS destacado:</span>
                    <span className="font-mono">{formatBRL(item.qive.valorIcms)}</span>
                  </div>
                </div>
              ) : (
                <div className="py-8 text-center text-neutral-500 text-xs">
                  Este documento não foi localizado na planilha exportada do Qive.
                </div>
              )}
            </div>

            {/* COLUMN 2: TOTVS (ERP) */}
            <div className="border border-[#E2D9CE] rounded-lg p-4 bg-[#FAF8F5]">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#E2D9CE]">
                <span className="font-bold text-xs uppercase tracking-wider text-[#1E2D23] font-['Montserrat',sans-serif]">
                  2. Escrituração no TOTVS (ERP)
                </span>
                {item.totvs ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#EFF6F1] text-[#233527] border border-[#C5DAC9]">
                    Lançada no TOTVS
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-100 text-[#8F3E35] border border-red-200">
                    Falta Lançar no ERP
                  </span>
                )}
              </div>

              {item.totvs ? (
                <div className="space-y-2.5 text-xs">
                  <div>
                    <span className="text-neutral-500 block text-[11px]">Fornecedor no TOTVS:</span>
                    <strong className="text-[#1E2D23]">{item.totvs.nomePessoa || '-'}</strong>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-neutral-500 block text-[11px]">Código Pessoa / Fornecedor:</span>
                      <span className="font-mono text-[#1E2D23]">{item.totvs.cdPessoa || '-'}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 block text-[11px]">Empresa / Filial:</span>
                      <span className="font-mono text-[#1E2D23]">{item.totvs.empresa || '-'}</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-neutral-500 block text-[11px]">Dt. Emissão / Entrada:</span>
                      <span className="font-mono text-[#1E2D23]">{item.totvs.dtEmissao} / {item.totvs.dtSaidaEntrada || '-'}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 block text-[11px]">Situação TOTVS:</span>
                      <span className="font-semibold text-[#1E2D23]">{item.totvs.situacao || '-'}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[11px]">Espécie / Modelo:</span>
                    <span className="font-semibold text-neutral-700">{item.totvs.especie || '-'}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[11px]">CFOP de Entrada:</span>
                    <span className="font-mono text-neutral-700">{item.cfops || item.totvs.cfop}</span>
                  </div>
                  <div className="pt-2 border-t border-[#E2D9CE] flex items-center justify-between">
                    <span className="text-neutral-600 font-bold">Valor Contábil Escriturado:</span>
                    <span className="font-mono font-bold text-sm text-[#1E2D23]">
                      {formatBRL(item.valorTotvs)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-neutral-500">
                    <span>Valor ICMS escriturado:</span>
                    <span className="font-mono">{formatBRL(item.valorIcmsTotvs)}</span>
                  </div>
                </div>
              ) : (
                <div className="py-8 text-center text-[#8F3E35] text-xs">
                  <AlertOctagon className="w-8 h-8 text-[#8F3E35] mx-auto mb-2 opacity-80" />
                  <strong className="block font-bold">Documento Pendente de Entrada</strong>
                  <p className="text-[11px] text-neutral-600 mt-1">
                    Esta nota consta no Qive da Receita Federal, mas ainda não foi escriturada no ERP TOTVS da empresa.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-[#FAF8F5] border-t border-[#E2D9CE] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold rounded bg-[#1E2D23] text-[#FAF7F2] hover:bg-[#2A3F31] transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
