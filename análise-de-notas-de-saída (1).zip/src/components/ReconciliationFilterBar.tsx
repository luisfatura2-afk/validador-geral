import React from 'react';
import { Search, Filter, X, FileSpreadsheet } from 'lucide-react';
import { ReconciliationFilterState } from '../types/reconciliation';

interface ReconciliationFilterBarProps {
  filters: ReconciliationFilterState;
  onFilterChange: (newFilters: ReconciliationFilterState) => void;
  onResetFilters: () => void;
  onExportExcel: () => void;
  totalFiltered: number;
  totalItems: number;
}

export const ReconciliationFilterBar: React.FC<ReconciliationFilterBarProps> = ({
  filters,
  onFilterChange,
  onResetFilters,
  onExportExcel,
  totalFiltered,
  totalItems,
}) => {
  const hasActiveFilters =
    filters.status !== 'ALL' ||
    filters.tipoDocumento !== 'ALL' ||
    filters.termoBusca !== '' ||
    filters.manifestacao !== 'ALL';

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg p-4 shadow-xs mb-4">
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
          <input
            type="text"
            placeholder="Buscar por Fornecedor, Chave de Acesso, CNPJ ou Número da NF..."
            value={filters.termoBusca}
            onChange={(e) => onFilterChange({ ...filters, termoBusca: e.target.value })}
            className="w-full pl-9 pr-3 py-2 text-xs border border-[#E2D9CE] rounded-md focus:outline-none focus:border-[#1E2D23] bg-[#FAF8F5] text-[#1E2D23]"
          />
          {filters.termoBusca && (
            <button
              onClick={() => onFilterChange({ ...filters, termoBusca: '' })}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Dropdown Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Status Select */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-neutral-500 uppercase">Status:</span>
            <select
              value={filters.status}
              onChange={(e) => onFilterChange({ ...filters, status: e.target.value })}
              className="text-xs border border-[#E2D9CE] rounded-md px-2.5 py-1.5 bg-[#FAF8F5] text-[#1E2D23] font-medium focus:outline-none focus:border-[#1E2D23]"
            >
              <option value="ALL">Todos os Status</option>
              <option value="MATCHED">Conciliadas (Lançadas no TOTVS)</option>
              <option value="PENDING_IN_TOTVS">Falta Lançar no TOTVS</option>
              <option value="VALUE_DIVERGENCE">Divergência de Valor R$</option>
              <option value="ONLY_IN_TOTVS">Apenas no TOTVS (Ausentes Qive)</option>
              <option value="CANCELLED_SEFAZ">Canceladas na SEFAZ</option>
            </select>
          </div>

          {/* Tipo Documento */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-neutral-500 uppercase">Tipo:</span>
            <select
              value={filters.tipoDocumento}
              onChange={(e) => onFilterChange({ ...filters, tipoDocumento: e.target.value })}
              className="text-xs border border-[#E2D9CE] rounded-md px-2.5 py-1.5 bg-[#FAF8F5] text-[#1E2D23] font-medium focus:outline-none focus:border-[#1E2D23]"
            >
              <option value="ALL">Todos os Tipos</option>
              <option value="NFe">NF-e (Mercadorias)</option>
              <option value="CTe">CT-e (Transportes)</option>
              <option value="NFSe">NFS-e (Serviços)</option>
            </select>
          </div>

          {hasActiveFilters && (
            <button
              onClick={onResetFilters}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-[#8F3E35] hover:bg-[#FAF0EE] rounded border border-[#E8D0CE] font-semibold transition-colors"
              title="Limpar todos os filtros"
            >
              <X className="w-3.5 h-3.5" />
              <span>Limpar Filtros</span>
            </button>
          )}

          {/* Export Excel Button */}
          <button
            id="btn-export-reconciliation-excel"
            onClick={onExportExcel}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] uppercase tracking-wider transition-all shadow-xs shrink-0"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-[#D5BEA4]" />
            <span>Exportar Excel</span>
          </button>
        </div>
      </div>

      <div className="mt-2.5 pt-2 border-t border-[#F0EAE1] flex items-center justify-between text-[11px] text-neutral-500">
        <span>
          Exibindo <strong className="text-[#1E2D23]">{totalFiltered}</strong> de{' '}
          <strong className="text-[#1E2D23]">{totalItems}</strong> documentos analisados
        </span>
        {hasActiveFilters && (
          <span className="text-[#8C6D4C] font-semibold">Filtros ativos aplicados</span>
        )}
      </div>
    </div>
  );
};
