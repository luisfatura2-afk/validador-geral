import React from 'react';
import {
  FileSpreadsheet,
  Copy,
  Check,
  HelpCircle,
  RefreshCw,
  Instagram,
  Facebook,
  Youtube,
  ArrowRightLeft,
  FileOutput,
  BarChart3,
  Scale,
  FolderArchive,
  ShieldAlert,
  History,
  Sparkles,
  Menu,
} from 'lucide-react';

export type FiscalModule =
  | 'DASHBOARD'
  | 'SAIDA'
  | 'ENTRADA'
  | 'APURACAO'
  | 'CENTRAL_DADOS'
  | 'AUDITORIA'
  | 'HISTORICO';

interface HeaderProps {
  activeModule: FiscalModule;
  onSelectModule: (mod: FiscalModule) => void;
  periodStr: string;
  totalRecords: number;
  filteredCount: number;
  onExportExcel: () => void;
  onCopyEmail: () => void;
  onResetData: () => void;
  onOpenHelp: () => void;
  onLoadDemoData?: () => void;
  onToggleSidebar?: () => void;
  emailCopied: boolean;
  hasData: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeModule,
  onSelectModule,
  periodStr,
  totalRecords,
  filteredCount,
  onExportExcel,
  onCopyEmail,
  onResetData,
  onOpenHelp,
  onLoadDemoData,
  onToggleSidebar,
  emailCopied,
  hasData,
}) => {
  const moduleMeta = {
    DASHBOARD: {
      tag: 'Painel Estratégico',
      title: 'Dashboard Executivo & Indicadores Fiscais',
    },
    SAIDA: {
      tag: 'Notas de Saída',
      title: 'Painel de Conferência & Fechamento de Saídas (TOTVS)',
    },
    ENTRADA: {
      tag: 'Conciliação de Entradas',
      title: 'Conciliação Qive SEFAZ × TOTVS ERP',
    },
    APURACAO: {
      tag: 'Apuração Fiscal',
      title: 'Demonstrativo Consolidado: Débito (Saídas) − Crédito (Entradas)',
    },
    CENTRAL_DADOS: {
      tag: 'Repositório Unificado',
      title: 'Central de Dados (Entradas, Saídas, Devoluções, CT-e, NFS-e)',
    },
    AUDITORIA: {
      tag: 'Conformidade',
      title: 'Motor de Auditoria & Regras Fiscais Automatizadas',
    },
    HISTORICO: {
      tag: 'Audit Logs',
      title: 'Histórico de Arquivos e Lotes Importados',
    },
  }[activeModule] || {
    tag: 'Fiscal Control',
    title: 'Sistema de Gestão e Auditoria Fiscal',
  };

  return (
    <header className="sticky top-0 z-30 shadow-md">
      {/* 1. Top Announcement Bar */}
      <div className="bg-[#D5BEA4] text-[#1E2D23] px-4 sm:px-8 py-1.5 text-xs font-semibold tracking-wide border-b border-[#C2A78D]">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider">
              <Instagram className="w-3.5 h-3.5" />
              <Facebook className="w-3.5 h-3.5" />
              <Youtube className="w-3.5 h-3.5" />
            </span>
            <span className="hidden md:inline text-neutral-600">|</span>
            <span className="hidden md:inline text-[11px] tracking-wider uppercase font-medium">
              txc.com.br • Gestão Fiscal Empresarial
            </span>
          </div>

          <div className="text-center font-bold tracking-wider uppercase text-[11px] sm:text-xs">
            TXC Fiscal Control V2.0 • Arquitetura Modular & Serviços Fiscais
          </div>

          <div className="hidden sm:flex items-center gap-2 text-[11px]">
            <span className="font-semibold">Processamento 100% no Navegador</span>
          </div>
        </div>
      </div>

      {/* 2. Main Navigation Bar */}
      <div className="bg-[#1E2D23] text-[#E8DEC8] border-b border-[#2A3F31]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between py-3.5 gap-3">
            {/* TXC Brand Logo & Title */}
            <div className="flex items-center gap-3 sm:gap-4">
              {onToggleSidebar && (
                <button
                  onClick={onToggleSidebar}
                  className="p-1.5 text-[#D5BEA4] hover:text-white hover:bg-[#2A3F31] rounded-lg transition-colors sm:hidden"
                  title="Abrir navegação"
                >
                  <Menu className="w-5 h-5" />
                </button>
              )}

              <div className="flex items-center select-none">
                <span className="text-2xl sm:text-3xl font-black tracking-tighter text-[#E8DEC8] font-['Montserrat',sans-serif] pr-1">
                  TXC
                </span>
              </div>

              <div className="border-l border-[#334D3C] pl-3">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold tracking-widest text-[#D5BEA4] uppercase">
                    Fiscal Control
                  </span>
                  <span className="text-[9px] bg-[#2A3F31] text-[#D5BEA4] px-1.5 py-0.2 rounded font-mono font-medium border border-[#3A5644]">
                    {moduleMeta.tag}
                  </span>
                </div>
                <h1 className="text-base sm:text-lg font-bold tracking-tight text-[#FAF7F2] font-['Cormorant_Garamond',serif]">
                  {moduleMeta.title}
                </h1>
              </div>
            </div>

            {/* Quick Actions & Demo Loader */}
            <div className="flex items-center gap-2 flex-wrap">
              {onLoadDemoData && (
                <button
                  onClick={onLoadDemoData}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded bg-[#2A3F31] hover:bg-[#344F3D] text-[#E8DEC8] border border-[#3D5B47] transition-all shadow-xs"
                  title="Carregar dados de exemplo (Saídas TOTVS + Entradas Qive + Entradas TOTVS)"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#D5BEA4]" />
                  <span className="hidden sm:inline">Dados de Demonstração</span>
                  <span className="sm:hidden">Demo</span>
                </button>
              )}

              {activeModule === 'SAIDA' && hasData && (
                <>
                  <button
                    id="btn-copy-email-header"
                    onClick={onCopyEmail}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded bg-[#2A3F31] hover:bg-[#344F3D] text-[#E8DEC8] border border-[#3D5B47] transition-all shadow-xs"
                    title="Copiar resumo no formato padrão de e-mail"
                  >
                    {emailCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 font-bold">Copiado!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-[#D5BEA4]" />
                        <span>Copiar E-mail</span>
                      </>
                    )}
                  </button>

                  <button
                    id="btn-export-excel-header"
                    onClick={onExportExcel}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded bg-[#D5BEA4] hover:bg-[#C2A588] text-[#1E2D23] uppercase tracking-wider transition-all shadow-sm active:scale-98"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>Exportar Excel</span>
                  </button>

                  <button
                    id="btn-reset-data"
                    onClick={onResetData}
                    className="p-1.5 text-[#C2B7A3] hover:text-[#FAF7F2] hover:bg-[#2A3F31] rounded transition-colors"
                    title="Trocar arquivo CSV"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </>
              )}

              <button
                id="btn-open-help"
                onClick={onOpenHelp}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-[#D5BEA4] hover:text-white hover:bg-[#2A3F31] rounded transition-colors"
                title="Instruções de uso e conciliação"
              >
                <HelpCircle className="w-4 h-4 text-[#D5BEA4]" />
                <span className="hidden sm:inline">Ajuda</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
