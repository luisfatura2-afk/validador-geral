import React from 'react';
import { PieChart, CheckCircle2, XCircle, AlertTriangle, HelpCircle, Filter } from 'lucide-react';
import { SituationSummary } from '../types/fiscal';
import { formatBRL } from '../utils/csvParser';

interface SituationAnalysisProps {
  situationSummaries: SituationSummary[];
  totalNotes: number;
  selectedSituation: string;
  onSelectSituation: (situacao: string) => void;
}

export const SituationAnalysis: React.FC<SituationAnalysisProps> = ({
  situationSummaries,
  totalNotes,
  selectedSituation,
  onSelectSituation,
}) => {
  const getSituationTheme = (situacao: string) => {
    const s = (situacao || '').toLowerCase();
    if (s.includes('autoriz') || s.includes('emitid')) {
      return {
        bg: 'bg-[#233527]',
        text: 'text-[#233527]',
        border: 'border-[#C5DAC9]',
        lightBg: 'bg-[#F2F7F3]',
        pillBg: 'bg-[#E3EEE5]',
        barBg: 'bg-[#2E4734]',
      };
    }
    if (s.includes('cancel')) {
      return {
        bg: 'bg-[#8F3E35]',
        text: 'text-[#8F3E35]',
        border: 'border-[#E8D0CE]',
        lightBg: 'bg-[#FAF2F1]',
        pillBg: 'bg-[#F5E2E0]',
        barBg: 'bg-[#8F3E35]',
      };
    }
    if (s.includes('inutiliz') || s.includes('denegad')) {
      return {
        bg: 'bg-[#A07335]',
        text: 'text-[#845E28]',
        border: 'border-[#EADFCB]',
        lightBg: 'bg-[#FAF6EE]',
        pillBg: 'bg-[#F5ECD8]',
        barBg: 'bg-[#A07335]',
      };
    }
    return {
      bg: 'bg-[#4B5E51]',
      text: 'text-[#334D3C]',
      border: 'border-[#D5E0D8]',
      lightBg: 'bg-[#F3F6F4]',
      pillBg: 'bg-[#E5ECE7]',
      barBg: 'bg-[#4B5E51]',
    };
  };

  const getSituationIcon = (situacao: string) => {
    const s = (situacao || '').toLowerCase();
    if (s.includes('autoriz') || s.includes('emitid')) {
      return <CheckCircle2 className="w-4 h-4 text-[#233527] shrink-0" />;
    }
    if (s.includes('cancel')) {
      return <XCircle className="w-4 h-4 text-[#8F3E35] shrink-0" />;
    }
    if (s.includes('inutiliz') || s.includes('denegad')) {
      return <AlertTriangle className="w-4 h-4 text-[#A07335] shrink-0" />;
    }
    return <HelpCircle className="w-4 h-4 text-[#4B5E51] shrink-0" />;
  };

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-6">
      {/* Header */}
      <div className="px-4 sm:px-5 py-3.5 bg-[#1E2D23] text-[#FAF7F2] flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-7 h-7 rounded bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4] shrink-0">
            <PieChart className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0">
            <h2 className="text-sm font-bold uppercase tracking-wider font-['Montserrat',sans-serif] text-[#FAF7F2] truncate">
              Situação da NF
            </h2>
            <p className="text-[11px] text-[#C2B7A3] truncate">
              Distribuição por status SEFAZ
            </p>
          </div>
        </div>

        <div className="text-right shrink-0">
          <span className="text-[11px] text-[#C2B7A3]">Total: </span>
          <span className="text-xs font-bold font-mono text-[#FAF7F2]">{totalNotes.toLocaleString('pt-BR')} docs</span>
        </div>
      </div>

      <div className="p-4 sm:p-5 space-y-4">
        {/* Stacked Proportional Bar */}
        <div>
          <div className="flex items-center justify-between text-[11px] font-semibold text-[#5A5248] uppercase tracking-wider mb-1.5">
            <span>Composição Geral</span>
            <span>{situationSummaries.length} status identificados</span>
          </div>
          <div className="w-full h-3 rounded-full overflow-hidden bg-[#EAE4DC] flex shadow-inner">
            {situationSummaries.map((s) => {
              const theme = getSituationTheme(s.situacao);
              return (
                <div
                  key={s.situacao}
                  title={`${s.situacao}: ${s.count} (${s.percentage.toFixed(1)}%)`}
                  style={{ width: `${Math.max(s.percentage, 0.5)}%` }}
                  className={`${theme.barBg} transition-all duration-300 first:rounded-l-full last:rounded-r-full`}
                />
              );
            })}
          </div>
        </div>

        {/* Status List Cards */}
        <div className="space-y-2.5">
          {situationSummaries.map((s) => {
            const theme = getSituationTheme(s.situacao);
            const isSelected = selectedSituation.toLowerCase() === s.situacao.toLowerCase();

            return (
              <button
                key={s.situacao}
                type="button"
                onClick={() => onSelectSituation(isSelected ? '' : s.situacao)}
                className={`w-full text-left p-3 rounded-lg border transition-all duration-150 ${
                  isSelected
                    ? `${theme.lightBg} ${theme.border} ring-2 ring-[#1E2D23]/20 shadow-xs`
                    : 'bg-[#FAF8F5] border-[#E8DFD3] hover:border-[#C8BCAC] hover:bg-white'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    {getSituationIcon(s.situacao)}
                    <span className="font-bold text-xs text-[#1E2D23] truncate">
                      {s.situacao || 'Não informada'}
                    </span>
                    {isSelected && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-[#1E2D23] text-[#FAF7F2] px-1.5 py-0.2 rounded">
                        <Filter className="w-2.5 h-2.5" /> Ativo
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-mono font-bold text-[#1E2D23]">
                      {s.count.toLocaleString('pt-BR')} docs
                    </span>
                    <span
                      className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${theme.pillBg} ${theme.text} border ${theme.border}`}
                    >
                      {s.percentage.toFixed(1)}%
                    </span>
                  </div>
                </div>

                {/* Progress bar and valor contabil */}
                <div className="w-full bg-[#EAE4DC] rounded-full h-1.5 overflow-hidden mb-1.5">
                  <div
                    className={`h-1.5 rounded-full ${theme.barBg}`}
                    style={{ width: `${s.percentage}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-[#6B6155]">
                  <span>Valor Contábil:</span>
                  <span className="font-mono font-semibold text-[#1E2D23]">
                    {formatBRL(s.vlContabil)}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {selectedSituation && (
          <div className="pt-1 text-center">
            <button
              type="button"
              onClick={() => onSelectSituation('')}
              className="text-xs font-semibold text-[#8C6D4C] hover:text-[#1E2D23] underline decoration-dotted"
            >
              Limpar filtro de situação
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
