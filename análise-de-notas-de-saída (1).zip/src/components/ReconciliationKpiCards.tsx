import React from 'react';
import {
  FileCheck,
  Building,
  CheckCircle2,
  AlertOctagon,
  Scale,
  FileQuestion,
  XCircle,
} from 'lucide-react';
import { ReconciliationKPIs } from '../types/reconciliation';
import { formatBRL } from '../utils/reconciliationEngine';

interface ReconciliationKpiCardsProps {
  kpis: ReconciliationKPIs;
  activeStatusFilter: string;
  onSelectStatusFilter: (status: string) => void;
}

export const ReconciliationKpiCards: React.FC<ReconciliationKpiCardsProps> = ({
  kpis,
  activeStatusFilter,
  onSelectStatusFilter,
}) => {
  const percentConciliado =
    kpis.totalQiveCount > 0
      ? ((kpis.matchedCount / kpis.totalQiveCount) * 100).toFixed(1)
      : '0.0';

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3.5 mb-6">
      {/* 1. Total Qive */}
      <div
        onClick={() => onSelectStatusFilter('ALL')}
        className={`bg-white border rounded-lg p-4 cursor-pointer transition-all shadow-xs ${
          activeStatusFilter === 'ALL'
            ? 'border-[#1E2D23] ring-1 ring-[#1E2D23] bg-[#FAF8F5]'
            : 'border-[#E2D9CE] hover:border-[#8C6D4C]'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-neutral-600 uppercase tracking-wider">
            1. Total Qive (SEFAZ)
          </span>
          <div className="w-6 h-6 rounded bg-[#F0EAE1] text-[#8C6D4C] flex items-center justify-center">
            <FileCheck className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="text-2xl font-bold font-mono text-[#1E2D23] leading-none mb-1">
          {kpis.totalQiveCount.toLocaleString('pt-BR')}
        </div>
        <div className="text-xs font-mono font-semibold text-neutral-600 truncate" title={formatBRL(kpis.totalQiveValue)}>
          {formatBRL(kpis.totalQiveValue)}
        </div>
        <div className="text-[10px] text-neutral-500 mt-2 pt-2 border-t border-[#F0EAE1]">
          Documentos emitidos na SEFAZ
        </div>
      </div>

      {/* 2. Total TOTVS */}
      <div
        onClick={() => onSelectStatusFilter('ALL')}
        className={`bg-white border rounded-lg p-4 cursor-pointer transition-all shadow-xs ${
          activeStatusFilter === 'ALL'
            ? 'border-[#1E2D23] ring-1 ring-[#1E2D23] bg-[#FAF8F5]'
            : 'border-[#E2D9CE] hover:border-[#8C6D4C]'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-neutral-600 uppercase tracking-wider">
            2. Total TOTVS (ERP)
          </span>
          <div className="w-6 h-6 rounded bg-[#F0EAE1] text-[#8C6D4C] flex items-center justify-center">
            <Building className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="text-2xl font-bold font-mono text-[#1E2D23] leading-none mb-1">
          {kpis.totalTotvsCount.toLocaleString('pt-BR')}
        </div>
        <div className="text-xs font-mono font-semibold text-neutral-600 truncate" title={formatBRL(kpis.totalTotvsValue)}>
          {formatBRL(kpis.totalTotvsValue)}
        </div>
        <div className="text-[10px] text-neutral-500 mt-2 pt-2 border-t border-[#F0EAE1]">
          Linhas escrituradas no ERP
        </div>
      </div>

      {/* 3. Conciliadas (Matched) */}
      <div
        onClick={() => onSelectStatusFilter('MATCHED')}
        className={`border rounded-lg p-4 cursor-pointer transition-all shadow-xs ${
          activeStatusFilter === 'MATCHED'
            ? 'border-[#233527] ring-2 ring-[#233527] bg-[#EFF6F1]'
            : 'bg-white border-[#C5DAC9] hover:bg-[#F4F9F5]'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-[#233527] uppercase tracking-wider">
            3. Conciliadas
          </span>
          <div className="w-6 h-6 rounded bg-[#EFF6F1] text-[#233527] border border-[#C5DAC9] flex items-center justify-center">
            <CheckCircle2 className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="text-2xl font-bold font-mono text-[#233527] leading-none mb-1">
          {kpis.matchedCount.toLocaleString('pt-BR')}
        </div>
        <div className="text-xs font-mono font-bold text-[#233527] truncate" title={formatBRL(kpis.matchedValue)}>
          {formatBRL(kpis.matchedValue)}
        </div>
        <div className="text-[10px] text-[#35533F] font-semibold mt-2 pt-2 border-t border-[#C5DAC9]">
          {percentConciliado}% de aderência fiscal
        </div>
      </div>

      {/* 4. Pendentes no TOTVS (FALTA LANÇAR - CRITICAL!) */}
      <div
        onClick={() => onSelectStatusFilter('PENDING_IN_TOTVS')}
        className={`border rounded-lg p-4 cursor-pointer transition-all shadow-xs ${
          activeStatusFilter === 'PENDING_IN_TOTVS'
            ? 'border-[#8F3E35] ring-2 ring-[#8F3E35] bg-[#FAF0EE]'
            : 'bg-white border-[#E8D0CE] hover:bg-[#FCF5F4]'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-[#8F3E35] uppercase tracking-wider">
            4. Falta no TOTVS
          </span>
          <div className="w-6 h-6 rounded bg-[#FAF0EE] text-[#8F3E35] border border-[#E8D0CE] flex items-center justify-center">
            <AlertOctagon className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="text-2xl font-bold font-mono text-[#8F3E35] leading-none mb-1">
          {kpis.pendingTotvsCount.toLocaleString('pt-BR')}
        </div>
        <div className="text-xs font-mono font-bold text-[#8F3E35] truncate" title={formatBRL(kpis.pendingTotvsValue)}>
          {formatBRL(kpis.pendingTotvsValue)}
        </div>
        <div className="text-[10px] text-[#8F3E35] font-semibold mt-2 pt-2 border-t border-[#E8D0CE]">
          Recebida na SEFAZ sem entrada
        </div>
      </div>

      {/* 5. Com Divergência de Valor */}
      <div
        onClick={() => onSelectStatusFilter('VALUE_DIVERGENCE')}
        className={`border rounded-lg p-4 cursor-pointer transition-all shadow-xs ${
          activeStatusFilter === 'VALUE_DIVERGENCE'
            ? 'border-[#A07335] ring-2 ring-[#A07335] bg-[#FAF4E8]'
            : 'bg-white border-[#EADFCB] hover:bg-[#FDF9F2]'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-[#845E28] uppercase tracking-wider">
            5. Divergência R$
          </span>
          <div className="w-6 h-6 rounded bg-[#FAF4E8] text-[#845E28] border border-[#EADFCB] flex items-center justify-center">
            <Scale className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="text-2xl font-bold font-mono text-[#845E28] leading-none mb-1">
          {kpis.divergenceCount.toLocaleString('pt-BR')}
        </div>
        <div className="text-xs font-mono font-bold text-[#845E28] truncate" title={formatBRL(kpis.divergenceValueSum)}>
          Dif: {formatBRL(kpis.divergenceValueSum)}
        </div>
        <div className="text-[10px] text-[#845E28] font-medium mt-2 pt-2 border-t border-[#EADFCB]">
          Valor Qive ≠ Valor TOTVS
        </div>
      </div>

      {/* 6. Apenas no TOTVS */}
      <div
        onClick={() => onSelectStatusFilter('ONLY_IN_TOTVS')}
        className={`border rounded-lg p-4 cursor-pointer transition-all shadow-xs ${
          activeStatusFilter === 'ONLY_IN_TOTVS'
            ? 'border-[#4B5E51] ring-2 ring-[#4B5E51] bg-[#EFF3F0]'
            : 'bg-white border-[#D5E0D8] hover:bg-[#F6F8F7]'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-[#334D3C] uppercase tracking-wider">
            6. Apenas no TOTVS
          </span>
          <div className="w-6 h-6 rounded bg-[#EFF3F0] text-[#334D3C] border border-[#D5E0D8] flex items-center justify-center">
            <FileQuestion className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="text-2xl font-bold font-mono text-[#334D3C] leading-none mb-1">
          {kpis.onlyTotvsCount.toLocaleString('pt-BR')}
        </div>
        <div className="text-xs font-mono font-bold text-[#334D3C] truncate" title={formatBRL(kpis.onlyTotvsValue)}>
          {formatBRL(kpis.onlyTotvsValue)}
        </div>
        <div className="text-[10px] text-neutral-500 mt-2 pt-2 border-t border-[#D5E0D8]">
          Não constam no Qive
        </div>
      </div>
    </div>
  );
};
