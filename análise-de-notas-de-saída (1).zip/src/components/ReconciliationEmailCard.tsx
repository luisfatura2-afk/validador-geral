import React, { useState } from 'react';
import { Mail, Copy, Check, ChevronDown, ChevronUp } from 'lucide-react';
import { ReconciliationKPIs, ReconciledItem } from '../types/reconciliation';
import { generateReconciliationEmail, formatBRL } from '../utils/reconciliationEngine';

interface ReconciliationEmailCardProps {
  kpis: ReconciliationKPIs;
  items: ReconciledItem[];
}

export const ReconciliationEmailCard: React.FC<ReconciliationEmailCardProps> = ({
  kpis,
  items,
}) => {
  const [copied, setCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const pendingItems = items.filter((i) => i.status === 'PENDING_IN_TOTVS');
  const divergentItems = items.filter((i) => i.status === 'VALUE_DIVERGENCE');

  const emailText = generateReconciliationEmail(kpis, pendingItems, divergentItems);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(emailText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  };

  const percentConciliado =
    kpis.totalQiveCount > 0
      ? ((kpis.matchedCount / kpis.totalQiveCount) * 100).toFixed(1)
      : '0.0';

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-6">
      <div className="px-4 sm:px-6 py-3.5 bg-[#FAF8F5] border-b border-[#E2D9CE] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-[#1E2D23] text-[#D5BEA4] flex items-center justify-center">
            <Mail className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-[#1E2D23] uppercase tracking-wider font-['Montserrat',sans-serif]">
              Resumo Executivo para Comunicação e Fechamento
            </h3>
            <p className="text-[11px] text-neutral-500">
              Texto estruturado pronto para envio à controladoria, compras ou diretoria
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-copy-reconciliation-email"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] uppercase tracking-wider transition-all shadow-xs active:scale-98"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Copiado com Sucesso!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[#D5BEA4]" />
                <span>Copiar Resumo</span>
              </>
            )}
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 text-neutral-500 hover:text-[#1E2D23] transition-colors"
            title={isExpanded ? 'Recolher prévia' : 'Expandir prévia'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Quick Summary Pill Highlights */}
      <div className="p-4 sm:p-5 bg-white">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs mb-3">
          <div className="bg-[#FAF8F5] p-3 rounded border border-[#E2D9CE]">
            <span className="text-[10px] text-neutral-500 uppercase font-semibold">Aderência Fiscal</span>
            <p className="text-base font-bold font-mono text-[#233527] mt-0.5">{percentConciliado}%</p>
            <p className="text-[11px] text-neutral-500">{kpis.matchedCount} de {kpis.totalQiveCount} conciliadas</p>
          </div>

          <div className="bg-[#FAF0EE] p-3 rounded border border-[#E8D0CE]">
            <span className="text-[10px] text-[#8F3E35] uppercase font-semibold">Pendentes no TOTVS</span>
            <p className="text-base font-bold font-mono text-[#8F3E35] mt-0.5">{kpis.pendingTotvsCount} notas</p>
            <p className="text-[11px] text-[#8F3E35] font-semibold">{formatBRL(kpis.pendingTotvsValue)}</p>
          </div>

          <div className="bg-[#FAF4E8] p-3 rounded border border-[#EADFCB]">
            <span className="text-[10px] text-[#845E28] uppercase font-semibold">Divergências de Valor</span>
            <p className="text-base font-bold font-mono text-[#845E28] mt-0.5">{kpis.divergenceCount} notas</p>
            <p className="text-[11px] text-[#845E28] font-semibold">Dif: {formatBRL(kpis.divergenceValueSum)}</p>
          </div>

          <div className="bg-[#EFF3F0] p-3 rounded border border-[#D5E0D8]">
            <span className="text-[10px] text-[#334D3C] uppercase font-semibold">Canceladas na SEFAZ</span>
            <p className="text-base font-bold font-mono text-[#334D3C] mt-0.5">{kpis.cancelledCount} notas</p>
            <p className="text-[11px] text-[#334D3C]">{formatBRL(kpis.cancelledValue)}</p>
          </div>
        </div>

        {/* Expandable Preview */}
        {isExpanded && (
          <div className="mt-3 pt-3 border-t border-[#E2D9CE]">
            <span className="text-[11px] font-bold text-neutral-600 uppercase tracking-wider block mb-1.5">
              Pré-visualização do texto formatado:
            </span>
            <pre className="p-3 bg-[#FAF8F5] border border-[#E2D9CE] rounded text-[11px] font-mono text-neutral-800 whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto">
              {emailText}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
