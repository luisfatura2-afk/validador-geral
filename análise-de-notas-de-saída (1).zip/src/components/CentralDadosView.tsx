import React, { useState, useMemo } from 'react';
import {
  UnifiedFiscalDocument,
  FiscalDocumentType,
  CentralDadosFilterState,
} from '../types/centralDados';
import { notasService } from '../services/notasService';
import {
  FolderArchive,
  Search,
  Filter,
  FileSpreadsheet,
  ArrowDownLeft,
  ArrowUpRight,
  RotateCcw,
  Truck,
  Building2,
  Copy,
  Check,
  ExternalLink,
  AlertTriangle,
} from 'lucide-react';
import { EmptyState } from './common/EmptyState';
import { AlertBadge } from './common/AlertBadge';

interface CentralDadosViewProps {
  documents: UnifiedFiscalDocument[];
  onSelectDocument?: (doc: UnifiedFiscalDocument) => void;
  onLoadDemoData: () => void;
  onNavigateToModule: (module: 'SAIDA' | 'ENTRADA') => void;
}

export const CentralDadosView: React.FC<CentralDadosViewProps> = ({
  documents,
  onSelectDocument,
  onLoadDemoData,
  onNavigateToModule,
}) => {
  const [filters, setFilters] = useState<CentralDadosFilterState>({
    category: 'ALL',
    origem: 'ALL',
    busca: '',
    dataInicio: '',
    dataFim: '',
    cfop: '',
    apenasInconsistentes: false,
  });

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Filtered documents
  const filteredDocuments = useMemo(() => {
    return notasService.filterCentralData(documents, filters);
  }, [documents, filters]);

  // Counts by category
  const categoryCounts = useMemo(() => {
    const counts: Record<FiscalDocumentType | 'ALL', { count: number; totalValor: number }> = {
      ALL: { count: documents.length, totalValor: 0 },
      ENTRADA: { count: 0, totalValor: 0 },
      SAIDA: { count: 0, totalValor: 0 },
      DEVOLUCAO: { count: 0, totalValor: 0 },
      CTE: { count: 0, totalValor: 0 },
      SERVICO: { count: 0, totalValor: 0 },
    };

    documents.forEach((d) => {
      counts.ALL.totalValor += d.valorContabil;
      if (counts[d.category]) {
        counts[d.category].count += 1;
        counts[d.category].totalValor += d.valorContabil;
      }
    });

    return counts;
  }, [documents]);

  const formatBRL = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const handleCopyKey = (key: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(key);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleExportCSV = () => {
    if (filteredDocuments.length === 0) return;
    const header = [
      'Categoria',
      'Origem',
      'Número',
      'Série',
      'Emissão',
      'Pessoa/Entidade',
      'CNPJ/CPF',
      'CFOP',
      'Valor Contábil',
      'ICMS',
      'PIS',
      'COFINS',
      'IPI',
      'Chave de Acesso',
      'Situação SEFAZ',
    ];
    const rows = filteredDocuments.map((d) => [
      d.category,
      d.origemFonte,
      d.numero,
      d.serie,
      d.dataEmissao,
      `"${d.emitenteOuDestinatario.replace(/"/g, '""')}"`,
      d.documentoPessoa,
      d.cfopPrincipal,
      d.valorContabil.toFixed(2),
      d.valorIcms.toFixed(2),
      d.valorPis.toFixed(2),
      d.valorCofins.toFixed(2),
      d.valorIpi.toFixed(2),
      d.chaveAcesso,
      d.situacaoSefaz,
    ]);

    const csvContent =
      '\uFEFF' + [header.join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `central_dados_fiscais_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const categoriesConfig: {
    key: FiscalDocumentType | 'ALL';
    label: string;
    icon: React.ElementType;
    desc: string;
  }[] = [
    { key: 'ALL', label: 'Todos os Documentos', icon: FolderArchive, desc: 'Repositório consolidado' },
    { key: 'ENTRADA', label: 'Notas de Entrada', icon: ArrowDownLeft, desc: 'Aquisições e compras' },
    { key: 'SAIDA', label: 'Notas de Saída', icon: ArrowUpRight, desc: 'Vendas e faturamento' },
    { key: 'DEVOLUCAO', label: 'Devoluções', icon: RotateCcw, desc: 'Operações de retorno' },
    { key: 'CTE', label: 'CT-e Transporte', icon: Truck, desc: 'Fretes e conhecimentos' },
    { key: 'SERVICO', label: 'Notas de Serviço', icon: Building2, desc: 'NFS-e e tomados' },
  ];

  if (documents.length === 0) {
    return (
      <div className="space-y-6">
        <div className="bg-white border border-[#E2D9CE] rounded-xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-[#1E2D23] font-['Montserrat',sans-serif] flex items-center gap-2">
              <FolderArchive className="w-5 h-5 text-[#8C6D4C]" />
              Central Unificada de Dados Fiscais
            </h2>
            <p className="text-xs text-neutral-500 mt-1">
              Repositório estruturado para armazenamento e consulta de Entradas, Saídas, Devoluções, CT-e e Serviços.
            </p>
          </div>
        </div>

        <EmptyState
          title="Nenhum documento carregado na Central"
          description="Importe arquivos de Saída (TOTVS) ou Entradas (Qive SEFAZ / TOTVS) para popular automaticamente o repositório fiscal unificado."
          icon={FolderArchive}
          actionButton={
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={onLoadDemoData}
                className="px-4 py-2 bg-[#D5BEA4] hover:bg-[#C2A588] text-[#1E2D23] text-xs font-bold uppercase tracking-wider rounded-lg transition-all shadow-sm"
              >
                Carregar Arquivos de Demonstração
              </button>
              <button
                onClick={() => onNavigateToModule('SAIDA')}
                className="px-4 py-2 bg-[#1E2D23] hover:bg-[#2A3F31] text-[#FAF7F2] text-xs font-bold uppercase tracking-wider rounded-lg transition-all"
              >
                Importar Notas de Saída
              </button>
            </div>
          }
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-white border border-[#E2D9CE] rounded-xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E2D9CE]">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#1E2D23] font-['Montserrat',sans-serif] flex items-center gap-2">
                <FolderArchive className="w-5 h-5 text-[#8C6D4C]" />
                Central Unificada de Dados Fiscais
              </h2>
              <span className="text-[10px] bg-[#FAF3EA] text-[#8C6D4C] border border-[#E8DCCB] font-bold px-2 py-0.5 rounded uppercase">
                {documents.length} registros
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              Visão consolidada multi-documento preparada para transição futura Front → API → Banco de Dados.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#D5BEA4] hover:bg-[#C2A588] text-[#1E2D23] text-xs font-bold uppercase tracking-wider rounded-lg transition-all shadow-sm"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Exportar Dados ({filteredDocuments.length})</span>
            </button>
          </div>
        </div>

        {/* Category Cards / Selectors */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-4">
          {categoriesConfig.map((cat) => {
            const isSelected = filters.category === cat.key;
            const Icon = cat.icon;
            const data = categoryCounts[cat.key];

            return (
              <button
                key={cat.key}
                onClick={() => setFilters((prev) => ({ ...prev, category: cat.key }))}
                className={`p-3 rounded-lg border text-left transition-all ${
                  isSelected
                    ? 'bg-[#1E2D23] text-[#FAF7F2] border-[#1E2D23] shadow-xs'
                    : 'bg-[#FAF8F5] hover:bg-white text-neutral-700 border-[#E2D9CE]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <Icon
                    className={`w-4 h-4 ${
                      isSelected ? 'text-[#D5BEA4]' : 'text-neutral-500'
                    }`}
                  />
                  <span
                    className={`text-[10px] font-bold font-mono px-1.5 py-0.2 rounded ${
                      isSelected ? 'bg-[#2A3F31] text-[#D5BEA4]' : 'bg-neutral-200 text-neutral-700'
                    }`}
                  >
                    {data.count}
                  </span>
                </div>
                <div
                  className={`text-xs font-bold truncate ${
                    isSelected ? 'text-[#FAF7F2]' : 'text-[#1E2D23]'
                  }`}
                >
                  {cat.label}
                </div>
                <div
                  className={`text-[11px] font-mono mt-1 truncate ${
                    isSelected ? 'text-[#D5BEA4]' : 'text-neutral-500'
                  }`}
                >
                  {formatBRL(data.totalValor)}
                </div>
              </button>
            );
          })}
        </div>

        {/* Filter Bar */}
        <div className="mt-4 pt-4 border-t border-[#E2D9CE] grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              placeholder="Buscar por número, chave de 44 dígitos, emitente ou CNPJ..."
              value={filters.busca}
              onChange={(e) => setFilters((prev) => ({ ...prev, busca: e.target.value }))}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-[#E2D9CE] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#8C6D4C] bg-[#FAF8F5]"
            />
          </div>

          <div className="sm:col-span-3">
            <select
              value={filters.origem}
              onChange={(e) =>
                setFilters((prev) => ({
                  ...prev,
                  origem: e.target.value as CentralDadosFilterState['origem'],
                }))
              }
              className="w-full py-1.5 px-3 text-xs border border-[#E2D9CE] rounded-lg bg-[#FAF8F5] focus:outline-none"
            >
              <option value="ALL">Todas as Origens (TOTVS & Qive)</option>
              <option value="TOTVS">Apenas TOTVS ERP</option>
              <option value="QIVE_SEFAZ">Apenas Qive SEFAZ</option>
            </select>
          </div>

          <div className="sm:col-span-3 flex items-center justify-between sm:justify-end gap-3">
            <label className="flex items-center gap-1.5 text-xs text-neutral-700 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={filters.apenasInconsistentes}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, apenasInconsistentes: e.target.checked }))
                }
                className="rounded border-[#E2D9CE] text-[#8C6D4C] focus:ring-0"
              />
              <span className="font-semibold text-rose-700">Apenas com Alertas</span>
            </label>

            {(filters.busca || filters.origem !== 'ALL' || filters.category !== 'ALL' || filters.apenasInconsistentes) && (
              <button
                onClick={() =>
                  setFilters({
                    category: 'ALL',
                    origem: 'ALL',
                    busca: '',
                    dataInicio: '',
                    dataFim: '',
                    cfop: '',
                    apenasInconsistentes: false,
                  })
                }
                className="text-[11px] text-[#8C6D4C] hover:underline font-bold"
              >
                Limpar
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-[#E2D9CE] rounded-xl overflow-hidden shadow-xs">
        <div className="px-5 py-3 bg-[#FAF8F5] border-b border-[#E2D9CE] flex items-center justify-between text-xs text-neutral-600">
          <span className="font-bold text-[#1E2D23]">
            Exibindo {filteredDocuments.length} de {documents.length} documentos encontrados
          </span>
          <span className="text-[11px] font-mono">
            Valor acumulado filtrado:{' '}
            <strong className="text-[#1E2D23]">
              {formatBRL(filteredDocuments.reduce((a, b) => a + b.valorContabil, 0))}
            </strong>
          </span>
        </div>

        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-[#1E2D23] text-[#FAF7F2] sticky top-0 z-10 font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Tipo / Origem</th>
                <th className="py-2.5 px-3">Número / Série</th>
                <th className="py-2.5 px-3">Emissão</th>
                <th className="py-2.5 px-3">Pessoa / Razão Social</th>
                <th className="py-2.5 px-3">CFOP</th>
                <th className="py-2.5 px-3 text-right">Valor Contábil</th>
                <th className="py-2.5 px-3 text-right">ICMS</th>
                <th className="py-2.5 px-3 text-right">PIS/COFINS</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-3 text-center">Chave</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E2D9CE]/60 font-sans">
              {filteredDocuments.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-neutral-500">
                    Nenhum documento encontrado com os filtros selecionados.
                  </td>
                </tr>
              ) : (
                filteredDocuments.map((doc) => {
                  const categoryBadgeColor = {
                    ENTRADA: 'bg-emerald-50 text-emerald-800 border-emerald-200',
                    SAIDA: 'bg-sky-50 text-sky-800 border-sky-200',
                    DEVOLUCAO: 'bg-amber-50 text-amber-900 border-amber-200',
                    CTE: 'bg-purple-50 text-purple-900 border-purple-200',
                    SERVICO: 'bg-indigo-50 text-indigo-900 border-indigo-200',
                  }[doc.category];

                  return (
                    <tr
                      key={doc.id}
                      onClick={() => onSelectDocument && onSelectDocument(doc)}
                      className="hover:bg-[#FAF8F5] transition-colors cursor-pointer"
                    >
                      <td className="py-2.5 px-3">
                        <div className="flex flex-col gap-0.5">
                          <span
                            className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold border uppercase w-fit ${categoryBadgeColor}`}
                          >
                            {doc.category}
                          </span>
                          <span className="text-[10px] text-neutral-400 font-mono">
                            {doc.origemFonte}
                          </span>
                        </div>
                      </td>

                      <td className="py-2.5 px-3">
                        <div className="font-bold text-[#1E2D23] font-mono">
                          {doc.numero || 'S/N'}
                        </div>
                        <div className="text-[10px] text-neutral-500">
                          Série: {doc.serie || '0'}
                        </div>
                      </td>

                      <td className="py-2.5 px-3 font-mono text-neutral-600">
                        {doc.dataEmissao || '—'}
                      </td>

                      <td className="py-2.5 px-3 max-w-xs truncate">
                        <div className="font-bold text-[#1E2D23] truncate" title={doc.emitenteOuDestinatario}>
                          {doc.emitenteOuDestinatario || 'Não informada'}
                        </div>
                        <div className="text-[10px] text-neutral-500 font-mono">
                          {doc.documentoPessoa || 'Sem CNPJ'}
                        </div>
                      </td>

                      <td className="py-2.5 px-3">
                        <span className="font-mono bg-neutral-100 text-neutral-800 px-1.5 py-0.5 rounded text-[11px] font-bold">
                          {doc.cfopPrincipal || '—'}
                        </span>
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono font-bold text-[#1E2D23]">
                        {formatBRL(doc.valorContabil)}
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono text-neutral-700">
                        {formatBRL(doc.valorIcms)}
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono text-neutral-700">
                        {formatBRL(doc.valorPis + doc.valorCofins)}
                      </td>

                      <td className="py-2.5 px-3 text-center">
                        {doc.temInconsistencia ? (
                          <AlertBadge severity="ATENCAO" label="Alerta" size="sm" />
                        ) : (
                          <AlertBadge severity="OK" label="OK" size="sm" />
                        )}
                      </td>

                      <td className="py-2.5 px-3 text-center">
                        {doc.chaveAcesso ? (
                          <button
                            onClick={(e) => handleCopyKey(doc.chaveAcesso, e)}
                            className="p-1 hover:bg-neutral-200 rounded text-neutral-500 transition-colors"
                            title={`Copiar Chave: ${doc.chaveAcesso}`}
                          >
                            {copiedKey === doc.chaveAcesso ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        ) : (
                          <span className="text-neutral-300">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
