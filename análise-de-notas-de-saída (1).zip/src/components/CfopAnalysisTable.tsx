import React, { useState, useMemo } from 'react';
import { Layers, ArrowUpDown, ArrowUp, ArrowDown, X } from 'lucide-react';
import { CfopSummary } from '../types/fiscal';
import { formatBRL } from '../utils/csvParser';

interface CfopAnalysisTableProps {
  cfopSummaries: CfopSummary[];
  selectedCfop: string;
  onSelectCfop: (cfop: string) => void;
}

type SortField = 'cfop' | 'count' | 'vlContabil' | 'vlIcms' | 'vlPis' | 'vlCofins' | 'vlIbs' | 'vlCbs';
type SortOrder = 'asc' | 'desc';

const CFOP_DESCRIPTIONS: Record<string, string> = {
  '5101': 'Venda de produção própria (estadual)',
  '5102': 'Venda de mercadoria adquirida (estadual)',
  '5405': 'Venda com ICMS retido por ST (estadual)',
  '6101': 'Venda de produção própria (interestadual)',
  '6102': 'Venda de mercadoria adquirida (interestadual)',
  '6108': 'Venda a consumidor final não contribuinte',
  '5202': 'Devolução de compra para comercialização',
  '6202': 'Devolução de compra para comercialização',
  '5949': 'Outra saída de mercadoria ou prestação de serviço',
  '6949': 'Outra saída de mercadoria interestadual',
  '5910': 'Remessa em bonificação, doação ou brinde',
  '5915': 'Remessa para conserto ou reparo',
};

export const CfopAnalysisTable: React.FC<CfopAnalysisTableProps> = ({
  cfopSummaries,
  selectedCfop,
  onSelectCfop,
}) => {
  const [sortField, setSortField] = useState<SortField>('count');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const sortedSummaries = useMemo(() => {
    return [...cfopSummaries].sort((a, b) => {
      let aVal: number | string = a[sortField];
      let bVal: number | string = b[sortField];

      if (typeof aVal === 'string') {
        return sortOrder === 'asc'
          ? (aVal as string).localeCompare(bVal as string)
          : (bVal as string).localeCompare(aVal as string);
      }

      return sortOrder === 'asc' ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
    });
  }, [cfopSummaries, sortField, sortOrder]);

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3 h-3 text-neutral-400 opacity-60 group-hover:opacity-100" />;
    }
    return sortOrder === 'asc' ? (
      <ArrowUp className="w-3 h-3 text-[#1E2D23]" />
    ) : (
      <ArrowDown className="w-3 h-3 text-[#1E2D23]" />
    );
  };

  return (
    <div className="bg-white border border-[#E2D9CE] rounded-lg shadow-xs overflow-hidden mb-6">
      <div className="px-4 sm:px-6 py-3.5 bg-[#1E2D23] text-[#FAF7F2] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-[#2A3F31] border border-[#3D5B47] flex items-center justify-center text-[#D5BEA4]">
            <Layers className="w-3.5 h-3.5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider font-['Montserrat',sans-serif] text-[#FAF7F2]">
              Análise por CFOP (Código Fiscal de Operações)
            </h2>
            <p className="text-[11px] text-[#C2B7A3]">
              Clique em uma linha para filtrar instantaneamente as notas daquele CFOP
            </p>
          </div>
        </div>

        {selectedCfop && (
          <button
            onClick={() => onSelectCfop('')}
            className="inline-flex items-center gap-1.5 text-xs bg-[#2A3F31] hover:bg-[#344F3D] text-[#FAF7F2] px-3 py-1 rounded border border-[#3D5B47] transition-colors"
          >
            <span>Filtrando CFOP: <strong className="text-[#D5BEA4]">{selectedCfop}</strong></span>
            <X className="w-3.5 h-3.5 ml-1 text-[#D5BEA4]" />
          </button>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-[#FAF8F5] border-b border-[#E2D9CE] text-[#1E2D23] font-semibold uppercase tracking-wider text-[11px]">
            <tr>
              <th
                onClick={() => handleSort('cfop')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>CFOP</span>
                  {renderSortIcon('cfop')}
                </div>
              </th>
              <th
                onClick={() => handleSort('count')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Qtd. Notas</span>
                  {renderSortIcon('count')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlContabil')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Valor Contábil</span>
                  {renderSortIcon('vlContabil')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlIcms')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>ICMS</span>
                  {renderSortIcon('vlIcms')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlPis')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>PIS</span>
                  {renderSortIcon('vlPis')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlCofins')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>COFINS</span>
                  {renderSortIcon('vlCofins')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlIbs')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>IBS</span>
                  {renderSortIcon('vlIbs')}
                </div>
              </th>
              <th
                onClick={() => handleSort('vlCbs')}
                className="py-3 px-4 cursor-pointer hover:bg-[#F0EAE1] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>CBS</span>
                  {renderSortIcon('vlCbs')}
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E2D9CE] bg-white">
            {sortedSummaries.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-neutral-500">
                  Nenhum registro encontrado para os filtros atuais.
                </td>
              </tr>
            ) : (
              sortedSummaries.map((row) => {
                const isSelected = selectedCfop === row.cfop;
                const desc = CFOP_DESCRIPTIONS[row.cfop];

                return (
                  <tr
                    key={row.cfop || 'empty'}
                    onClick={() => onSelectCfop(isSelected ? '' : row.cfop)}
                    className={`cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-[#F7F3EB] text-[#1E2D23] font-semibold'
                        : 'hover:bg-[#FAF8F5] text-neutral-700'
                    }`}
                  >
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                            isSelected
                              ? 'bg-[#1E2D23] text-[#D5BEA4]'
                              : 'bg-[#F3EFE9] text-[#1E2D23] border border-[#E2D9CE]'
                          }`}
                        >
                          {row.cfop || 'Sem CFOP'}
                        </span>
                        {desc && (
                          <span className="text-[11px] text-neutral-500 hidden md:inline truncate max-w-xs">
                            {desc}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right font-semibold text-[#1E2D23] font-mono">
                      {row.count.toLocaleString('pt-BR')}
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-[#1E2D23] font-mono">
                      {formatBRL(row.vlContabil)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-neutral-800">
                      {formatBRL(row.vlIcms)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-neutral-800">
                      {formatBRL(row.vlPis)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-neutral-800">
                      {formatBRL(row.vlCofins)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-neutral-800">
                      {formatBRL(row.vlIbs)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-neutral-800">
                      {formatBRL(row.vlCbs)}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
