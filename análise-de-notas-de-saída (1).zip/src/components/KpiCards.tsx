import React from 'react';
import { Files, CheckCircle, XCircle, AlertTriangle, HelpCircle } from 'lucide-react';
import { formatBRL } from '../utils/csvParser';

interface KpiCardsProps {
  totalCount: number;
  authorizedCount: number;
  authorizedValue: number;
  canceledCount: number;
  canceledValue: number;
  inutilizedCount: number;
  otherCount: number;
  otherValue: number;
  totalValue: number;
  selectedSituationFilter: string;
  onSelectSituation: (sit: string) => void;
}

export const KpiCards: React.FC<KpiCardsProps> = ({
  totalCount,
  authorizedCount,
  authorizedValue,
  canceledCount,
  inutilizedCount,
  otherCount,
  totalValue,
  selectedSituationFilter,
  onSelectSituation,
}) => {
  const getPercent = (count: number) => {
    if (totalCount === 0) return '0%';
    return `${((count / totalCount) * 100).toFixed(1)}%`;
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 mb-6">
      {/* 1. Total de Notas */}
      <div
        id="kpi-total-notas"
        onClick={() => onSelectSituation('')}
        className={`bg-white border rounded-lg p-4 shadow-xs cursor-pointer transition-all hover:border-[#1E2D23] ${
          selectedSituationFilter === '' ? 'border-[#1E2D23] ring-1 ring-[#1E2D23]' : 'border-[#E2D9CE]'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider">
            Total de Notas
          </span>
          <div className="w-8 h-8 rounded bg-[#F3EFE9] flex items-center justify-center text-[#1E2D23]">
            <Files className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2">
          <span className="text-2xl sm:text-3xl font-black text-[#1E2D23] tracking-tight font-['Montserrat',sans-serif]">
            {totalCount.toLocaleString('pt-BR')}
          </span>
          <span className="ml-2 text-xs font-semibold text-neutral-500">docs</span>
        </div>
        <div className="mt-2 pt-2 border-t border-[#F0EAE1] flex items-center justify-between text-xs">
          <span className="text-neutral-500">Valor contábil total:</span>
          <span className="font-bold text-[#1E2D23] font-mono">{formatBRL(totalValue)}</span>
        </div>
      </div>

      {/* 2. Notas Autorizadas */}
      <div
        id="kpi-notas-autorizadas"
        onClick={() => onSelectSituation('Autorizada')}
        className={`bg-white border rounded-lg p-4 shadow-xs cursor-pointer transition-all hover:border-[#233527] ${
          selectedSituationFilter.toLowerCase().includes('autoriz')
            ? 'border-[#233527] ring-1 ring-[#233527]'
            : 'border-[#E2D9CE]'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#1E3A2B] uppercase tracking-wider">
            Notas Autorizadas
          </span>
          <div className="w-8 h-8 rounded bg-[#EBF3EE] flex items-center justify-center text-[#233527]">
            <CheckCircle className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-black text-[#233527] tracking-tight font-['Montserrat',sans-serif]">
            {authorizedCount.toLocaleString('pt-BR')}
          </span>
          <span className="text-xs font-bold text-[#233527] bg-[#EBF3EE] px-1.5 py-0.5 rounded">
            {getPercent(authorizedCount)}
          </span>
        </div>
        <div className="mt-2 pt-2 border-t border-[#F0EAE1] flex items-center justify-between text-xs">
          <span className="text-neutral-500">Total autorizado:</span>
          <span className="font-bold text-[#233527] font-mono">{formatBRL(authorizedValue)}</span>
        </div>
      </div>

      {/* 3. Notas Canceladas */}
      <div
        id="kpi-notas-canceladas"
        onClick={() => onSelectSituation('Cancelada')}
        className={`bg-white border rounded-lg p-4 shadow-xs cursor-pointer transition-all hover:border-[#8F3E35] ${
          selectedSituationFilter.toLowerCase().includes('cancel')
            ? 'border-[#8F3E35] ring-1 ring-[#8F3E35]'
            : 'border-[#E2D9CE]'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#8F3E35] uppercase tracking-wider">
            Notas Canceladas
          </span>
          <div className="w-8 h-8 rounded bg-[#FAF0EE] flex items-center justify-center text-[#8F3E35]">
            <XCircle className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-black text-[#8F3E35] tracking-tight font-['Montserrat',sans-serif]">
            {canceledCount.toLocaleString('pt-BR')}
          </span>
          <span className="text-xs font-bold text-[#8F3E35] bg-[#FAF0EE] px-1.5 py-0.5 rounded">
            {getPercent(canceledCount)}
          </span>
        </div>
        <div className="mt-2 pt-2 border-t border-[#F0EAE1] flex items-center justify-between text-xs">
          <span className="text-neutral-500">Status fiscal:</span>
          <span className="font-semibold text-[#8F3E35]">Cancelamento SEFAZ</span>
        </div>
      </div>

      {/* 4. Notas Inutilizadas */}
      <div
        id="kpi-notas-inutilizadas"
        onClick={() => onSelectSituation('Inutilizada')}
        className={`bg-white border rounded-lg p-4 shadow-xs cursor-pointer transition-all hover:border-[#A07335] ${
          selectedSituationFilter.toLowerCase().includes('inutiliz')
            ? 'border-[#A07335] ring-1 ring-[#A07335]'
            : 'border-[#E2D9CE]'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#845E28] uppercase tracking-wider">
            Notas Inutilizadas
          </span>
          <div className="w-8 h-8 rounded bg-[#FAF4E8] flex items-center justify-center text-[#A07335]">
            <AlertTriangle className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-black text-[#845E28] tracking-tight font-['Montserrat',sans-serif]">
            {inutilizedCount.toLocaleString('pt-BR')}
          </span>
          <span className="text-xs font-bold text-[#845E28] bg-[#FAF4E8] px-1.5 py-0.5 rounded">
            {getPercent(inutilizedCount)}
          </span>
        </div>
        <div className="mt-2 pt-2 border-t border-[#F0EAE1] flex items-center justify-between text-xs">
          <span className="text-neutral-500">Numeração:</span>
          <span className="font-semibold text-[#845E28]">Quebra de sequência</span>
        </div>
      </div>

      {/* 5. Outras Situações */}
      <div
        id="kpi-outras-situacoes"
        onClick={() => onSelectSituation('Outras')}
        className={`bg-white border rounded-lg p-4 shadow-xs cursor-pointer transition-all hover:border-[#4B5E51] ${
          selectedSituationFilter.toLowerCase() === 'outras'
            ? 'border-[#4B5E51] ring-1 ring-[#4B5E51]'
            : 'border-[#E2D9CE]'
        }`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-neutral-600 uppercase tracking-wider">
            Outras Situações
          </span>
          <div className="w-8 h-8 rounded bg-[#F3EFE9] flex items-center justify-center text-neutral-600">
            <HelpCircle className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-black text-neutral-700 tracking-tight font-['Montserrat',sans-serif]">
            {otherCount.toLocaleString('pt-BR')}
          </span>
          <span className="text-xs font-bold text-neutral-600 bg-[#F3EFE9] px-1.5 py-0.5 rounded">
            {getPercent(otherCount)}
          </span>
        </div>
        <div className="mt-2 pt-2 border-t border-[#F0EAE1] flex items-center justify-between text-xs">
          <span className="text-neutral-500">Denegadas/Outras:</span>
          <span className="font-semibold text-neutral-700">Verificar detalhes</span>
        </div>
      </div>
    </div>
  );
};
