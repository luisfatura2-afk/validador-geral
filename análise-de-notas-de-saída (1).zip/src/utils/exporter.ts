import * as XLSX from 'xlsx';
import { InvoiceRecord, CfopSummary, SituationSummary, TaxTotals } from '../types/fiscal';
import { formatBRL, formatDecimalBR } from './csvParser';

export function generateEmailSummary(
  minDateFormatted: string,
  maxDateFormatted: string,
  totalNotes: number,
  authorizedCount: number,
  authorizedTotalValue: number,
  canceledCount: number,
  inutilizedCount: number,
  otherCount: number
): string {
  return `Bom dia,

Segue em anexo a planilha atualizada contendo a análise das notas fiscais referente ao período de ${minDateFormatted} a ${maxDateFormatted}.

Resumo da análise:
- Lançadas no sistema: Não disponível neste arquivo
- Não lançadas (pendentes): Não disponível neste arquivo
- Lançadas indevidamente: Não disponível neste arquivo
- Total geral: ${totalNotes} notas fiscais
- Notas autorizadas: ${authorizedCount} (${formatBRL(authorizedTotalValue)})
- Notas canceladas: ${canceledCount}
- Notas inutilizadas: ${inutilizedCount}
- Outras situações: ${otherCount}

Atenciosamente,
Departamento Fiscal / Fiscal Control`;
}

export function exportAnalysisToExcel(
  records: InvoiceRecord[],
  cfopSummaries: CfopSummary[],
  situationSummaries: SituationSummary[],
  taxTotals: TaxTotals,
  periodStr: string
) {
  const wb = XLSX.utils.book_new();

  // 1. Resumo Sheet
  const resumoData = [
    ['ANÁLISE DE NOTAS DE SAÍDA - FISCAL CONTROL'],
    ['Período analisado', periodStr],
    ['Data da exportação', new Date().toLocaleDateString('pt-BR')],
    [''],
    ['INDICADORES GERAIS'],
    ['Total de notas', records.length],
    ['Notas autorizadas', situationSummaries.find(s => s.situacao.toLowerCase().includes('autoriz'))?.count || 0],
    ['Notas canceladas', situationSummaries.find(s => s.situacao.toLowerCase().includes('cancel'))?.count || 0],
    ['Notas inutilizadas', situationSummaries.find(s => s.situacao.toLowerCase().includes('inutiliz'))?.count || 0],
    ['Outras situações', situationSummaries.filter(s => 
      !s.situacao.toLowerCase().includes('autoriz') && 
      !s.situacao.toLowerCase().includes('cancel') && 
      !s.situacao.toLowerCase().includes('inutiliz')
    ).reduce((acc, curr) => acc + curr.count, 0)],
    [''],
    ['TOTAIS TRIBUTÁRIOS IDENTIFICADOS'],
    ['ICMS', taxTotals.icms],
    ['Base de ICMS', taxTotals.baseIcms],
    ['ICMS Isento', taxTotals.isentoIcms],
    ['Outros valores de ICMS', taxTotals.outroIcms],
    ['ICMS ST', taxTotals.icmsSt],
    ['IPI', taxTotals.ipi],
    ['PIS', taxTotals.pis],
    ['COFINS', taxTotals.cofins],
    ['FCP', taxTotals.fcp],
    ['FCP ST', taxTotals.fcpSt],
    ['IBS (Reforma)', taxTotals.ibs],
    ['CBS (Reforma)', taxTotals.cbs],
    ['IS (Reforma)', taxTotals.is],
  ];
  const wsResumo = XLSX.utils.aoa_to_sheet(resumoData);
  XLSX.utils.book_append_sheet(wb, wsResumo, 'Resumo Geral');

  // 2. CFOP Sheet
  const cfopData = [
    ['CFOP', 'Qtd Notas', 'Valor Contábil (R$)', 'ICMS (R$)', 'PIS (R$)', 'COFINS (R$)', 'IBS (R$)', 'CBS (R$)'],
    ...cfopSummaries.map((c) => [
      c.cfop || 'Sem CFOP',
      c.count,
      c.vlContabil,
      c.vlIcms,
      c.vlPis,
      c.vlCofins,
      c.vlIbs,
      c.vlCbs,
    ]),
  ];
  const wsCfop = XLSX.utils.aoa_to_sheet(cfopData);
  XLSX.utils.book_append_sheet(wb, wsCfop, 'Análise por CFOP');

  // 3. Situação Sheet
  const sitData = [
    ['Situação', 'Quantidade', 'Percentual (%)', 'Valor Contábil (R$)'],
    ...situationSummaries.map((s) => [
      s.situacao || 'Não informada',
      s.count,
      Number(s.percentage.toFixed(2)),
      s.vlContabil,
    ]),
  ];
  const wsSit = XLSX.utils.aoa_to_sheet(sitData);
  XLSX.utils.book_append_sheet(wb, wsSit, 'Análise por Situação');

  // 4. Detailed Invoices Sheet
  const invoicesData = [
    [
      'Empresa',
      'Situação',
      'Dt. Emissão',
      'Dt. Saída/Entrada',
      'Espécie',
      'Nota Fiscal',
      'Série',
      'Cód. Pessoa',
      'Nome Pessoa',
      'CFOP',
      'Valor Contábil',
      'Alíq. ICMS',
      'Base ICMS',
      'Valor ICMS',
      'ICMS Isento',
      'Outro ICMS',
      'IPI',
      'ICMS ST',
      'PIS',
      'COFINS',
      'FCP',
      'FCP ST',
      'IBS',
      'CBS',
      'IS',
      'Chave de Acesso',
    ],
    ...records.map((r) => [
      r.empresa,
      r.situacao,
      r.dtEmissao,
      r.dtSaidaEntrada,
      r.especie,
      r.notaFiscal,
      r.serie,
      r.cdPessoa,
      r.nomePessoa,
      r.cfop,
      r.vlContabil,
      r.aliqIcms,
      r.vlBaseIcms,
      r.vlIcms,
      r.vlIsentoIcms,
      r.vlOutroIcms,
      r.vlIpi,
      r.vlIcmsSt,
      r.vlPis,
      r.vlCofins,
      r.vlFcp,
      r.vlFcpSt,
      r.vlIbs,
      r.vlCbs,
      r.vlIs,
      r.chaveAcesso,
    ]),
  ];
  const wsInvoices = XLSX.utils.aoa_to_sheet(invoicesData);
  XLSX.utils.book_append_sheet(wb, wsInvoices, 'Notas Fiscais');

  // Generate and download
  const filename = `Analise_Notas_Saida_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, filename);
}

export function exportFilteredInvoicesToExcel(records: InvoiceRecord[]) {
  const wb = XLSX.utils.book_new();
  const invoicesData = [
    [
      'Empresa',
      'Situação',
      'Dt. Emissão',
      'Dt. Saída/Entrada',
      'Espécie',
      'Nota Fiscal',
      'Série',
      'Cód. Pessoa',
      'Nome Pessoa',
      'CFOP',
      'Valor Contábil',
      'Alíq. ICMS',
      'Base ICMS',
      'Valor ICMS',
      'ICMS Isento',
      'Outro ICMS',
      'IPI',
      'ICMS ST',
      'PIS',
      'COFINS',
      'FCP',
      'FCP ST',
      'IBS',
      'CBS',
      'IS',
      'Chave de Acesso',
    ],
    ...records.map((r) => [
      r.empresa,
      r.situacao,
      r.dtEmissao,
      r.dtSaidaEntrada,
      r.especie,
      r.notaFiscal,
      r.serie,
      r.cdPessoa,
      r.nomePessoa,
      r.cfop,
      r.vlContabil,
      r.aliqIcms,
      r.vlBaseIcms,
      r.vlIcms,
      r.vlIsentoIcms,
      r.vlOutroIcms,
      r.vlIpi,
      r.vlIcmsSt,
      r.vlPis,
      r.vlCofins,
      r.vlFcp,
      r.vlFcpSt,
      r.vlIbs,
      r.vlCbs,
      r.vlIs,
      r.chaveAcesso,
    ]),
  ];
  const ws = XLSX.utils.aoa_to_sheet(invoicesData);
  XLSX.utils.book_append_sheet(wb, ws, 'Notas Filtradas');
  const filename = `Notas_Filtradas_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, filename);
}
