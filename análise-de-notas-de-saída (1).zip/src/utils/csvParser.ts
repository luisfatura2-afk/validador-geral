import Papa from 'papaparse';
import { InvoiceRecord } from '../types/fiscal';

/**
 * Normalizes Brazilian and international monetary / numeric string to float.
 * Handles "1.234,56", "1234,56", "1234.56", "R$ 1.234,56", empty, etc.
 */
export function parseBrazilianNumber(value: unknown): number {
  if (value === null || value === undefined) return 0;
  let str = String(value).trim();
  if (!str) return 0;

  // Remove currency prefix, non-breaking spaces, and whitespace
  str = str.replace(/R\$/gi, '').replace(/\u00A0/g, ' ').replace(/\s+/g, '').trim();
  if (!str) return 0;

  // Handle parenthesized negatives: (123,45) -> -123.45
  let isNegative = false;
  if (str.startsWith('(') && str.endsWith(')')) {
    isNegative = true;
    str = str.slice(1, -1).trim();
  } else if (str.startsWith('-')) {
    isNegative = true;
    str = str.slice(1).trim();
  }

  // If contains both period and comma (e.g. 1.234,56 or 1,234.56)
  if (str.includes('.') && str.includes(',')) {
    const lastDot = str.lastIndexOf('.');
    const lastComma = str.lastIndexOf(',');
    if (lastComma > lastDot) {
      // Brazilian standard 1.234,56 -> 1234.56
      str = str.replace(/\./g, '').replace(',', '.');
    } else {
      // International format 1,234.56 -> 1234.56
      str = str.replace(/,/g, '');
    }
  } else if (str.includes(',')) {
    // Only comma 1234,56 -> 1234.56
    str = str.replace(',', '.');
  }

  // Remove any remaining non-numeric chars except dot
  str = str.replace(/[^0-9.]/g, '');

  const num = parseFloat(str);
  if (isNaN(num)) return 0;
  return isNegative ? -num : num;
}

/**
 * Formats a number to Brazilian currency string: R$ 1.234,56
 */
export function formatBRL(value: number): string {
  if (isNaN(value)) return 'R$ 0,00';
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Formats a number to Brazilian decimal format: 1.234,56
 */
export function formatDecimalBR(value: number, decimals: number = 2): string {
  if (isNaN(value)) return '0,00';
  return value.toLocaleString('pt-BR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

/**
 * Parses date string in formats: "DD/MM/YYYY", "DD/MM/YYYY HH:mm:ss", "YYYY-MM-DD", etc.
 */
export function parseDateBR(dateStr: string): Date | undefined {
  if (!dateStr) return undefined;
  const clean = dateStr.trim().split(' ')[0]; // ignore time part if present

  // DD/MM/YYYY or DD-MM-YYYY
  const brMatch = clean.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (brMatch) {
    const day = parseInt(brMatch[1], 10);
    const month = parseInt(brMatch[2], 10) - 1;
    let year = parseInt(brMatch[3], 10);
    if (year < 100) year += 2000;
    const d = new Date(year, month, day);
    if (!isNaN(d.getTime())) return d;
  }

  // YYYY-MM-DD
  const isoMatch = clean.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
  if (isoMatch) {
    const year = parseInt(isoMatch[1], 10);
    const month = parseInt(isoMatch[2], 10) - 1;
    const day = parseInt(isoMatch[3], 10);
    const d = new Date(year, month, day);
    if (!isNaN(d.getTime())) return d;
  }

  const generic = new Date(dateStr);
  return isNaN(generic.getTime()) ? undefined : generic;
}

/**
 * Normalizes header keys for tolerant lookup
 */
function normalizeKey(key: string): string {
  return key
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove accents
    .replace(/[^a-z0-9]/g, ''); // remove punctuation/spaces
}

/**
 * Map candidate column names to standard keys
 */
function findValue(row: Record<string, string>, candidates: string[]): { val: string; keyFound: string } {
  const normalizedRowKeys: Record<string, string> = {};
  for (const k of Object.keys(row)) {
    const nk = normalizeKey(k);
    if (nk && nk.length > 0) {
      normalizedRowKeys[nk] = k;
    }
  }

  // 1. Exact normalized match
  for (const candidate of candidates) {
    const normCand = normalizeKey(candidate);
    if (normalizedRowKeys[normCand]) {
      const origKey = normalizedRowKeys[normCand];
      return { val: (row[origKey] || '').trim(), keyFound: origKey };
    }
  }

  // 2. Controlled substring matching (strict rules to prevent false positives)
  for (const candidate of candidates) {
    const normCand = normalizeKey(candidate);
    if (normCand.length < 4) continue;
    for (const [normKey, origKey] of Object.entries(normalizedRowKeys)) {
      if (normKey.length < 4) continue;
      // Candidate substring in key (e.g. "vlcontabilcomissao" contains "vlcontabil")
      if (normKey.includes(normCand) || (normKey.length >= 6 && normCand.includes(normKey))) {
        return { val: (row[origKey] || '').trim(), keyFound: origKey };
      }
    }
  }

  return { val: '', keyFound: '' };
}

export interface ParseResult {
  records: InvoiceRecord[];
  columnCount: number;
  detectedColumns: string[];
  missingColumns: string[];
  totalRows: number;
  minDate?: Date;
  maxDate?: Date;
  minDateFormatted: string;
  maxDateFormatted: string;
}

const REQUIRED_CANONICAL_COLUMNS = [
  { name: 'Empresa', candidates: ['empresa', 'cdempresa', 'codempresa', 'filial'] },
  { name: 'Situação', candidates: ['situacao', 'status', 'situacaonf', 'sit'] },
  { name: 'Dt. emissão', candidates: ['dtemissao', 'dataemissao', 'emissao', 'dtemissao'] },
  { name: 'Dt. saída/entrada', candidates: ['dtsaidaentrada', 'dtsaida', 'dtentrada', 'datasaida'] },
  { name: 'Esp.', candidates: ['esp', 'especie', 'modelodocumento', 'modelo'] },
  { name: 'Nota fiscal', candidates: ['notafiscal', 'numero', 'numnf', 'numeronf', 'nf', 'documento'] },
  { name: 'série', candidates: ['serie', 'serienf', 'ser'] },
  { name: 'Cd. pessoa', candidates: ['cdpessoa', 'codpessoa', 'codigopessoa', 'cliente', 'cdcliente', 'cnpjcpf'] },
  { name: 'Nome pessoa', candidates: ['nomepessoa', 'razaosocial', 'nome', 'destinatario', 'cliente'] },
  { name: 'CFOP', candidates: ['cfop', 'codcfop', 'natoperacao'] },
  {
    name: 'Vl. contábil',
    candidates: [
      'vlcontabil',
      'vlrcontabil',
      'valorcontabil',
      'vlcontab',
      'vlrcontab',
      'valortotal',
      'vltotal',
      'vlrtotal',
      'valordocumento',
      'vldocumento',
      'vlrdocumento',
      'vlrdoc',
      'vldoc',
      'valornf',
      'vlnf',
      'vlrnf',
      'vloperacao',
      'vlroperacao',
      'valoroperacao',
      'vlmercadoria',
      'vlrmercadoria',
      'vlrmercadorias',
      'totalnota',
      'totalnf',
      'total',
    ],
  },
  { name: 'Aliq. ICMS', candidates: ['aliqicms', 'aliquotaicms', 'aliq'] },
  { name: 'Vl. base ICMS', candidates: ['vlbaseicms', 'baseicms', 'vlicmsbase'] },
  { name: 'Vl. ICMS', candidates: ['vlicms', 'valoricms', 'icms'] },
  { name: 'Vl. isento ICMS', candidates: ['vlisentoicms', 'isentoicms', 'icmsisento'] },
  { name: 'Vl. outro ICMS', candidates: ['vloutroicms', 'outroicms', 'icmsoutros', 'outrasicms'] },
  { name: 'Vl. IPI', candidates: ['vlipi', 'valoripi', 'ipi'] },
  { name: 'Vl. ICMS ST', candidates: ['vlicmsst', 'icmsst', 'valoricmsst'] },
  { name: 'Vl. PIS', candidates: ['vlpis', 'valorpis', 'pis'] },
  { name: 'Vl. COFINS', candidates: ['vlcofins', 'valorcofins', 'cofins'] },
  { name: 'Vl. FCP', candidates: ['vlfcp', 'valorfcp', 'fcp'] },
  { name: 'Vl. FCP ST', candidates: ['vlfcpst', 'fcpst', 'valorfcpst'] },
  { name: 'VL. IBS', candidates: ['vlibs', 'ibs', 'valoribs'] },
  { name: 'VL. CBS', candidates: ['vlcbs', 'cbs', 'valorcbs'] },
  { name: 'VL. IS', candidates: ['vlis', 'is', 'valoris'] },
  { name: 'Chave acesso', candidates: ['chaveacesso', 'chave', 'chavenfe', 'chaveeletronica', 'chavedanfe'] },
];

export function parseCSVString(csvContent: string): ParseResult {
  // Parse with PapaParse
  const parsed = Papa.parse<Record<string, string>>(csvContent, {
    header: true,
    skipEmptyLines: 'greedy',
    transformHeader: (h) => h.trim(),
  });

  const rawRows = parsed.data || [];
  const detectedHeaders = parsed.meta.fields || [];

  const missingColumns: string[] = [];
  const detectedColumns: string[] = [];

  // Check detected columns against expected canonical list
  REQUIRED_CANONICAL_COLUMNS.forEach((col) => {
    const found = detectedHeaders.some((h) => {
      const normH = normalizeKey(h);
      return col.candidates.some((c) => normalizeKey(c) === normH);
    });
    if (found) {
      detectedColumns.push(col.name);
    } else {
      missingColumns.push(col.name);
    }
  });

  let minDate: Date | undefined;
  let maxDate: Date | undefined;

  const records: InvoiceRecord[] = rawRows.map((row, index) => {
    const getVal = (candidates: string[]) => findValue(row, candidates).val;

    const empresa = getVal(['empresa', 'cdempresa', 'codempresa', 'filial']);
    const situacao = getVal(['situacao', 'status', 'situacaonf', 'sit']);
    const dtEmissao = getVal(['dtemissao', 'dataemissao', 'emissao']);
    const dtSaidaEntrada = getVal(['dtsaidaentrada', 'dtsaida', 'dtentrada', 'datasaida']);
    const especie = getVal(['esp', 'especie', 'modelodocumento', 'modelo']);
    const notaFiscal = getVal(['notafiscal', 'numero', 'numnf', 'numeronf', 'nf', 'documento']);
    const serie = getVal(['serie', 'serienf', 'ser']);
    const cdPessoa = getVal(['cdpessoa', 'codpessoa', 'codigopessoa', 'cliente', 'cdcliente', 'cnpjcpf']);
    const nomePessoa = getVal(['nomepessoa', 'razaosocial', 'nome', 'destinatario']);
    const cfop = getVal(['cfop', 'codcfop', 'natoperacao']);

    const vlContabilRaw = getVal([
      'vlcontabil',
      'vlrcontabil',
      'valorcontabil',
      'vlcontab',
      'vlrcontab',
      'valortotal',
      'vltotal',
      'vlrtotal',
      'valordocumento',
      'vldocumento',
      'vlrdocumento',
      'vlrdoc',
      'vldoc',
      'valornf',
      'vlnf',
      'vlrnf',
      'vloperacao',
      'vlroperacao',
      'valoroperacao',
      'vlmercadoria',
      'vlrmercadoria',
      'vlrmercadorias',
      'totalnota',
      'totalnf',
      'total',
    ]);
    const aliqIcmsRaw = getVal(['aliqicms', 'aliquotaicms', 'aliq']);
    const vlBaseIcmsRaw = getVal(['vlbaseicms', 'baseicms', 'vlicmsbase']);
    const vlIcmsRaw = getVal(['vlicms', 'valoricms', 'icms']);
    const vlIsentoIcmsRaw = getVal(['vlisentoicms', 'isentoicms', 'icmsisento']);
    const vlOutroIcmsRaw = getVal(['vloutroicms', 'outroicms', 'icmsoutros', 'outrasicms']);
    const vlIpiRaw = getVal(['vlipi', 'valoripi', 'ipi']);
    const vlIcmsStRaw = getVal(['vlicmsst', 'icmsst', 'valoricmsst']);
    const vlPisRaw = getVal(['vlpis', 'valorpis', 'pis']);
    const vlCofinsRaw = getVal(['vlcofins', 'valorcofins', 'cofins']);
    const vlFcpRaw = getVal(['vlfcp', 'valorfcp', 'fcp']);
    const vlFcpStRaw = getVal(['vlfcpst', 'fcpst', 'valorfcpst']);
    const vlIbsRaw = getVal(['vlibs', 'ibs', 'valoribs']);
    const vlCbsRaw = getVal(['vlcbs', 'cbs', 'valorcbs']);
    const vlIsRaw = getVal(['vlis', 'is', 'valoris']);
    const chaveAcesso = getVal(['chaveacesso', 'chave', 'chavenfe', 'chaveeletronica', 'chavedanfe']);

    let vlContabil = parseBrazilianNumber(vlContabilRaw);
    const vlBaseIcms = parseBrazilianNumber(vlBaseIcmsRaw);
    // Smart fallback if vlContabil is 0 but base ICMS is available
    if (vlContabil === 0 && vlBaseIcms > 0) {
      vlContabil = vlBaseIcms;
    }

    const dtEmissaoDate = parseDateBR(dtEmissao);
    const dtSaidaEntradaDate = parseDateBR(dtSaidaEntrada);

    if (dtEmissaoDate) {
      if (!minDate || dtEmissaoDate.getTime() < minDate.getTime()) {
        minDate = dtEmissaoDate;
      }
      if (!maxDate || dtEmissaoDate.getTime() > maxDate.getTime()) {
        maxDate = dtEmissaoDate;
      }
    }

    return {
      id: `nf-${index + 1}`,
      empresa,
      situacao,
      dtEmissao,
      dtSaidaEntrada,
      especie,
      notaFiscal,
      serie,
      cdPessoa,
      nomePessoa,
      cfop,
      vlContabil,
      vlContabilRaw,
      aliqIcms: parseBrazilianNumber(aliqIcmsRaw),
      aliqIcmsRaw,
      vlBaseIcms: parseBrazilianNumber(vlBaseIcmsRaw),
      vlBaseIcmsRaw,
      vlIcms: parseBrazilianNumber(vlIcmsRaw),
      vlIcmsRaw,
      vlIsentoIcms: parseBrazilianNumber(vlIsentoIcmsRaw),
      vlIsentoIcmsRaw,
      vlOutroIcms: parseBrazilianNumber(vlOutroIcmsRaw),
      vlOutroIcmsRaw,
      vlIpi: parseBrazilianNumber(vlIpiRaw),
      vlIpiRaw,
      vlIcmsSt: parseBrazilianNumber(vlIcmsStRaw),
      vlIcmsStRaw,
      vlPis: parseBrazilianNumber(vlPisRaw),
      vlPisRaw,
      vlCofins: parseBrazilianNumber(vlCofinsRaw),
      vlCofinsRaw,
      vlFcp: parseBrazilianNumber(vlFcpRaw),
      vlFcpRaw,
      vlFcpSt: parseBrazilianNumber(vlFcpStRaw),
      vlFcpStRaw,
      vlIbs: parseBrazilianNumber(vlIbsRaw),
      vlIbsRaw,
      vlCbs: parseBrazilianNumber(vlCbsRaw),
      vlCbsRaw,
      vlIs: parseBrazilianNumber(vlIsRaw),
      vlIsRaw,
      chaveAcesso: chaveAcesso.replace(/\s+/g, ''),
      dtEmissaoDate,
      dtSaidaEntradaDate,
      rawRow: row,
    };
  });

  const formatDate = (d?: Date) => {
    if (!d) return 'Não identificada';
    return d.toLocaleDateString('pt-BR', { timeZone: 'UTC' });
  };

  return {
    records,
    columnCount: detectedHeaders.length,
    detectedColumns,
    missingColumns,
    totalRows: records.length,
    minDate,
    maxDate,
    minDateFormatted: formatDate(minDate),
    maxDateFormatted: formatDate(maxDate),
  };
}
