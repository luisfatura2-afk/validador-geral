import * as XLSX from 'xlsx';
import { ReconciledItem, ReconciliationKPIs } from '../types/reconciliation';

export function exportReconciliationToExcel(
  items: ReconciledItem[],
  kpis: ReconciliationKPIs
): void {
  const wb = XLSX.utils.book_new();

  // 1. Visão Geral / KPIs Sheet
  const kpiRows = [
    ['TXC FISCAL CONTROL - RELATÓRIO DE CONCILIAÇÃO DE ENTRADAS (QIVE × TOTVS)'],
    ['Gerado em', new Date().toLocaleString('pt-BR')],
    ['Critério de Comparação', 'Chave de Acesso Eletrônica (44 dígitos)'],
    [],
    ['MÉTRICA / INDICADOR', 'QUANTIDADE', 'VALOR TOTAL (R$)'],
    ['Total de Notas no Qive (SEFAZ)', kpis.totalQiveCount, kpis.totalQiveValue],
    ['Total de Notas no TOTVS (ERP)', kpis.totalTotvsCount, kpis.totalTotvsValue],
    ['Conciliadas (Lançadas no TOTVS)', kpis.matchedCount, kpis.matchedValue],
    ['Pendentes no TOTVS (Falta Lançar)', kpis.pendingTotvsCount, kpis.pendingTotvsValue],
    ['Apenas no TOTVS (Ausentes no Qive)', kpis.onlyTotvsCount, kpis.onlyTotvsValue],
    ['Com Divergência de Valor', kpis.divergenceCount, kpis.divergenceValueSum],
    ['Canceladas na SEFAZ', kpis.cancelledCount, kpis.cancelledValue],
    [],
    [
      'Aderência Fiscal (% Conciliado)',
      kpis.totalQiveCount > 0 ? `${((kpis.matchedCount / kpis.totalQiveCount) * 100).toFixed(1)}%` : '0.0%',
      '',
    ],
  ];

  const wsKpi = XLSX.utils.aoa_to_sheet(kpiRows);
  wsKpi['!cols'] = [{ wch: 38 }, { wch: 18 }, { wch: 22 }];
  XLSX.utils.book_append_sheet(wb, wsKpi, 'Resumo Executivo');

  // Helper to map item to row
  const formatItemRow = (item: ReconciledItem) => ({
    'Status Conciliação': item.statusLabel,
    'Chave de Acesso': item.chaveAcesso,
    'Número NF': item.numero,
    'Série': item.serie,
    'Tipo': item.tipoDocumento,
    'Data Emissão': item.dataEmissao,
    'Nome Emitente / Fornecedor': item.nomeEmitente,
    'CNPJ Emitente': item.cnpjEmitente,
    'Valor Qive (R$)': item.valorQive,
    'Valor TOTVS (R$)': item.valorTotvs,
    'Diferença (R$)': item.diferencaValor,
    'ICMS Qive (R$)': item.valorIcmsQive,
    'ICMS TOTVS (R$)': item.valorIcmsTotvs,
    'CFOPs': item.cfops,
    'Manifestação SEFAZ': item.manifestacao,
    'Status SEFAZ': item.statusSefaz,
  });

  // 2. All Items Sheet
  const allRows = items.map(formatItemRow);
  const wsAll = XLSX.utils.json_to_sheet(allRows);
  wsAll['!cols'] = [
    { wch: 32 }, // Status
    { wch: 46 }, // Chave
    { wch: 12 }, // Num
    { wch: 8 },  // Serie
    { wch: 8 },  // Tipo
    { wch: 12 }, // Data
    { wch: 38 }, // Emitente
    { wch: 18 }, // CNPJ
    { wch: 16 }, // Vl Qive
    { wch: 16 }, // Vl TOTVS
    { wch: 14 }, // Dif
    { wch: 14 }, // ICMS Qive
    { wch: 14 }, // ICMS TOTVS
    { wch: 12 }, // CFOP
    { wch: 20 }, // Manifestacao
    { wch: 14 }, // Status SEFAZ
  ];
  XLSX.utils.book_append_sheet(wb, wsAll, 'Todas as Notas');

  // 3. Pending in TOTVS Sheet (CRITICAL AUDIT LIST)
  const pendingRows = items
    .filter((i) => i.status === 'PENDING_IN_TOTVS')
    .map(formatItemRow);
  if (pendingRows.length > 0) {
    const wsPending = XLSX.utils.json_to_sheet(pendingRows);
    wsPending['!cols'] = wsAll['!cols'];
    XLSX.utils.book_append_sheet(wb, wsPending, 'Falta Lançar no TOTVS');
  }

  // 4. Value Divergences Sheet
  const divRows = items
    .filter((i) => i.status === 'VALUE_DIVERGENCE')
    .map(formatItemRow);
  if (divRows.length > 0) {
    const wsDiv = XLSX.utils.json_to_sheet(divRows);
    wsDiv['!cols'] = wsAll['!cols'];
    XLSX.utils.book_append_sheet(wb, wsDiv, 'Divergências de Valor');
  }

  // 5. Only in TOTVS Sheet
  const onlyTotvsRows = items
    .filter((i) => i.status === 'ONLY_IN_TOTVS')
    .map(formatItemRow);
  if (onlyTotvsRows.length > 0) {
    const wsOnlyTotvs = XLSX.utils.json_to_sheet(onlyTotvsRows);
    wsOnlyTotvs['!cols'] = wsAll['!cols'];
    XLSX.utils.book_append_sheet(wb, wsOnlyTotvs, 'Apenas no TOTVS');
  }

  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `conciliacao_entradas_qive_totvs_${dateStr}.xlsx`);
}
