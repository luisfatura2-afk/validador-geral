import { InvoiceRecord, AttentionPoint } from '../types/fiscal';

export function calculateAttentionPoints(records: InvoiceRecord[]): AttentionPoint[] {
  const points: AttentionPoint[] = [];

  // 1. NF sem CFOP
  const noCfopIds = records
    .filter((r) => !r.cfop || r.cfop.trim() === '' || r.cfop === '0' || r.cfop === '0000')
    .map((r) => r.id);
  if (noCfopIds.length > 0) {
    points.push({
      id: 'SEM_CFOP',
      title: 'Notas fiscais sem CFOP informado ou com código zero',
      term: 'Campo não informado',
      description: 'Documentos onde o campo CFOP encontra-se em branco, nulo ou preenchido com zero.',
      count: noCfopIds.length,
      severity: 'warning',
      filterKey: 'SEM_CFOP',
      affectedIds: noCfopIds,
    });
  }

  // 2. NF sem Chave de Acesso
  const noChaveIds = records
    .filter((r) => !r.chaveAcesso || r.chaveAcesso.trim().length === 0 || r.chaveAcesso.length < 44)
    .map((r) => r.id);
  if (noChaveIds.length > 0) {
    points.push({
      id: 'SEM_CHAVE',
      title: 'Notas sem chave de acesso ou com tamanho divergente',
      term: 'Campo não informado',
      description: 'Documentos sem chave eletrônica de 44 dígitos ou campo vazio (comum em notas manuais ou inutilizadas).',
      count: noChaveIds.length,
      severity: 'info',
      filterKey: 'SEM_CHAVE',
      affectedIds: noChaveIds,
    });
  }

  // 3. NF sem valor contábil
  const noValorIds = records
    .filter((r) => r.vlContabil <= 0)
    .map((r) => r.id);
  if (noValorIds.length > 0) {
    points.push({
      id: 'SEM_VALOR',
      title: 'Notas sem valor contábil ou com valor zerado',
      term: 'Verificar',
      description: 'Registros com valor contábil zerado ou não preenchido no arquivo importado.',
      count: noValorIds.length,
      severity: 'warning',
      filterKey: 'SEM_VALOR',
      affectedIds: noValorIds,
    });
  }

  // 4. ICMS sem Base de ICMS
  const icmsSemBaseIds = records
    .filter((r) => r.vlIcms > 0 && r.vlBaseIcms <= 0)
    .map((r) => r.id);
  if (icmsSemBaseIds.length > 0) {
    points.push({
      id: 'ICMS_SEM_BASE',
      title: 'Valor de ICMS informado com Base de Cálculo zerada',
      term: 'Possível inconsistência',
      description: 'Documentos com valor de ICMS destacado, porém com base de cálculo informada como 0,00.',
      count: icmsSemBaseIds.length,
      severity: 'warning',
      filterKey: 'ICMS_SEM_BASE',
      affectedIds: icmsSemBaseIds,
    });
  }

  // 5. Base de ICMS com ICMS zerado
  const baseSemIcmsIds = records
    .filter((r) => r.vlBaseIcms > 0 && r.vlIcms <= 0)
    .map((r) => r.id);
  if (baseSemIcmsIds.length > 0) {
    points.push({
      id: 'BASE_SEM_ICMS',
      title: 'Base de ICMS preenchida porém com Valor de ICMS zerado',
      term: 'Verificar',
      description: 'Documentos com base de cálculo informada mas sem valor de ICMS apurado (conferir alíquota ou CST).',
      count: baseSemIcmsIds.length,
      severity: 'info',
      filterKey: 'BASE_SEM_ICMS',
      affectedIds: baseSemIcmsIds,
    });
  }

  // 6. CFOP igual a zero
  const cfopZeroIds = records
    .filter((r) => r.cfop === '0' || r.cfop === '0000' || r.cfop === '0.000')
    .map((r) => r.id);
  if (cfopZeroIds.length > 0 && cfopZeroIds.length !== noCfopIds.length) {
    points.push({
      id: 'CFOP_ZERO',
      title: 'CFOP preenchido como zero (0000)',
      term: 'Verificar',
      description: 'Documentos que receberam CFOP 0 no preenchimento do sistema de origem.',
      count: cfopZeroIds.length,
      severity: 'warning',
      filterKey: 'CFOP_ZERO',
      affectedIds: cfopZeroIds,
    });
  }

  // 7. Duplicidade de Chave de Acesso
  const chaveCountMap = new Map<string, string[]>();
  records.forEach((r) => {
    if (r.chaveAcesso && r.chaveAcesso.length >= 44) {
      const arr = chaveCountMap.get(r.chaveAcesso) || [];
      arr.push(r.id);
      chaveCountMap.set(r.chaveAcesso, arr);
    }
  });

  const dupChaveIds: string[] = [];
  chaveCountMap.forEach((ids) => {
    if (ids.length > 1) {
      dupChaveIds.push(...ids);
    }
  });

  if (dupChaveIds.length > 0) {
    points.push({
      id: 'DUP_CHAVE',
      title: 'Duplicidade de chave de acesso no arquivo',
      term: 'Possível inconsistência',
      description: 'Mesma chave de acesso de 44 dígitos constando em mais de uma linha da planilha.',
      count: dupChaveIds.length,
      severity: 'critical',
      filterKey: 'DUP_CHAVE',
      affectedIds: dupChaveIds,
    });
  }

  // 8. Duplicidade de Número + Série + Empresa
  const numSerieMap = new Map<string, string[]>();
  records.forEach((r) => {
    if (r.notaFiscal && r.notaFiscal.trim() !== '') {
      const key = `${r.empresa}|${r.serie}|${r.notaFiscal}`;
      const arr = numSerieMap.get(key) || [];
      arr.push(r.id);
      numSerieMap.set(key, arr);
    }
  });

  const dupNumSerieIds: string[] = [];
  numSerieMap.forEach((ids) => {
    if (ids.length > 1) {
      dupNumSerieIds.push(...ids);
    }
  });

  if (dupNumSerieIds.length > 0) {
    points.push({
      id: 'DUP_NUMERO_SERIE',
      title: 'Duplicidade de Empresa + Série + Número da NF',
      term: 'Possível inconsistência',
      description: 'Mesmo número de documento, série e empresa encontrados mais de uma vez.',
      count: dupNumSerieIds.length,
      severity: 'warning',
      filterKey: 'DUP_NUMERO_SERIE',
      affectedIds: dupNumSerieIds,
    });
  }

  // 9. Situações diferentes de autorizada (ex: Cancelada, Inutilizada, Denegada)
  const naoAutorizadasIds = records
    .filter((r) => {
      const s = (r.situacao || '').toLowerCase();
      return !s.includes('autoriz');
    })
    .map((r) => r.id);
  if (naoAutorizadasIds.length > 0) {
    points.push({
      id: 'SITUACOES_NAO_AUTORIZADAS',
      title: 'Documentos com situação diferente de Autorizada',
      term: 'Verificar',
      description: 'Notas canceladas, inutilizadas, denegadas ou pendentes que requerem acompanhamento.',
      count: naoAutorizadasIds.length,
      severity: 'info',
      filterKey: 'SITUACOES_NAO_AUTORIZADAS',
      affectedIds: naoAutorizadasIds,
    });
  }

  // 10. Todos os campos tributários vazios/zerados em nota autorizada com valor
  const tributosZeradosIds = records
    .filter((r) => {
      const isAutorizada = (r.situacao || '').toLowerCase().includes('autoriz');
      const hasValue = r.vlContabil > 0;
      const allZero =
        r.vlIcms === 0 &&
        r.vlBaseIcms === 0 &&
        r.vlIsentoIcms === 0 &&
        r.vlOutroIcms === 0 &&
        r.vlIpi === 0 &&
        r.vlIcmsSt === 0 &&
        r.vlPis === 0 &&
        r.vlCofins === 0 &&
        r.vlIbs === 0 &&
        r.vlCbs === 0;
      return isAutorizada && hasValue && allZero;
    })
    .map((r) => r.id);
  if (tributosZeradosIds.length > 0) {
    points.push({
      id: 'TRIBUTOS_ZERADOS',
      title: 'Campos tributários não preenchidos em nota com valor',
      term: 'Campo não informado',
      description: 'Documentos autorizados com valor contábil mas com tributos (ICMS, PIS, COFINS, etc.) zerados ou não informados no CSV.',
      count: tributosZeradosIds.length,
      severity: 'info',
      filterKey: 'TRIBUTOS_ZERADOS',
      affectedIds: tributosZeradosIds,
    });
  }

  return points;
}
