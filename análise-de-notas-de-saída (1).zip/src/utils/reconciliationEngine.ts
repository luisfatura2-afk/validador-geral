import { InvoiceRecord } from '../types/fiscal';
import {
  QiveRecord,
  ReconciledItem,
  ReconciliationKPIs,
  ReconciliationStatus,
} from '../types/reconciliation';

export interface TotvsKeyAggregate {
  chaveAcesso: string;
  records: InvoiceRecord[];
  totalVlContabil: number;
  totalVlIcms: number;
  empresa: string;
  situacao: string;
  dtEmissao: string;
  dtEmissaoDate?: Date;
  notaFiscal: string;
  serie: string;
  nomePessoa: string;
  cdPessoa: string;
  cfops: string[];
}

/**
 * Aggregates TOTVS rows by Chave de Acesso (accounting for multi-CFOP/item lines)
 */
export function aggregateTotvsByChave(records: InvoiceRecord[]): Map<string, TotvsKeyAggregate> {
  const map = new Map<string, TotvsKeyAggregate>();

  records.forEach((r) => {
    const key = (r.chaveAcesso || '').replace(/\D/g, '');
    const searchKey = key || `totvs_${r.id}`;

    const existing = map.get(searchKey) || {
      chaveAcesso: key,
      records: [],
      totalVlContabil: 0,
      totalVlIcms: 0,
      empresa: r.empresa,
      situacao: r.situacao,
      dtEmissao: r.dtEmissao,
      dtEmissaoDate: r.dtEmissaoDate,
      notaFiscal: r.notaFiscal,
      serie: r.serie,
      nomePessoa: r.nomePessoa,
      cdPessoa: r.cdPessoa,
      cfops: [],
    };

    existing.records.push(r);
    existing.totalVlContabil += r.vlContabil;
    existing.totalVlIcms += r.vlIcms;
    if (r.cfop && !existing.cfops.includes(r.cfop)) {
      existing.cfops.push(r.cfop);
    }

    map.set(searchKey, existing);
  });

  return map;
}

/**
 * Reconciles Qive received invoices against TOTVS recorded invoices
 */
export function reconcileQiveAndTotvs(
  qiveRecords: QiveRecord[],
  totvsRecords: InvoiceRecord[]
): {
  items: ReconciledItem[];
  kpis: ReconciliationKPIs;
} {
  const totvsAggMap = aggregateTotvsByChave(totvsRecords);
  const matchedTotvsKeys = new Set<string>();

  const items: ReconciledItem[] = [];

  // 1. Process all Qive records
  qiveRecords.forEach((q) => {
    const key = (q.chaveAcesso || '').replace(/\D/g, '');
    const totvsAgg = key ? totvsAggMap.get(key) : undefined;

    if (key && totvsAgg) {
      matchedTotvsKeys.add(key);
    }

    let status: ReconciliationStatus = 'MATCHED';
    let statusLabel = 'Conciliada (Lançada no TOTVS)';

    const isQiveCancelled = (q.status || '').toLowerCase().includes('cancel');

    if (isQiveCancelled) {
      status = 'CANCELLED_SEFAZ';
      statusLabel = totvsAgg
        ? 'Alerta: Cancelada na SEFAZ e Lançada no TOTVS'
        : 'Cancelada na SEFAZ';
    } else if (!totvsAgg) {
      status = 'PENDING_IN_TOTVS';
      statusLabel = 'Pendente de Lançamento no TOTVS';
    } else {
      const diff = Math.abs(q.valorTotal - totvsAgg.totalVlContabil);
      if (diff > 0.05) {
        status = 'VALUE_DIVERGENCE';
        statusLabel = `Divergência de Valor (Dif: R$ ${diff.toFixed(2)})`;
      } else {
        status = 'MATCHED';
        statusLabel = 'Conciliada (Lançada no TOTVS)';
      }
    }

    const valorTotvs = totvsAgg ? totvsAgg.totalVlContabil : 0;
    const valorIcmsTotvs = totvsAgg ? totvsAgg.totalVlIcms : 0;
    const diferencaValor = Math.abs(q.valorTotal - valorTotvs);

    // Primary TOTVS row reference
    const primaryTotvs = totvsAgg && totvsAgg.records.length > 0 ? totvsAgg.records[0] : undefined;

    items.push({
      id: `rec_${q.id}`,
      chaveAcesso: key || q.chaveAcesso,
      status,
      statusLabel,
      qive: q,
      totvs: primaryTotvs,
      numero: q.numero || (totvsAgg ? totvsAgg.notaFiscal : ''),
      serie: q.serie || (totvsAgg ? totvsAgg.serie : ''),
      tipoDocumento: q.tipoNota,
      nomeEmitente: q.nomeEmitente || (totvsAgg ? totvsAgg.nomePessoa : ''),
      cnpjEmitente: q.cnpjEmitente || (totvsAgg ? totvsAgg.cdPessoa : ''),
      dataEmissao: q.dataEmissao || (totvsAgg ? totvsAgg.dtEmissao : ''),
      dataEmissaoDate: q.dataEmissaoDate || (totvsAgg ? totvsAgg.dtEmissaoDate : undefined),
      valorQive: q.valorTotal,
      valorTotvs,
      diferencaValor,
      valorIcmsQive: q.valorIcms,
      valorIcmsTotvs,
      cfops: q.cfops || (totvsAgg ? totvsAgg.cfops.join(', ') : ''),
      manifestacao: q.manifestacao,
      statusSefaz: q.status,
    });
  });

  // 2. Process TOTVS records that were NOT in Qive
  totvsAggMap.forEach((totvsAgg, key) => {
    if (key && matchedTotvsKeys.has(key)) return; // already processed

    const primaryTotvs = totvsAgg.records[0];
    const status: ReconciliationStatus = 'ONLY_IN_TOTVS';
    const statusLabel = 'Apenas no TOTVS (Ausente no Qive)';

    let tipoDocumento = primaryTotvs.especie || 'NFe';
    if (key && key.length === 44) {
      const mod = key.substring(20, 22);
      if (mod === '57') tipoDocumento = 'CTe';
      else if (mod === '55') tipoDocumento = 'NFe';
    }

    items.push({
      id: `rec_totvs_${primaryTotvs.id}`,
      chaveAcesso: key,
      status,
      statusLabel,
      totvs: primaryTotvs,
      numero: totvsAgg.notaFiscal,
      serie: totvsAgg.serie,
      tipoDocumento,
      nomeEmitente: totvsAgg.nomePessoa,
      cnpjEmitente: totvsAgg.cdPessoa,
      dataEmissao: totvsAgg.dtEmissao,
      dataEmissaoDate: totvsAgg.dtEmissaoDate,
      valorQive: 0,
      valorTotvs: totvsAgg.totalVlContabil,
      diferencaValor: totvsAgg.totalVlContabil,
      valorIcmsQive: 0,
      valorIcmsTotvs: totvsAgg.totalVlIcms,
      cfops: totvsAgg.cfops.join(', '),
      manifestacao: 'Não localizada no Qive',
      statusSefaz: totvsAgg.situacao || 'Emitida',
    });
  });

  // Calculate KPIs
  let totalQiveCount = qiveRecords.length;
  let totalQiveValue = 0;
  let totalTotvsCount = totvsRecords.length;
  let totalTotvsValue = 0;

  let matchedCount = 0;
  let matchedValue = 0;

  let pendingTotvsCount = 0;
  let pendingTotvsValue = 0;

  let onlyTotvsCount = 0;
  let onlyTotvsValue = 0;

  let divergenceCount = 0;
  let divergenceValueSum = 0;

  let cancelledCount = 0;
  let cancelledValue = 0;

  qiveRecords.forEach((q) => {
    totalQiveValue += q.valorTotal;
  });

  totvsRecords.forEach((t) => {
    totalTotvsValue += t.vlContabil;
  });

  items.forEach((item) => {
    switch (item.status) {
      case 'MATCHED':
        matchedCount++;
        matchedValue += item.valorQive;
        break;
      case 'PENDING_IN_TOTVS':
        pendingTotvsCount++;
        pendingTotvsValue += item.valorQive;
        break;
      case 'ONLY_IN_TOTVS':
        onlyTotvsCount++;
        onlyTotvsValue += item.valorTotvs;
        break;
      case 'VALUE_DIVERGENCE':
        divergenceCount++;
        divergenceValueSum += item.diferencaValor;
        break;
      case 'CANCELLED_SEFAZ':
        cancelledCount++;
        cancelledValue += item.valorQive || item.valorTotvs;
        break;
    }
  });

  const kpis: ReconciliationKPIs = {
    totalQiveCount,
    totalQiveValue,
    totalTotvsCount,
    totalTotvsValue,
    matchedCount,
    matchedValue,
    pendingTotvsCount,
    pendingTotvsValue,
    onlyTotvsCount,
    onlyTotvsValue,
    divergenceCount,
    divergenceValueSum,
    cancelledCount,
    cancelledValue,
  };

  return { items, kpis };
}

/**
 * Format BRL helper
 */
export function formatBRL(val: number): string {
  return val.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Generates an executive text summary of the Entrada reconciliation for email or WhatsApp
 */
export function generateReconciliationEmail(
  kpis: ReconciliationKPIs,
  pendingItems: ReconciledItem[],
  divergentItems: ReconciledItem[]
): string {
  const percentConciliado =
    kpis.totalQiveCount > 0
      ? ((kpis.matchedCount / kpis.totalQiveCount) * 100).toFixed(1)
      : '0.0';

  let email = `Prezados,\n\n`;
  email += `Segue o relatório analítico de conciliação fiscal de entradas (Qive SEFAZ × TOTVS ERP):\n\n`;
  email += `• Total de notas recebidas no Qive (SEFAZ): ${kpis.totalQiveCount} notas (${formatBRL(kpis.totalQiveValue)})\n`;
  email += `• Total de notas lançadas no TOTVS (ERP): ${kpis.totalTotvsCount} notas (${formatBRL(kpis.totalTotvsValue)})\n`;
  email += `• Notas conciliadas com sucesso: ${kpis.matchedCount} notas (${percentConciliado}% de aderência fiscal)\n\n`;

  email += `⚠️ PONTOS DE ATENÇÃO FISCAL:\n`;
  email += `• Notas pendentes de lançamento no TOTVS: ${kpis.pendingTotvsCount} notas (${formatBRL(kpis.pendingTotvsValue)})\n`;
  email += `• Notas lançadas no TOTVS sem correspondente no Qive: ${kpis.onlyTotvsCount} notas (${formatBRL(kpis.onlyTotvsValue)})\n`;
  email += `• Notas com divergência de valores: ${kpis.divergenceCount} notas (Diferença: ${formatBRL(kpis.divergenceValueSum)})\n`;
  email += `• Notas com cancelamento na SEFAZ: ${kpis.cancelledCount} notas\n\n`;

  if (pendingItems.length > 0) {
    email += `PRINCIPAIS NOTAS PENDENTES DE ENTRADA NO TOTVS (TOP 10):\n`;
    pendingItems.slice(0, 10).forEach((item, idx) => {
      email += `${idx + 1}. NF ${item.numero || 'S/N'} (${item.tipoDocumento}) - ${item.nomeEmitente} | Valor: ${formatBRL(item.valorQive)} | Chave: ${item.chaveAcesso}\n`;
    });
    if (pendingItems.length > 10) {
      email += `... e mais ${pendingItems.length - 10} nota(s) pendente(s) constante(s) na planilha anexa.\n`;
    }
    email += `\n`;
  }

  if (divergentItems.length > 0) {
    email += `NOTAS COM DIVERGÊNCIA DE VALORES (QIVE × TOTVS):\n`;
    divergentItems.slice(0, 5).forEach((item, idx) => {
      email += `${idx + 1}. NF ${item.numero} - ${item.nomeEmitente}: Qive ${formatBRL(item.valorQive)} vs TOTVS ${formatBRL(item.valorTotvs)} (Dif: ${formatBRL(item.diferencaValor)})\n`;
    });
    email += `\n`;
  }

  email += `Solicitamos a verificação prioritária dos lançamentos pendentes para fechamento do período fiscal.\n\n`;
  email += `Atenciosamente,\n`;
  email += `Departamento Fiscal • TXC Control\n`;

  return email;
}
