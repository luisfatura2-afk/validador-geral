import * as XLSX from 'xlsx';
import { ReconciliationKPIs, ReconciledItem } from '../types/reconciliation';
import { TaxTotals, CfopSummary } from '../types/fiscal';

export interface IndicatorExportData {
  saidaTotalValue: number;
  saidaTotalCount: number;
  saidaAuthorizedValue: number;
  saidaAuthorizedCount: number;
  saidaTaxTotals: TaxTotals;
  cfopSummaries: CfopSummary[];
  reconciliationKpis: ReconciliationKPIs;
  pendingSuppliers: {
    nome: string;
    cnpj: string;
    count: number;
    totalValue: number;
  }[];
  healthScore: number;
}

export function exportIndicatorsToExcel(data: IndicatorExportData): void {
  const wb = XLSX.utils.book_new();

  // 1. Resumo Executivo & Score Fiscal
  const reconciliationRate =
    data.reconciliationKpis.totalQiveCount > 0
      ? (data.reconciliationKpis.matchedCount / data.reconciliationKpis.totalQiveCount) * 100
      : 0;

  const totalTaxes =
    data.saidaTaxTotals.icms +
    data.saidaTaxTotals.pis +
    data.saidaTaxTotals.cofins +
    data.saidaTaxTotals.ipi +
    data.saidaTaxTotals.icmsSt +
    data.saidaTaxTotals.ibs +
    data.saidaTaxTotals.cbs;

  const effectiveTaxRate =
    data.saidaAuthorizedValue > 0 ? (totalTaxes / data.saidaAuthorizedValue) * 100 : 0;

  const executiveRows = [
    ['TXC FISCAL CONTROL - PAINEL EXECUTIVO DE INDICADORES FISCAIS'],
    ['Data de Emissão do Relatório', new Date().toLocaleString('pt-BR')],
    ['Score de Saúde Fiscal TXC (0-100)', `${data.healthScore} / 100`],
    [],
    ['INDICADOR ESTRATÉGICO', 'VALOR APURADO', 'DETALHAMENTO / META'],
    ['Faturamento de Saída Autorizado', data.saidaAuthorizedValue, `${data.saidaAuthorizedCount} notas emitidas`],
    ['Total de Compras na SEFAZ (Qive)', data.reconciliationKpis.totalQiveValue, `${data.reconciliationKpis.totalQiveCount} notas de fornecedores`],
    ['Total Escriturado no ERP (TOTVS)', data.reconciliationKpis.totalTotvsValue, `${data.reconciliationKpis.totalTotvsCount} notas lançadas`],
    ['Taxa de Conciliação SEFAZ × TOTVS', `${reconciliationRate.toFixed(1)}%`, 'Meta: >= 98,0%'],
    ['Exposição de Pendências (Falta Lançar)', data.reconciliationKpis.pendingTotvsValue, `${data.reconciliationKpis.pendingTotvsCount} notas pendentes`],
    ['Divergências de Valores entre Sistemas', data.reconciliationKpis.divergenceValueSum, `${data.reconciliationKpis.divergenceCount} notas divergentes`],
    ['Total de Tributos Próprios (Saídas)', totalTaxes, `Carga Efetiva: ${effectiveTaxRate.toFixed(2)}%`],
    ['ICMS Próprio', data.saidaTaxTotals.icms, 'Estadual'],
    ['PIS / COFINS Total', data.saidaTaxTotals.pis + data.saidaTaxTotals.cofins, 'Federal'],
    ['IPI Apurado', data.saidaTaxTotals.ipi, 'Federal Industrial'],
  ];

  const wsExec = XLSX.utils.aoa_to_sheet(executiveRows);
  wsExec['!cols'] = [{ wch: 40 }, { wch: 22 }, { wch: 30 }];
  XLSX.utils.book_append_sheet(wb, wsExec, 'Indicadores Executivos');

  // 2. Top Fornecedores Pendentes no TOTVS
  if (data.pendingSuppliers.length > 0) {
    const supplierRows = data.pendingSuppliers.map((s) => ({
      'Fornecedor / Emitente': s.nome,
      'CNPJ': s.cnpj,
      'Qtd Notas Pendentes': s.count,
      'Valor Total Pendente (R$)': s.totalValue,
    }));
    const wsSupp = XLSX.utils.json_to_sheet(supplierRows);
    wsSupp['!cols'] = [{ wch: 45 }, { wch: 22 }, { wch: 22 }, { wch: 25 }];
    XLSX.utils.book_append_sheet(wb, wsSupp, 'Fornecedores Pendentes');
  }

  // 3. CFOPs de Maior Relevância
  if (data.cfopSummaries.length > 0) {
    const cfopRows = data.cfopSummaries.map((c) => ({
      'Código CFOP': c.cfop,
      'Qtd de Notas': c.count,
      'Valor Contábil (R$)': c.vlContabil,
      'ICMS (R$)': c.vlIcms,
      'PIS (R$)': c.vlPis,
      'COFINS (R$)': c.vlCofins,
    }));
    const wsCfop = XLSX.utils.json_to_sheet(cfopRows);
    wsCfop['!cols'] = [{ wch: 15 }, { wch: 15 }, { wch: 22 }, { wch: 18 }, { wch: 18 }, { wch: 18 }];
    XLSX.utils.book_append_sheet(wb, wsCfop, 'Análise CFOP');
  }

  // Download
  XLSX.writeFile(wb, `TXC_Painel_Indicadores_${new Date().toISOString().slice(0, 10)}.xlsx`);
}
