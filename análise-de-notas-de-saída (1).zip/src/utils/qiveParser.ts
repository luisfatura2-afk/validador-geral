import { QiveRecord } from '../types/reconciliation';

export interface QiveParseResult {
  records: QiveRecord[];
  totalRows: number;
  totalValue: number;
  detectedColumns: string[];
  delimiter: string;
}

/**
 * Split CSV line handling quotes properly
 */
export function splitCsvLine(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++; // skip escaped quote
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

/**
 * Detects delimiter (comma or semicolon)
 */
export function detectQiveDelimiter(firstLine: string): string {
  const countComma = (firstLine.match(/,/g) || []).length;
  const countSemicolon = (firstLine.match(/;/g) || []).length;
  const countTab = (firstLine.match(/\t/g) || []).length;

  if (countSemicolon > countComma && countSemicolon > countTab) return ';';
  if (countTab > countComma && countTab > countSemicolon) return '\t';
  return ',';
}

/**
 * Normalizes string for header comparison
 */
function normalizeHeader(str: string): string {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');
}

/**
 * Parse Brazilian currency or decimal number
 */
export function parseBRLNumber(val?: string | number): number {
  if (val === undefined || val === null) return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;

  let s = String(val).trim().replace(/^"|"$/g, '');
  if (!s) return 0;

  // Handle format with dots and commas like "18.901,65" or "18901,65" or "18901.65"
  if (s.includes(',') && s.includes('.')) {
    if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
      // 1.234,56
      s = s.replace(/\./g, '').replace(',', '.');
    } else {
      // 1,234.56
      s = s.replace(/,/g, '');
    }
  } else if (s.includes(',')) {
    // 1234,56
    s = s.replace(',', '.');
  }

  // Remove any non-numeric characters except minus and dot
  s = s.replace(/[^0-9.-]/g, '');

  const num = parseFloat(s);
  return isNaN(num) ? 0 : num;
}

/**
 * Parses date in DD/MM/YYYY format
 */
export function parseBRDate(dateStr?: string): Date | undefined {
  if (!dateStr) return undefined;
  const clean = dateStr.trim().replace(/^"|"$/g, '');
  const parts = clean.split(/[/ -]/);
  if (parts.length < 3) return undefined;

  let day: number, month: number, year: number;
  if (parts[0].length === 4) {
    // YYYY-MM-DD
    year = parseInt(parts[0], 10);
    month = parseInt(parts[1], 10) - 1;
    day = parseInt(parts[2], 10);
  } else {
    // DD/MM/YYYY
    day = parseInt(parts[0], 10);
    month = parseInt(parts[1], 10) - 1;
    year = parseInt(parts[2], 10);
  }

  if (isNaN(day) || isNaN(month) || isNaN(year)) return undefined;
  return new Date(Date.UTC(year, month, day));
}

/**
 * Parse Qive CSV content
 */
export function parseQiveCSVString(csvContent: string): QiveParseResult {
  const lines = csvContent
    .split(/\r\n|\n|\r/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length === 0) {
    return { records: [], totalRows: 0, totalValue: 0, detectedColumns: [], delimiter: ',' };
  }

  const delimiter = detectQiveDelimiter(lines[0]);
  const headerCells = splitCsvLine(lines[0], delimiter).map((h) => h.replace(/^"|"$/g, '').trim());

  // Map header normalized names to column indexes
  const colMap = new Map<string, number>();
  headerCells.forEach((h, idx) => {
    colMap.set(normalizeHeader(h), idx);
  });

  const getVal = (row: string[], ...aliases: string[]): string => {
    for (const alias of aliases) {
      const idx = colMap.get(normalizeHeader(alias));
      if (idx !== undefined && idx < row.length) {
        return row[idx].replace(/^"|"$/g, '').trim();
      }
    }
    return '';
  };

  const records: QiveRecord[] = [];
  let totalValue = 0;

  for (let i = 1; i < lines.length; i++) {
    const row = splitCsvLine(lines[i], delimiter);
    if (row.length <= 1) continue;

    const rawChave = getVal(row, 'Chave de Acesso', 'Chave de acesso', 'Chave Acesso', 'Chave');
    const chaveAcesso = rawChave.replace(/\D/g, ''); // 44 digits

    // Identify document type (NFe: 55, CTe: 57, etc.)
    let tipoNota: 'NFe' | 'CTe' | 'NFSe' | 'Outro' = 'NFe';
    if (chaveAcesso.length === 44) {
      const mod = chaveAcesso.substring(20, 22);
      if (mod === '57') tipoNota = 'CTe';
      else if (mod === '55') tipoNota = 'NFe';
      else if (mod === '65') tipoNota = 'NFe'; // NFC-e
    } else {
      const natureza = getVal(row, 'Natureza Operação', 'Natureza da Operação').toLowerCase();
      if (natureza.includes('transporte') || natureza.includes('cte')) tipoNota = 'CTe';
      else if (natureza.includes('servico') || natureza.includes('nfse')) tipoNota = 'NFSe';
    }

    const dataEmissao = getVal(row, 'Data Emissão', 'Data de Emissão', 'Emissao', 'Data');
    const valorTotal = parseBRLNumber(getVal(row, 'Valor Total da Nota', 'Valor Total', 'Valor'));
    const valorIcms = parseBRLNumber(getVal(row, 'Valor ICMS', 'ICMS', 'Vl. ICMS', 'Vl ICMS'));
    const valorPis = parseBRLNumber(getVal(row, 'Valor PIS', 'PIS', 'Vl. PIS', 'Vl PIS'));
    const valorCofins = parseBRLNumber(getVal(row, 'Valor COFINS', 'COFINS', 'Vl. COFINS', 'Vl COFINS'));
    const valorIpi = parseBRLNumber(getVal(row, 'Valor IPI', 'IPI', 'Vl. IPI', 'Vl IPI'));
    const valorIcmsSt = parseBRLNumber(getVal(row, 'Valor ICMS ST', 'ICMS ST', 'Vl. ICMS ST', 'ICMS-ST'));
    const valorBaseIcms = parseBRLNumber(getVal(row, 'Base ICMS', 'Valor Base ICMS', 'Vl. Base ICMS', 'Base de Cálculo ICMS'));
    const status = getVal(row, 'Status', 'Situação', 'Situacao') || 'Autorizadas';

    const rawRow: Record<string, string> = {};
    headerCells.forEach((header, idx) => {
      rawRow[header] = idx < row.length ? row[idx] : '';
    });

    const record: QiveRecord = {
      id: `qive_${i}_${chaveAcesso || i}`,
      chaveAcesso,
      numero: getVal(row, 'Número', 'Numero', 'Numero da Nota', 'Nota'),
      serie: getVal(row, 'Série', 'Serie'),
      dataEmissao,
      dataEmissaoDate: parseBRDate(dataEmissao),
      nomeEmitente: getVal(row, 'Nome PJ Emitente', 'Emitente', 'Nome Emitente', 'Razão Social Emitente'),
      cnpjEmitente: getVal(row, 'CNPJ Emitente', 'CNPJ/CPF Emitente', 'CNPJ').replace(/\D/g, ''),
      ieEmitente: getVal(row, 'IE Emitente'),
      destinatario: getVal(row, 'Destinatário', 'Destinatario', 'Nome Destinatário'),
      cnpjDestinatario: getVal(row, 'CNPJ Destinatário', 'CNPJ Destinatario').replace(/\D/g, ''),
      ieDestinatario: getVal(row, 'IE Destinatário', 'IE Destinatario'),
      valorTotal,
      valorIcms,
      valorPis,
      valorCofins,
      valorIpi,
      valorIcmsSt,
      valorBaseIcms,
      status,
      manifestacao: getVal(row, 'Manifestação', 'Manifestacao') || 'Sem Manifestação',
      naturezaOperacao: getVal(row, 'Natureza Operação', 'Natureza da Operação'),
      cfops: getVal(row, 'CFOPs da Nota', 'CFOP da Nota', 'CFOP', 'CFOPs'),
      tipoNota,
      rawRow,
    };

    records.push(record);
    totalValue += valorTotal;
  }

  return {
    records,
    totalRows: records.length,
    totalValue,
    detectedColumns: headerCells,
    delimiter,
  };
}
