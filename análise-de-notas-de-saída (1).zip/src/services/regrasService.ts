import { InvoiceRecord } from '../types/fiscal';
import {
  AuditRule,
  AuditFinding,
  AuditSummary,
  RuleCategory,
  AlertSeverity,
} from '../types/auditRules';
import {
  BeneficioFiscal,
  BeneficioFiscalAuditoriaStats,
} from '../types/beneficioFiscal';
import {
  ALL_RULE_EVALUATORS,
  executeAuditEngine,
} from '../rules/engine';

const STORAGE_KEY_BENEFICIOS = 'fiscal_audit_beneficios_v2';

export const TEMPLATES_BENEFICIOS_FISCAIS: BeneficioFiscal[] = [
  {
    id: 'BENEF-PR-800000',
    codigo: 'PR800000',
    nome: 'Isenção de ICMS - Saídas Internas Hortifrutigranjeiros',
    tipoBeneficio: 'ISENCAO',
    cfops: ['5101', '5102', '5103'],
    cstEsperado: '40',
    uf: 'PR',
    baseLegal: 'Item 21 do Anexo V do RICMS/PR',
    descricao: 'Isenção de ICMS para produtos hortícolas e frutas em estado natural nas saídas internas.',
    ativo: true,
    criadoEm: '2026-01-10T10:00:00.000Z',
  },
  {
    id: 'BENEF-SP-000001',
    codigo: 'SP000001',
    nome: 'Redução de Base de Cálculo - Produtos da Cesta Básica',
    tipoBeneficio: 'REDUCAO_BASE',
    cfops: ['5101', '5102', '6101', '6102'],
    cstEsperado: '20',
    percentualReducao: 33.33,
    aliquotaEfetiva: 12,
    uf: 'SP',
    baseLegal: 'Artigo 3º do Anexo II do RICMS/SP',
    descricao: 'Redução da base de cálculo do ICMS de forma que a carga tributária resulte no percentual de 7% ou 12%.',
    ativo: true,
    criadoEm: '2026-01-15T14:30:00.000Z',
  },
  {
    id: 'BENEF-MG-000002',
    codigo: 'MG000002',
    nome: 'Diferimento de ICMS - Insumos Agropecuários',
    tipoBeneficio: 'DIFERIMENTO',
    cfops: ['5101', '5102'],
    cstEsperado: '51',
    uf: 'MG',
    baseLegal: 'Item 4 do Anexo II do RICMS/MG',
    descricao: 'Diferimento do imposto no fornecimento interno de insumos para produção agropecuária.',
    ativo: true,
    criadoEm: '2026-02-01T09:00:00.000Z',
  },
  {
    id: 'BENEF-BR-EXP',
    codigo: 'BR999999',
    nome: 'Não Incidência / Imunidade Constitucional de Exportação',
    tipoBeneficio: 'NAO_INCIDENCIA',
    cfops: ['7101', '7102', '7501'],
    cstEsperado: '41',
    uf: 'TODOS',
    baseLegal: 'Art. 155, § 2º, X, "a" da CF/88 e Lei Complementar 87/96',
    descricao: 'Desoneração constitucional de ICMS sobre operações que destinem mercadorias ao exterior.',
    ativo: true,
    criadoEm: '2026-02-10T11:00:00.000Z',
  },
];

class RegrasService {
  /**
   * Return the list of all registered fiscal audit rules
   */
  public getRegrasDisponiveis(): AuditRule[] {
    return ALL_RULE_EVALUATORS.map((e) => e.rule);
  }

  /**
   * Run full audit over an array of invoices including configured Benefícios Fiscais
   */
  public auditarDocumentos(
    records: InvoiceRecord[],
    beneficios?: BeneficioFiscal[]
  ): AuditSummary {
    const activeBeneficios = beneficios ?? this.getBeneficios();
    return executeAuditEngine(records, activeBeneficios);
  }

  /**
   * Filter findings by category or severity
   */
  public filtrarApontamentos(
    findings: AuditFinding[],
    filtro: {
      category?: RuleCategory | 'ALL';
      severity?: AlertSeverity | 'ALL';
      busca?: string;
    }
  ): AuditFinding[] {
    return findings.filter((f) => {
      if (filtro.category && filtro.category !== 'ALL' && f.category !== filtro.category) {
        return false;
      }
      if (filtro.severity && filtro.severity !== 'ALL' && f.severity !== filtro.severity) {
        return false;
      }
      if (filtro.busca && filtro.busca.trim() !== '') {
        const q = filtro.busca.toLowerCase();
        const match =
          f.title.toLowerCase().includes(q) ||
          f.description.toLowerCase().includes(q) ||
          (f.documentNumber && f.documentNumber.toLowerCase().includes(q)) ||
          (f.documentKey && f.documentKey.toLowerCase().includes(q)) ||
          (f.entityName && f.entityName.toLowerCase().includes(q)) ||
          (f.cfop && f.cfop.toLowerCase().includes(q));
        if (!match) return false;
      }
      return true;
    });
  }

  // ==========================================
  // BENEFÍCIOS FISCAIS CRUD & REPOSITÓRIO LOCAL
  // ==========================================

  /**
   * Retrieve all saved Benefícios Fiscais from localStorage
   */
  public getBeneficios(): BeneficioFiscal[] {
    try {
      // Clear legacy storage key if present
      localStorage.removeItem('fiscal_audit_beneficios_v1');

      const stored = localStorage.getItem(STORAGE_KEY_BENEFICIOS);
      if (stored !== null) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch {
      // fallback
    }

    // Default: start with clean, empty list
    this.salvarTodosBeneficios([]);
    return [];
  }

  /**
   * Save or update a Benefício Fiscal
   */
  public salvarBeneficio(
    data: Omit<BeneficioFiscal, 'id' | 'criadoEm'> & { id?: string }
  ): BeneficioFiscal {
    const list = this.getBeneficios();
    const cleanCfops = (data.cfops || [])
      .map((c) => c.replace(/\D/g, '').trim())
      .filter((c) => c.length > 0);

    const now = new Date().toISOString();

    if (data.id) {
      // Update existing
      const index = list.findIndex((b) => b.id === data.id);
      if (index >= 0) {
        const updated: BeneficioFiscal = {
          ...list[index],
          ...data,
          id: data.id,
          cfops: cleanCfops,
          codigo: data.codigo.trim().toUpperCase(),
          nome: data.nome.trim(),
          uf: (data.uf || 'TODOS').trim().toUpperCase(),
          baseLegal: data.baseLegal.trim(),
          atualizadoEm: now,
        };
        list[index] = updated;
        this.salvarTodosBeneficios(list);
        return updated;
      }
    }

    // Create new
    const novo: BeneficioFiscal = {
      id: `BENEF-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      codigo: data.codigo.trim().toUpperCase(),
      nome: data.nome.trim(),
      tipoBeneficio: data.tipoBeneficio,
      cfops: cleanCfops,
      cstEsperado: data.cstEsperado?.trim(),
      percentualReducao: data.percentualReducao,
      aliquotaEfetiva: data.aliquotaEfetiva,
      uf: (data.uf || 'TODOS').trim().toUpperCase(),
      baseLegal: data.baseLegal.trim(),
      descricao: data.descricao?.trim(),
      ativo: data.ativo ?? true,
      criadoEm: now,
    };

    list.unshift(novo);
    this.salvarTodosBeneficios(list);
    return novo;
  }

  /**
   * Delete a Benefício Fiscal by ID
   */
  public excluirBeneficio(id: string): boolean {
    const list = this.getBeneficios();
    const filtered = list.filter((b) => b.id !== id);
    if (filtered.length !== list.length) {
      this.salvarTodosBeneficios(filtered);
      return true;
    }
    return false;
  }

  /**
   * Delete ALL registered Benefícios Fiscais
   */
  public excluirTodosBeneficios(): void {
    this.salvarTodosBeneficios([]);
  }

  /**
   * Toggle active status of a Benefício Fiscal
   */
  public alternarStatusBeneficio(id: string): boolean {
    const list = this.getBeneficios();
    const index = list.findIndex((b) => b.id === id);
    if (index >= 0) {
      list[index].ativo = !list[index].ativo;
      list[index].atualizadoEm = new Date().toISOString();
      this.salvarTodosBeneficios(list);
      return true;
    }
    return false;
  }

  /**
   * Optional: Load standard sample templates on explicit user request
   */
  public carregarExemplosSugeridos(): BeneficioFiscal[] {
    this.salvarTodosBeneficios(TEMPLATES_BENEFICIOS_FISCAIS);
    return TEMPLATES_BENEFICIOS_FISCAIS;
  }

  /**
   * Reset to empty list
   */
  public resetarBeneficiosPadrao(): BeneficioFiscal[] {
    this.salvarTodosBeneficios([]);
    return [];
  }

  /**
   * Compute aggregate statistics for Benefícios Fiscais given current loaded invoices
   */
  public calcularEstatisticasBeneficios(
    beneficios: BeneficioFiscal[],
    records: InvoiceRecord[]
  ): BeneficioFiscalAuditoriaStats {
    const totalBeneficios = beneficios.length;
    const beneficiosAtivos = beneficios.filter((b) => b.ativo).length;

    // Set of all unique CFOPs across active benefits
    const allCfops = new Set<string>();
    beneficios
      .filter((b) => b.ativo)
      .forEach((b) => {
        b.cfops.forEach((c) => allCfops.add(c.replace(/\D/g, '')));
      });

    let documentosAtingidos = 0;
    let totalValorBeneficio = 0;

    records.forEach((r) => {
      const cleanCfop = (r.cfop || '').replace(/\D/g, '');
      if (cleanCfop && allCfops.has(cleanCfop)) {
        documentosAtingidos += 1;
        totalValorBeneficio += r.vlContabil;
      }
    });

    // Run audit to count finding errors specifically related to BENEFICIO_FISCAL
    const auditRes = executeAuditEngine(records, beneficios);
    const inconsistenciasDetectadas = auditRes.findingsByCategory.BENEFICIO_FISCAL || 0;

    return {
      totalBeneficios,
      beneficiosAtivos,
      totalCfopsVinculados: allCfops.size,
      documentosAtingidos,
      totalValorBeneficio,
      inconsistenciasDetectadas,
    };
  }

  private salvarTodosBeneficios(list: BeneficioFiscal[]): void {
    try {
      localStorage.setItem(STORAGE_KEY_BENEFICIOS, JSON.stringify(list));
    } catch {
      // ignore in constrained env
    }
  }
}

export const regrasService = new RegrasService();

