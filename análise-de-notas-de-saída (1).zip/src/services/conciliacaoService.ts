import {
  QiveRecord,
  ReconciledItem,
  ReconciliationFilterState,
  ReconciliationKPIs,
} from '../types/reconciliation';
import { InvoiceRecord } from '../types/fiscal';
import { reconcileQiveAndTotvs } from '../utils/reconciliationEngine';

class ConciliacaoService {
  /**
   * Reconcile Qive SEFAZ against TOTVS ERP
   */
  public conciliar(
    qiveRecords: QiveRecord[],
    totvsRecords: InvoiceRecord[]
  ): {
    items: ReconciledItem[];
    kpis: ReconciliationKPIs;
  } {
    return reconcileQiveAndTotvs(qiveRecords, totvsRecords);
  }

  /**
   * Apply reconciliation filters
   */
  public filtrarItens(
    items: ReconciledItem[],
    filters: ReconciliationFilterState
  ): ReconciledItem[] {
    return items.filter((item) => {
      // Status
      if (filters.status !== 'ALL') {
        if (item.status !== filters.status) return false;
      }

      // Tipo documento
      if (filters.tipoDocumento !== 'ALL') {
        if (item.tipoDocumento !== filters.tipoDocumento) return false;
      }

      // Manifestacao
      if (filters.manifestacao !== 'ALL') {
        const manif = item.manifestacao || item.qive?.manifestacao || '';
        if (filters.manifestacao === 'CONFIRMADA' && !manif.toLowerCase().includes('confirmad')) return false;
        if (filters.manifestacao === 'CIENCIA' && !manif.toLowerCase().includes('ciência') && !manif.toLowerCase().includes('ciencia')) return false;
        if (filters.manifestacao === 'DESCONHECIDA' && !manif.toLowerCase().includes('desconhec')) return false;
        if (filters.manifestacao === 'NAO_REALIZADA' && !manif.toLowerCase().includes('não realizada') && !manif.toLowerCase().includes('nao realizada')) return false;
        if (filters.manifestacao === 'SEM_MANIFESTACAO' && manif.trim() !== '') return false;
      }

      // Termo busca
      if (filters.termoBusca && filters.termoBusca.trim() !== '') {
        const term = filters.termoBusca.toLowerCase().trim();
        const matchChave = item.chaveAcesso.toLowerCase().includes(term);
        const matchNum = item.numero.toLowerCase().includes(term);
        const matchNome = (item.nomeEmitente || '').toLowerCase().includes(term);
        const matchCnpj = (item.cnpjEmitente || '').toLowerCase().includes(term);
        if (!matchChave && !matchNum && !matchNome && !matchCnpj) return false;
      }

      // Data de emissao
      if (filters.dataInicio && item.dataEmissaoDate) {
        const start = new Date(filters.dataInicio);
        if (item.dataEmissaoDate < start) return false;
      }
      if (filters.dataFim && item.dataEmissaoDate) {
        const end = new Date(filters.dataFim + 'T23:59:59');
        if (item.dataEmissaoDate > end) return false;
      }

      return true;
    });
  }
}

export const conciliacaoService = new ConciliacaoService();
