import { ImportLogEntry, ImportStatus } from '../types/importHistory';
import { parseCSVString, ParseResult } from '../utils/csvParser';
import { parseQiveCSVString, QiveParseResult } from '../utils/qiveParser';

const STORAGE_KEY_IMPORT_HISTORY = 'txc_fiscal_import_history_v2';

class ImportacaoService {
  private inMemoryHistory: ImportLogEntry[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_IMPORT_HISTORY);
      if (saved) {
        this.inMemoryHistory = JSON.parse(saved);
      }
    } catch {
      this.inMemoryHistory = [];
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem(
        STORAGE_KEY_IMPORT_HISTORY,
        JSON.stringify(this.inMemoryHistory.slice(0, 50)) // limit to last 50
      );
    } catch {
      // ignore storage quota issues
    }
  }

  public getHistorico(): ImportLogEntry[] {
    return [...this.inMemoryHistory];
  }

  public listarHistorico(): ImportLogEntry[] {
    return this.getHistorico();
  }

  public registrarImportacao(entry: Omit<ImportLogEntry, 'id' | 'importedAt'>): ImportLogEntry {
    const fullEntry: ImportLogEntry = {
      ...entry,
      id: `IMP-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      importedAt: new Date().toISOString(),
    };

    this.inMemoryHistory.unshift(fullEntry);
    this.saveToStorage();
    return fullEntry;
  }

  public limparHistorico(): void {
    this.inMemoryHistory = [];
    try {
      localStorage.removeItem(STORAGE_KEY_IMPORT_HISTORY);
    } catch {
      // ignore
    }
  }

  // Parse Saída CSV & log
  public processarArquivoSaida(content: string, fileName: string): ParseResult {
    const result = parseCSVString(content);

    const hasMissing = result.missingColumns.length > 0;
    const status: ImportStatus = hasMissing
      ? result.records.length > 0
        ? 'ATENCAO'
        : 'ERRO'
      : 'SUCESSO';

    const totalContabil = result.records.reduce((acc, r) => acc + (r.vlContabil || 0), 0);

    this.registrarImportacao({
      fileName,
      fileSizeBytes: content.length,
      sourceType: 'TOTVS_SAIDA',
      sourceLabel: 'TOTVS ERP (Notas de Saída)',
      totalRecords: result.totalRows,
      validRecords: result.records.length,
      invalidRecords: result.missingColumns.length,
      totalContabil,
      periodStart: result.minDateFormatted,
      periodEnd: result.maxDateFormatted,
      status,
      errors: result.missingColumns.map((col) => ({
        message: `Coluna esperada não identificada: ${col}`,
        severity: 'WARNING',
      })),
    });

    return result;
  }

  // Parse Entrada TOTVS CSV & log
  public processarArquivoEntradaTotvs(content: string, fileName: string): ParseResult {
    const result = parseCSVString(content);

    const hasMissing = result.missingColumns.length > 0;
    const status: ImportStatus = hasMissing
      ? result.records.length > 0
        ? 'ATENCAO'
        : 'ERRO'
      : 'SUCESSO';

    const totalContabil = result.records.reduce((acc, r) => acc + (r.vlContabil || 0), 0);

    this.registrarImportacao({
      fileName,
      fileSizeBytes: content.length,
      sourceType: 'TOTVS_ENTRADA',
      sourceLabel: 'TOTVS ERP (Notas de Entrada)',
      totalRecords: result.totalRows,
      validRecords: result.records.length,
      invalidRecords: result.missingColumns.length,
      totalContabil,
      periodStart: result.minDateFormatted,
      periodEnd: result.maxDateFormatted,
      status,
      errors: result.missingColumns.map((col) => ({
        message: `Coluna esperada não identificada: ${col}`,
        severity: 'WARNING',
      })),
    });

    return result;
  }

  // Parse Qive SEFAZ CSV & log
  public processarArquivoQive(content: string, fileName: string): QiveParseResult {
    const result = parseQiveCSVString(content);

    const status: ImportStatus = result.records.length > 0 ? 'SUCESSO' : 'ERRO';

    this.registrarImportacao({
      fileName,
      fileSizeBytes: content.length,
      sourceType: 'QIVE_SEFAZ',
      sourceLabel: 'Qive SEFAZ (Recebidas)',
      totalRecords: result.totalRows,
      validRecords: result.records.length,
      invalidRecords: 0,
      totalContabil: result.totalValue,
      status,
      errors: [],
    });

    return result;
  }
}

export const importacaoService = new ImportacaoService();
