import {
  InvoiceRecord,
  FilterState,
  TaxTotals,
  CfopSummary,
  SituationSummary,
} from '../types/fiscal';
import { UnifiedFiscalDocument, CentralDadosFilterState } from '../types/centralDados';
import { QiveRecord } from '../types/reconciliation';

export interface NotasStatistics {
  totalNotas: number;
  valorTotalContabil: number;
  totalIcms: number;
  totalPis: number;
  totalCofins: number;
  totalIpi: number;
  totalIbs: number;
  totalCbs: number;
}

class NotasService {
  /**
   * Filter invoice records according to FilterState
   */
  public filterInvoices(records: InvoiceRecord[], filters: FilterState): InvoiceRecord[] {
    return records.filter((r) => {
      // Date filter
      if (filters.dataInicio && r.dtEmissaoDate) {
        const start = new Date(filters.dataInicio);
        if (r.dtEmissaoDate < start) return false;
      }
      if (filters.dataFim && r.dtEmissaoDate) {
        const end = new Date(filters.dataFim + 'T23:59:59');
        if (r.dtEmissaoDate > end) return false;
      }

      // Exact/inclusion filters
      if (filters.empresa && r.empresa !== filters.empresa) return false;
      if (filters.situacao && r.situacao !== filters.situacao) return false;
      if (filters.cfop && r.cfop !== filters.cfop) return false;
      if (filters.especie && r.especie !== filters.especie) return false;
      if (filters.serie && r.serie !== filters.serie) return false;

      // Text search
      if (filters.numeroNf && !r.notaFiscal.toLowerCase().includes(filters.numeroNf.toLowerCase())) {
        return false;
      }
      if (filters.cdPessoa && !r.cdPessoa.toLowerCase().includes(filters.cdPessoa.toLowerCase())) {
        return false;
      }
      if (filters.nomePessoa && !r.nomePessoa.toLowerCase().includes(filters.nomePessoa.toLowerCase())) {
        return false;
      }

      return true;
    });
  }

  /**
   * Calculate Tax Totals
   */
  public calculateTaxTotals(records: InvoiceRecord[]): TaxTotals {
    return records.reduce(
      (acc, r) => {
        acc.icms += r.vlIcms || 0;
        acc.baseIcms += r.vlBaseIcms || 0;
        acc.isentoIcms += r.vlIsentoIcms || 0;
        acc.outroIcms += r.vlOutroIcms || 0;
        acc.icmsSt += r.vlIcmsSt || 0;
        acc.ipi += r.vlIpi || 0;
        acc.pis += r.vlPis || 0;
        acc.cofins += r.vlCofins || 0;
        acc.fcp += r.vlFcp || 0;
        acc.fcpSt += r.vlFcpSt || 0;
        acc.ibs += r.vlIbs || 0;
        acc.cbs += r.vlCbs || 0;
        acc.is += r.vlIs || 0;
        return acc;
      },
      {
        icms: 0,
        baseIcms: 0,
        isentoIcms: 0,
        outroIcms: 0,
        icmsSt: 0,
        ipi: 0,
        pis: 0,
        cofins: 0,
        fcp: 0,
        fcpSt: 0,
        ibs: 0,
        cbs: 0,
        is: 0,
      }
    );
  }

  /**
   * Aggregate CFOP Summaries
   */
  public getCfopSummaries(records: InvoiceRecord[]): CfopSummary[] {
    const map = new Map<string, CfopSummary>();

    records.forEach((r) => {
      const code = r.cfop?.trim() || 'SEM_CFOP';
      const existing = map.get(code);

      if (existing) {
        existing.count += 1;
        existing.vlContabil += r.vlContabil;
        existing.vlIcms += r.vlIcms;
        existing.vlPis += r.vlPis;
        existing.vlCofins += r.vlCofins;
        existing.vlIbs += r.vlIbs || 0;
        existing.vlCbs += r.vlCbs || 0;
      } else {
        map.set(code, {
          cfop: code,
          count: 1,
          vlContabil: r.vlContabil,
          vlIcms: r.vlIcms,
          vlPis: r.vlPis,
          vlCofins: r.vlCofins,
          vlIbs: r.vlIbs || 0,
          vlCbs: r.vlCbs || 0,
        });
      }
    });

    return Array.from(map.values()).sort((a, b) => b.vlContabil - a.vlContabil);
  }

  /**
   * Aggregate Situation Summaries
   */
  public getSituationSummaries(records: InvoiceRecord[]): SituationSummary[] {
    const map = new Map<string, { count: number; vlContabil: number }>();

    records.forEach((r) => {
      const sit = r.situacao?.trim() || 'Não informada';
      const cur = map.get(sit) || { count: 0, vlContabil: 0 };
      cur.count += 1;
      cur.vlContabil += r.vlContabil;
      map.set(sit, cur);
    });

    const total = records.length;
    return Array.from(map.entries())
      .map(([situacao, data]) => ({
        situacao,
        count: data.count,
        vlContabil: data.vlContabil,
        percentage: total > 0 ? (data.count / total) * 100 : 0,
      }))
      .sort((a, b) => b.count - a.count);
  }

  /**
   * Consolidate documents from Saídas, Entradas TOTVS, and Qive into UnifiedFiscalDocument
   * Categorizing into: ENTRADA, SAIDA, DEVOLUCAO, CTE, SERVICO
   */
  public buildCentralDataRepository(
    saidas: InvoiceRecord[],
    entradasTotvs: InvoiceRecord[],
    entradasQive: QiveRecord[]
  ): UnifiedFiscalDocument[] {
    const list: UnifiedFiscalDocument[] = [];

    // 1. Process Saídas
    saidas.forEach((r) => {
      const cleanCfop = (r.cfop || '').replace(/\D/g, '');
      const especie = (r.especie || '').toUpperCase();

      let category: UnifiedFiscalDocument['category'] = 'SAIDA';
      if (cleanCfop.startsWith('120') || cleanCfop.startsWith('220') || cleanCfop.startsWith('520') || cleanCfop.startsWith('620')) {
        category = 'DEVOLUCAO';
      } else if (cleanCfop.startsWith('135') || cleanCfop.startsWith('235') || cleanCfop.startsWith('535') || cleanCfop.startsWith('635') || especie.includes('CTE')) {
        category = 'CTE';
      } else if (cleanCfop === '1933' || cleanCfop === '2933' || especie.includes('NFS') || especie.includes('RPS')) {
        category = 'SERVICO';
      }

      list.push({
        id: `SAIDA-${r.id}`,
        category,
        numero: r.notaFiscal,
        serie: r.serie,
        chaveAcesso: r.chaveAcesso,
        dataEmissao: r.dtEmissao,
        dataMovimentacao: r.dtSaidaEntrada,
        emitenteOuDestinatario: r.nomePessoa,
        documentoPessoa: r.cdPessoa,
        cfopPrincipal: r.cfop,
        valorContabil: r.vlContabil,
        valorIcms: r.vlIcms,
        valorPis: r.vlPis,
        valorCofins: r.vlCofins,
        valorIpi: r.vlIpi,
        valorIbs: r.vlIbs,
        valorCbs: r.vlCbs,
        situacaoSefaz: r.situacao,
        origemFonte: 'TOTVS',
        originalRecord: r,
        temInconsistencia: Boolean(!r.cfop || r.vlContabil <= 0 || (r.chaveAcesso && r.chaveAcesso.length < 44)),
      });
    });

    // 2. Process Entradas TOTVS
    entradasTotvs.forEach((r) => {
      const cleanCfop = (r.cfop || '').replace(/\D/g, '');
      const especie = (r.especie || '').toUpperCase();

      let category: UnifiedFiscalDocument['category'] = 'ENTRADA';
      if (cleanCfop.startsWith('120') || cleanCfop.startsWith('220') || cleanCfop.startsWith('520') || cleanCfop.startsWith('620')) {
        category = 'DEVOLUCAO';
      } else if (cleanCfop.startsWith('135') || cleanCfop.startsWith('235') || cleanCfop.startsWith('535') || cleanCfop.startsWith('635') || especie.includes('CTE')) {
        category = 'CTE';
      } else if (cleanCfop === '1933' || cleanCfop === '2933' || especie.includes('NFS') || especie.includes('RPS')) {
        category = 'SERVICO';
      }

      list.push({
        id: `ENTRADA-TOTVS-${r.id}`,
        category,
        numero: r.notaFiscal,
        serie: r.serie,
        chaveAcesso: r.chaveAcesso,
        dataEmissao: r.dtEmissao,
        dataMovimentacao: r.dtSaidaEntrada,
        emitenteOuDestinatario: r.nomePessoa,
        documentoPessoa: r.cdPessoa,
        cfopPrincipal: r.cfop,
        valorContabil: r.vlContabil,
        valorIcms: r.vlIcms,
        valorPis: r.vlPis,
        valorCofins: r.vlCofins,
        valorIpi: r.vlIpi,
        valorIbs: r.vlIbs,
        valorCbs: r.vlCbs,
        situacaoSefaz: r.situacao,
        origemFonte: 'TOTVS',
        originalRecord: r,
        temInconsistencia: Boolean(!r.cfop || r.vlContabil <= 0 || (r.chaveAcesso && r.chaveAcesso.length < 44)),
      });
    });

    // 3. Process Qive SEFAZ if not duplicate
    entradasQive.forEach((q) => {
      const alreadyInList = list.some((item) => item.chaveAcesso === q.chaveAcesso && q.chaveAcesso.length >= 44);
      if (!alreadyInList) {
        list.push({
          id: `QIVE-${q.id}`,
          category: q.tipoNota === 'CTe' ? 'CTE' : q.tipoNota === 'NFSe' ? 'SERVICO' : 'ENTRADA',
          numero: q.numero,
          serie: q.serie,
          chaveAcesso: q.chaveAcesso,
          dataEmissao: q.dataEmissao,
          emitenteOuDestinatario: q.nomeEmitente,
          documentoPessoa: q.cnpjEmitente,
          cfopPrincipal: q.cfops || 'Diversos',
          valorContabil: q.valorTotal,
          valorIcms: q.valorIcms,
          valorPis: q.valorPis || 0,
          valorCofins: q.valorCofins || 0,
          valorIpi: q.valorIpi || 0,
          situacaoSefaz: q.status,
          origemFonte: 'QIVE_SEFAZ',
          originalRecord: q as unknown as Record<string, unknown>,
          temInconsistencia: Boolean(q.valorTotal <= 0 || !q.chaveAcesso || q.chaveAcesso.length < 44),
        });
      }
    });

    return list;
  }

  /**
   * Filter Central Data Repository
   */
  public filterCentralData(
    items: UnifiedFiscalDocument[],
    filters: CentralDadosFilterState
  ): UnifiedFiscalDocument[] {
    return items.filter((item) => {
      if (filters.category !== 'ALL' && item.category !== filters.category) {
        return false;
      }
      if (filters.origem !== 'ALL' && item.origemFonte !== filters.origem) {
        return false;
      }
      if (filters.apenasInconsistentes && !item.temInconsistencia) {
        return false;
      }
      if (filters.cfop && !item.cfopPrincipal.toLowerCase().includes(filters.cfop.toLowerCase())) {
        return false;
      }
      if (filters.busca) {
        const q = filters.busca.toLowerCase();
        const match =
          item.numero.toLowerCase().includes(q) ||
          item.chaveAcesso.toLowerCase().includes(q) ||
          item.emitenteOuDestinatario.toLowerCase().includes(q) ||
          item.documentoPessoa.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }
}

export const notasService = new NotasService();
