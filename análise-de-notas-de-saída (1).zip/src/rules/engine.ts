import { InvoiceRecord } from '../types/fiscal';
import {
  AlertSeverity,
  RuleCategory,
  AuditFinding,
  AuditRule,
  AuditSummary,
} from '../types/auditRules';
import { BeneficioFiscal } from '../types/beneficioFiscal';

export interface RuleEvaluator {
  rule: AuditRule;
  evaluate: (records: InvoiceRecord[]) => AuditFinding[];
}

// 1. CFOP RULES
export const cfopEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_CFOP_AUSENTE',
      code: 'CFOP-01',
      name: 'CFOP Ausente ou Inválido',
      category: 'CFOP',
      defaultSeverity: 'CRITICO',
      description: 'Documentos fiscais onde o código CFOP está em branco, nulo ou preenchido com 0.',
      legalReference: 'Ajuste SINIEF 07/05 - Anexo Código Fiscal de Operações',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        if (!r.cfop || r.cfop.trim() === '' || r.cfop === '0' || r.cfop === '0000' || r.cfop === '0.000') {
          findings.push({
            id: `CFOP-01-${r.id}`,
            ruleId: 'R_CFOP_AUSENTE',
            ruleCode: 'CFOP-01',
            category: 'CFOP',
            severity: 'CRITICO',
            title: 'CFOP Ausente ou Zero',
            description: `A nota fiscal ${r.notaFiscal || 'S/N'} (série ${r.serie || '0'}) não possui CFOP válido informado.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Informar o CFOP de operação correspondente na emissão/escrituração.',
            impactValue: r.vlContabil,
          });
        }
      });
      return findings;
    },
  },
  {
    rule: {
      id: 'R_CFOP_SENTIDO',
      code: 'CFOP-02',
      name: 'CFOP com Sentido Invertido (Entrada vs Saída)',
      category: 'CFOP',
      defaultSeverity: 'ATENCAO',
      description: 'Identificação de CFOP de entrada (iniciados em 1, 2, 3) em arquivo de saída, ou vice-versa.',
      legalReference: 'Tabela de CFOP - Convênio S/Nº de 1970',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        const clean = (r.cfop || '').replace(/\D/g, '');
        // CFOPs 1xxx, 2xxx, 3xxx are entradas
        if (clean.startsWith('1') || clean.startsWith('2') || clean.startsWith('3')) {
          findings.push({
            id: `CFOP-02-${r.id}`,
            ruleId: 'R_CFOP_SENTIDO',
            ruleCode: 'CFOP-02',
            category: 'CFOP',
            severity: 'ATENCAO',
            title: 'CFOP de Entrada em Lote de Saída',
            description: `Nota fiscal com CFOP ${r.cfop}, característico de operação de entrada/aquisição ou devolução.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Verificar se trata-se de devolução emitida por cliente ou classificação incorreta.',
            impactValue: r.vlContabil,
          });
        }
      });
      return findings;
    },
  },
];

// 2. ICMS RULES
export const icmsEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_ICMS_SEM_BASE',
      code: 'ICMS-01',
      name: 'ICMS Destacado com Base de Cálculo Zerada',
      category: 'ICMS',
      defaultSeverity: 'CRITICO',
      description: 'Documentos fiscais com valor de ICMS informado mas cuja base de cálculo é zero.',
      legalReference: 'Art. 44 do Convênio SINIEF s/nº de 1970',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        if (r.vlIcms > 0 && r.vlBaseIcms <= 0) {
          findings.push({
            id: `ICMS-01-${r.id}`,
            ruleId: 'R_ICMS_SEM_BASE',
            ruleCode: 'ICMS-01',
            category: 'ICMS',
            severity: 'CRITICO',
            title: 'ICMS sem Base de Cálculo',
            description: `Valor de ICMS de R$ ${r.vlIcms.toFixed(2)} informado sem base de cálculo destacada.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Retificar a base de cálculo no ERP para evitar glosa ou autuação da SEFAZ.',
            impactValue: r.vlIcms,
          });
        }
      });
      return findings;
    },
  },
  {
    rule: {
      id: 'R_BASE_SEM_ICMS',
      code: 'ICMS-02',
      name: 'Base de Cálculo com ICMS Zerado',
      category: 'ICMS',
      defaultSeverity: 'ATENCAO',
      description: 'Documentos com base de cálculo de ICMS maior que zero mas imposto apurado como 0,00.',
      legalReference: 'Regulamento do ICMS - Alíquota e Isenção',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        if (r.vlBaseIcms > 0 && r.vlIcms <= 0) {
          findings.push({
            id: `ICMS-02-${r.id}`,
            ruleId: 'R_BASE_SEM_ICMS',
            ruleCode: 'ICMS-02',
            category: 'ICMS',
            severity: 'ATENCAO',
            title: 'Base de ICMS sem Imposto Destacado',
            description: `Base de cálculo de R$ ${r.vlBaseIcms.toFixed(2)} sem destaque correspondente de ICMS.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Verificar alíquota aplicável ou se a operação goza de benefício fiscal.',
            impactValue: r.vlBaseIcms,
          });
        }
      });
      return findings;
    },
  },
];

// 3. PIS & COFINS RULES
export const pisCofinsEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_PIS_COFINS_DIVERGENCIA',
      code: 'FED-01',
      name: 'Divergência entre PIS e COFINS',
      category: 'PIS',
      defaultSeverity: 'ATENCAO',
      description: 'Documentos onde há destaque de PIS mas COFINS zerado, ou destaque de COFINS com PIS zerado.',
      legalReference: 'Leis Federais 10.637/2002 e 10.833/2003',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        const hasPis = r.vlPis > 0;
        const hasCofins = r.vlCofins > 0;
        if ((hasPis && !hasCofins) || (!hasPis && hasCofins)) {
          findings.push({
            id: `FED-01-${r.id}`,
            ruleId: 'R_PIS_COFINS_DIVERGENCIA',
            ruleCode: 'FED-01',
            category: 'PIS',
            severity: 'ATENCAO',
            title: 'Incoerência no Destaque PIS/COFINS',
            description: `Destaque assimétrico de contribuições federais (PIS: R$ ${r.vlPis.toFixed(2)}, COFINS: R$ ${r.vlCofins.toFixed(2)}).`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Conferir se houve tributação monofásica ou omissão de alíquota na apuração.',
            impactValue: Math.abs(r.vlPis - r.vlCofins),
          });
        }
      });
      return findings;
    },
  },
];

// 4. REFORMA TRIBUTÁRIA (IBS & CBS) RULES
export const reformaEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_REFORMA_IBS_CBS',
      code: 'REF-01',
      name: 'Detecção de Destaque IBS/CBS',
      category: 'IBS',
      defaultSeverity: 'INFORMATIVO',
      description: 'Documentos com campos de IBS e CBS preenchidos para controle da Reforma Tributária (EC 132/2023).',
      legalReference: 'Emenda Constitucional 132/2023 - Reforma Tributária',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        if ((r.vlIbs && r.vlIbs > 0) || (r.vlCbs && r.vlCbs > 0)) {
          findings.push({
            id: `REF-01-${r.id}`,
            ruleId: 'R_REFORMA_IBS_CBS',
            ruleCode: 'REF-01',
            category: 'IBS',
            severity: 'INFORMATIVO',
            title: 'Destaque de IBS/CBS Identificado',
            description: `Documento com valores de Reforma Tributária preenchidos (IBS: R$ ${(r.vlIbs || 0).toFixed(2)}, CBS: R$ ${(r.vlCbs || 0).toFixed(2)}).`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Acompanhar parametrização e período de transição dos novos tributos.',
            impactValue: (r.vlIbs || 0) + (r.vlCbs || 0),
          });
        }
      });
      return findings;
    },
  },
];

// 5. CST / COERÊNCIA TRIBUTÁRIA RULES
export const cstEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_TRIBUTOS_ZERADOS_AUTORIZADA',
      code: 'CST-01',
      name: 'Campos Tributários Zerados em Nota Autorizada',
      category: 'CST',
      defaultSeverity: 'INFORMATIVO',
      description: 'Nota com valor contábil mas com todos os campos de tributos informados como 0,00.',
      legalReference: 'Manual de Orientação do Contribuinte (MOC NF-e)',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        const isAutorizada = (r.situacao || '').toLowerCase().includes('autoriz');
        const hasValue = r.vlContabil > 0;
        const allZero =
          r.vlIcms === 0 &&
          r.vlBaseIcms === 0 &&
          r.vlIsentoIcms === 0 &&
          r.vlOutroIcms === 0 &&
          r.vlIpi === 0 &&
          r.vlIcmsSt === 0 &&
          r.vlPis === 0 &&
          r.vlCofins === 0 &&
          (r.vlIbs || 0) === 0 &&
          (r.vlCbs || 0) === 0;

        if (isAutorizada && hasValue && allZero) {
          findings.push({
            id: `CST-01-${r.id}`,
            ruleId: 'R_TRIBUTOS_ZERADOS_AUTORIZADA',
            ruleCode: 'CST-01',
            category: 'CST',
            severity: 'INFORMATIVO',
            title: 'Tributação não destacada em nota com valor',
            description: `Documento autorizado no valor de R$ ${r.vlContabil.toFixed(2)} sem destaque em campos de impostos.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Confirmar se a operação possui enquadramento em Simples Nacional, remessa ou imunidade.',
            impactValue: r.vlContabil,
          });
        }
      });
      return findings;
    },
  },
];

// 6. DUPLICIDADE RULES
export const duplicidadeEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_DUP_CHAVE',
      code: 'DUP-01',
      name: 'Duplicidade de Chave de Acesso (44 dígitos)',
      category: 'DUPLICIDADE',
      defaultSeverity: 'CRITICO',
      description: 'Chaves de acesso de 44 dígitos que aparecem mais de uma vez no mesmo arquivo importado.',
      legalReference: 'Cláusula terceira do Ajuste SINIEF 07/05',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      const chaveMap = new Map<string, InvoiceRecord[]>();

      records.forEach((r) => {
        if (r.chaveAcesso && r.chaveAcesso.length >= 44) {
          const list = chaveMap.get(r.chaveAcesso) || [];
          list.push(r);
          chaveMap.set(r.chaveAcesso, list);
        }
      });

      chaveMap.forEach((list, chave) => {
        if (list.length > 1) {
          list.forEach((r) => {
            findings.push({
              id: `DUP-01-${r.id}`,
              ruleId: 'R_DUP_CHAVE',
              ruleCode: 'DUP-01',
              category: 'DUPLICIDADE',
              severity: 'CRITICO',
              title: 'Chave de Acesso Duplicada',
              description: `A chave ${chave} consta em ${list.length} registros diferentes no arquivo.`,
              documentKey: r.chaveAcesso,
              documentNumber: r.notaFiscal,
              documentSerie: r.serie,
              documentDate: r.dtEmissao,
              entityName: r.nomePessoa,
              entityId: r.cdPessoa,
              cfop: r.cfop,
              suggestedAction: 'Excluir lançamento duplicado no ERP para evitar duplicidade de tributação.',
              impactValue: r.vlContabil,
            });
          });
        }
      });

      return findings;
    },
  },
  {
    rule: {
      id: 'R_DUP_NUM_SERIE',
      code: 'DUP-02',
      name: 'Duplicidade de Empresa + Série + Número',
      category: 'DUPLICIDADE',
      defaultSeverity: 'ATENCAO',
      description: 'Mesma combinação de Empresa, Série e Número de Nota Fiscal encontrada mais de uma vez.',
      legalReference: 'Controle Sequencial de Numeração de NF-e',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      const numSerieMap = new Map<string, InvoiceRecord[]>();

      records.forEach((r) => {
        if (r.notaFiscal && r.notaFiscal.trim() !== '') {
          const key = `${r.empresa}|${r.serie}|${r.notaFiscal}`;
          const list = numSerieMap.get(key) || [];
          list.push(r);
          numSerieMap.set(key, list);
        }
      });

      numSerieMap.forEach((list, key) => {
        if (list.length > 1) {
          list.forEach((r) => {
            findings.push({
              id: `DUP-02-${r.id}`,
              ruleId: 'R_DUP_NUM_SERIE',
              ruleCode: 'DUP-02',
              category: 'DUPLICIDADE',
              severity: 'ATENCAO',
              title: 'Duplicidade de Número e Série',
              description: `A NF ${r.notaFiscal} (Série ${r.serie}, Empresa ${r.empresa}) possui ${list.length} ocorrências.`,
              documentKey: r.chaveAcesso,
              documentNumber: r.notaFiscal,
              documentSerie: r.serie,
              documentDate: r.dtEmissao,
              entityName: r.nomePessoa,
              entityId: r.cdPessoa,
              cfop: r.cfop,
              suggestedAction: 'Verificar se trata-se de desdobramento de itens ou re-emissão indevida.',
              impactValue: r.vlContabil,
            });
          });
        }
      });

      return findings;
    },
  },
];

// 7. DIVERGÊNCIA RULES
export const divergenciaEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_DIV_VALOR_TRIBUTADO',
      code: 'DIV-01',
      name: 'Divergência entre Valor Contábil e Bases Fiscais',
      category: 'DIVERGENCIA',
      defaultSeverity: 'ATENCAO',
      description: 'Valor contábil difere substancialmente da soma de Base ICMS + Isentas + Outras.',
      legalReference: 'Equalização Contábil-Fiscal',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        if (r.vlContabil > 0) {
          const somaBases = r.vlBaseIcms + r.vlIsentoIcms + r.vlOutroIcms;
          // Consider discrepancy only if there are bases filled and difference is > 1.00
          if (somaBases > 0 && Math.abs(r.vlContabil - somaBases) > 1.0) {
            findings.push({
              id: `DIV-01-${r.id}`,
              ruleId: 'R_DIV_VALOR_TRIBUTADO',
              ruleCode: 'DIV-01',
              category: 'DIVERGENCIA',
              severity: 'ATENCAO',
              title: 'Diferença entre Contábil e Desdobro de ICMS',
              description: `Valor contábil de R$ ${r.vlContabil.toFixed(2)} difere da soma (Base + Isento + Outros = R$ ${somaBases.toFixed(2)}).`,
              documentKey: r.chaveAcesso,
              documentNumber: r.notaFiscal,
              documentSerie: r.serie,
              documentDate: r.dtEmissao,
              entityName: r.nomePessoa,
              entityId: r.cdPessoa,
              cfop: r.cfop,
              suggestedAction: 'Auditar desonerações, frete, IPI ou acréscimos comerciais.',
              impactValue: Math.abs(r.vlContabil - somaBases),
            });
          }
        }
      });
      return findings;
    },
  },
];

// 8. DOCUMENTOS INVÁLIDOS RULES
export const documentoInvalidoEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_STATUS_NAO_AUTORIZADO',
      code: 'DOC-01',
      name: 'Documento Não Autorizado (Cancelado/Inutilizado/Denegado)',
      category: 'DOCUMENTO_INVALIDO',
      defaultSeverity: 'ATENCAO',
      description: 'Documentos fiscais com status perante a SEFAZ diferente de Autorizada.',
      legalReference: 'Ajuste SINIEF 07/05 - Situações da NF-e',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        const s = (r.situacao || '').toLowerCase();
        if (s && !s.includes('autoriz')) {
          const isCancelada = s.includes('cancel');
          const isDenegada = s.includes('deneg');
          const severity: AlertSeverity = isDenegada ? 'CRITICO' : 'ATENCAO';

          findings.push({
            id: `DOC-01-${r.id}`,
            ruleId: 'R_STATUS_NAO_AUTORIZADO',
            ruleCode: 'DOC-01',
            category: 'DOCUMENTO_INVALIDO',
            severity,
            title: `Situação SEFAZ: ${r.situacao}`,
            description: `Documento consta como '${r.situacao}'. Não deve computar débito/crédito na apuração normal.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: isCancelada
              ? 'Certificar-se de que não houve circulação de mercadoria ou apropriação indevida de crédito.'
              : 'Verificar motivo de rejeição ou denegação junto ao portal da SEFAZ.',
            impactValue: r.vlContabil,
          });
        }
      });
      return findings;
    },
  },
];

// 9. CAMPOS AUSENTES RULES
export const camposAusentesEvaluators: RuleEvaluator[] = [
  {
    rule: {
      id: 'R_CHAVE_AUSENTE',
      code: 'AUS-01',
      name: 'Chave de Acesso Ausente ou Incompleta',
      category: 'CAMPOS_AUSENTES',
      defaultSeverity: 'ATENCAO',
      description: 'Documentos fiscais sem chave de acesso ou com tamanho inferior a 44 dígitos.',
      legalReference: 'Manual de Padrões Técnicos da NF-e',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        if (!r.chaveAcesso || r.chaveAcesso.trim().length < 44) {
          findings.push({
            id: `AUS-01-${r.id}`,
            ruleId: 'R_CHAVE_AUSENTE',
            ruleCode: 'AUS-01',
            category: 'CAMPOS_AUSENTES',
            severity: 'ATENCAO',
            title: 'Chave de Acesso Incompleta ou Ausente',
            description: `Chave com ${r.chaveAcesso?.trim().length || 0} caracteres (esperado: 44 dígitos numéricos).`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Reprocessar importação do XML original para recuperar a chave eletrônica.',
            impactValue: r.vlContabil,
          });
        }
      });
      return findings;
    },
  },
  {
    rule: {
      id: 'R_VALOR_ZERADO',
      code: 'AUS-02',
      name: 'Valor Contábil Zerado ou Negativo',
      category: 'CAMPOS_AUSENTES',
      defaultSeverity: 'ATENCAO',
      description: 'Registros com valor contábil informado como zero ou negativo no arquivo importado.',
      legalReference: 'Escrituração Fiscal Digital (EFD-ICMS/IPI)',
      enabled: true,
    },
    evaluate: (records) => {
      const findings: AuditFinding[] = [];
      records.forEach((r) => {
        if (r.vlContabil <= 0) {
          findings.push({
            id: `AUS-02-${r.id}`,
            ruleId: 'R_VALOR_ZERADO',
            ruleCode: 'AUS-02',
            category: 'CAMPOS_AUSENTES',
            severity: 'ATENCAO',
            title: 'Valor Contábil Zerado',
            description: `Documento com valor contábil de R$ ${r.vlContabil.toFixed(2)}.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Conferir se a nota é de valor simbólico ou houve erro de extração no relatório.',
            impactValue: 0,
          });
        }
      });
      return findings;
    },
  },
];

// 10. BENEFÍCIOS FISCAIS RULES (VINCULADOS A CFOP)
export function evaluateBeneficiosFiscais(
  records: InvoiceRecord[],
  beneficios: BeneficioFiscal[] = []
): AuditFinding[] {
  const findings: AuditFinding[] = [];
  const activeBeneficios = beneficios.filter((b) => b.ativo);
  if (activeBeneficios.length === 0) return findings;

  records.forEach((r) => {
    const rawCfop = (r.cfop || '').trim();
    const cleanCfop = rawCfop.replace(/\D/g, '');
    if (!cleanCfop) return;

    // Check all active benefits that match this record's CFOP
    const matchingBeneficios = activeBeneficios.filter((b) =>
      b.cfops.some((c) => {
        const cleanC = c.replace(/\D/g, '').trim();
        return cleanC === cleanCfop || rawCfop === c.trim();
      })
    );

    matchingBeneficios.forEach((b) => {
      // 1. ISENÇÃO / DIFERIMENTO / SUSPENSÃO / NÃO INCIDÊNCIA
      if (
        b.tipoBeneficio === 'ISENCAO' ||
        b.tipoBeneficio === 'DIFERIMENTO' ||
        b.tipoBeneficio === 'SUSPENSAO' ||
        b.tipoBeneficio === 'NAO_INCIDENCIA'
      ) {
        if (r.vlIcms > 0) {
          findings.push({
            id: `BENEF-ICMS-${b.id}-${r.id}`,
            ruleId: 'R_BENEF_ICMS_INDEVIDO',
            ruleCode: 'BENEF-01',
            category: 'BENEFICIO_FISCAL',
            severity: 'CRITICO',
            title: `Destaque Indevido de ICMS em CFOP com ${b.tipoBeneficio}`,
            description: `CFOP ${r.cfop} possui benefício fiscal '${b.nome}' (${b.codigo}), mas a nota destacou ICMS de R$ ${r.vlIcms.toFixed(2)}.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: `Verificar se a operação deve usufruir da isenção/diferimento (${b.baseLegal}) e retificar o lançamento contábil.`,
            impactValue: r.vlIcms,
          });
        }

        // Se é isenção total mas não informou valor isento ou outro ICMS
        if (r.vlContabil > 0 && r.vlIsentoIcms <= 0 && r.vlOutroIcms <= 0 && r.vlIcms <= 0) {
          findings.push({
            id: `BENEF-ISENTO-ZERADO-${b.id}-${r.id}`,
            ruleId: 'R_BENEF_SEM_DESDOBRO',
            ruleCode: 'BENEF-02',
            category: 'BENEFICIO_FISCAL',
            severity: 'ATENCAO',
            title: `Operação Beneficiada sem Desdobro de Isenção/Outros`,
            description: `CFOP ${r.cfop} vinculado a '${b.nome}' (${b.codigo}) sem preenchimento dos campos de Vl. Isento ou Vl. Outro ICMS.`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: 'Registrar o valor da parcela desonerada em campo fiscal apropriado da EFD/SPED.',
            impactValue: r.vlContabil,
          });
        }
      }

      // 2. REDUÇÃO DE BASE DE CÁLCULO
      if (b.tipoBeneficio === 'REDUCAO_BASE') {
        if (r.vlBaseIcms >= r.vlContabil && r.vlContabil > 0) {
          findings.push({
            id: `BENEF-BASE-INTEGRAL-${b.id}-${r.id}`,
            ruleId: 'R_BENEF_BASE_NAO_REDUZIDA',
            ruleCode: 'BENEF-03',
            category: 'BENEFICIO_FISCAL',
            severity: 'ATENCAO',
            title: `Base de ICMS Não Reduzida em CFOP Beneficiado`,
            description: `CFOP ${r.cfop} possui benefício de Redução de Base de Cálculo ('${b.nome}'), mas a Base de ICMS (R$ ${r.vlBaseIcms.toFixed(2)}) é igual ou superior ao Contábil (R$ ${r.vlContabil.toFixed(2)}).`,
            documentKey: r.chaveAcesso,
            documentNumber: r.notaFiscal,
            documentSerie: r.serie,
            documentDate: r.dtEmissao,
            entityName: r.nomePessoa,
            entityId: r.cdPessoa,
            cfop: r.cfop,
            suggestedAction: `Aplicar percentual de redução (${b.percentualReducao ? b.percentualReducao + '%' : 'conforme ' + b.baseLegal}) sobre a base calculada.`,
            impactValue: Math.abs(r.vlContabil - r.vlBaseIcms),
          });
        }
      }
    });
  });

  return findings;
}

// All Registered Evaluators
export const ALL_RULE_EVALUATORS: RuleEvaluator[] = [
  ...cfopEvaluators,
  ...icmsEvaluators,
  ...pisCofinsEvaluators,
  ...reformaEvaluators,
  ...cstEvaluators,
  ...duplicidadeEvaluators,
  ...divergenciaEvaluators,
  ...documentoInvalidoEvaluators,
  ...camposAusentesEvaluators,
];

// Master Audit Engine Execution
export function executeAuditEngine(
  records: InvoiceRecord[],
  beneficios: BeneficioFiscal[] = []
): AuditSummary {
  const findings: AuditFinding[] = [];
  const findingsByCategory: Record<RuleCategory, number> = {
    CFOP: 0,
    ICMS: 0,
    PIS: 0,
    COFINS: 0,
    IBS: 0,
    CBS: 0,
    CST: 0,
    DUPLICIDADE: 0,
    DIVERGENCIA: 0,
    DOCUMENTO_INVALIDO: 0,
    CAMPOS_AUSENTES: 0,
    BENEFICIO_FISCAL: 0,
  };
  const findingsBySeverity: Record<AlertSeverity, number> = {
    OK: 0,
    ATENCAO: 0,
    CRITICO: 0,
    INFORMATIVO: 0,
  };

  ALL_RULE_EVALUATORS.forEach(({ rule, evaluate }) => {
    if (rule.enabled) {
      const results = evaluate(records);
      results.forEach((f) => {
        findings.push(f);
        findingsByCategory[f.category] = (findingsByCategory[f.category] || 0) + 1;
        findingsBySeverity[f.severity] = (findingsBySeverity[f.severity] || 0) + 1;
      });
    }
  });

  // Evaluate Benefícios Fiscais
  if (beneficios && beneficios.length > 0) {
    const beneficioFindings = evaluateBeneficiosFiscais(records, beneficios);
    beneficioFindings.forEach((f) => {
      findings.push(f);
      findingsByCategory.BENEFICIO_FISCAL = (findingsByCategory.BENEFICIO_FISCAL || 0) + 1;
      findingsBySeverity[f.severity] = (findingsBySeverity[f.severity] || 0) + 1;
    });
  }

  const affectedRecordIds = new Set(findings.map((f) => f.documentNumber || f.documentKey));
  const totalAnalyzed = records.length;
  const totalAlerts = findings.length;
  const criticalCount = findingsBySeverity.CRITICO;
  const attentionCount = findingsBySeverity.ATENCAO;
  const infoCount = findingsBySeverity.INFORMATIVO;
  const totalWithIssues = affectedRecordIds.size;
  const totalOk = Math.max(0, totalAnalyzed - totalWithIssues);
  const okCount = totalOk;

  return {
    totalAnalyzed,
    totalOk,
    totalAlerts,
    criticalCount,
    attentionCount,
    infoCount,
    okCount,
    findings,
    findingsByCategory,
    findingsBySeverity,
  };
}
